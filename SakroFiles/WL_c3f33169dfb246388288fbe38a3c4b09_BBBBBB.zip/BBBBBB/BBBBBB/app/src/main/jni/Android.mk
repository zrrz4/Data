LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE    := ayan
LOCAL_SRC_FILES := Main.cpp

# Enable modern C++ features
LOCAL_CPPFLAGS += -std=c++17 -fexceptions -frtti

# System libs
LOCAL_LDLIBS += -llog -landroid


include $(BUILD_SHARED_LIBRARY)


#include <sys/types.h>
#include <pthread.h>
#include <jni.h>
#include <string>
#include "obfuscate.h"
#include "ESP.h"
#include "Hacks.h"

#include "Includes.h"

ESP espOverlay;
int type=1,utype=2;

extern "C" JNIEXPORT jstring JNICALL
Java_pubgm_loader_MAct_Telegram(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF(OBFUSCATE("https://t.me/MON5LA"));
}

extern "C" JNIEXPORT void JNICALL
Java_pubgm_loader_drawing_Overlay_DrawOn(JNIEnv *env, jclass , jobject espView, jobject canvas) {
    espOverlay = ESP(env, espView, canvas);
    if (espOverlay.isValid()){
        DrawESP(espOverlay, espOverlay.getWidth(), espOverlay.getHeight());
    }
}

extern "C" JNIEXPORT void JNICALL
Java_pubgm_loader_drawing_Overlay_Close(JNIEnv *,  jobject ) {
    Close();
    options.openState=-1;
	//options.aimBullet = -1;
}

extern "C" JNIEXPORT void JNICALL
Java_pubgm_loader_drawing_FourService_SettingValue(JNIEnv *,  jobject ,jint code,jboolean jboolean1) {
    switch((int)code){
        case 2:
            isPlayerLine = jboolean1;  break;
        case 3:
            isPlayerBox = jboolean1;   break;
        case 4:
            isSkeletonBones = jboolean1;  break;
        case 5:
            isPlayerDist = jboolean1;  break;
        case 6:
            isPlayerHealth = jboolean1;  break;
        case 7:
            isPlayerName = jboolean1;  break;
        case 8:
            isPlayerHead = jboolean1;  break;
        case 9:
            isPlayer360Alert = jboolean1;  break;
        case 10:
            isPlayerWeapon=jboolean1;  break;
        case 11:
            isGrenadeWarning=jboolean1; break;
        case 12:
            isVisibility=jboolean1; break;
        case 20:
            isPlayerWeaponText = jboolean1;
            break;
        case 14:
            options.pour=jboolean1;
            break;
        case 15:
            options.tracingStatus=jboolean1;
            break;
        case 28:
			options.ignoreBot=jboolean1;
            break;
		case 29:
            aIignore=jboolean1;
            break;
    }
}
extern "C" JNIEXPORT void JNICALL
Java_pubgm_loader_drawing_FourService_SettingInt(JNIEnv *,  jobject ,jint code,jint value) {
    switch((int)code){
		//aim
        case 1:
            options.openState = value;  break;
		case 2:
          //  options.aimBullet = value;  break;
		case 3:
            options.aimingRange = 1+value;  break;
		case 4:
            //options.aimingDist = value;  break;
		case 5:
         //   options.recCompe = value;  break;
		case 0:
          //  options.aimingSpeed = 1+value;  break;
		case 6:
            options.aimbotmode = value;  break;
		case 7:
            options.aimingState = value;  break;
		case 8:
            options.priority = value;  break;
			//setting
		case 9:
            setLineThicknes = value;  break;
		case 10:
            setBoxThicknes = value;  break;
		case 11:
            setSkelThicknes = value;  break;
		case 12:
            boxstyle = value;  break;
		case 13:
            countStyle = value;  break;
		case 14:
            stylealert = value;  break;
    }
}

extern "C" JNIEXPORT void JNICALL
Java_pubgm_loader_drawing_FourService_SettingMemory(JNIEnv *env, jobject thiz, jint setting_code,jboolean value) {
    switch((int)setting_code){
        case 1:
           // otherFeature.LessRecoil = value;
            break;
        case 2:
          // otherFeature.ZeroRecoil = value;
            break;
        case 3:
         //   otherFeature.InstantHit = value;
            break;
		case 4:
         //   otherFeature.FastShootInterval = value;
            break;
        case 5:
            otherFeature.HitX = value;
            break;
        case 6:
            otherFeature.SmallCrosshair = value;
            break;
		case 7:
            otherFeature.NoShake = value;
            break;
		case 8:
            otherFeature.WideView = value;
            break;
        case 9:
            otherFeature.Aimbot = value;
            break;
        case 10:
          //  otherFeature.FastSwitchWeapon = value;
            break;
			
    }
}


extern "C"
JNIEXPORT void JNICALL
Java_pubgm_loader_drawing_FourService_WideView(JNIEnv *env, jobject thiz, jint wideview) {
    otherFeature.WideView = wideview;
}

extern "C" JNIEXPORT void JNICALL
Java_pubgm_loader_drawing_TAim_AimBot(JNIEnv *,  jobject ,jint aim) {
    options.openState=aim;
}
extern "C" JNIEXPORT void JNICALL
Java_pubgm_loader_drawing_TBullet_AimBul(JNIEnv *,  jobject ,jint bull) {
   // options.aimBullet=bull;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_pubgm_loader_drawing_Overlay_getReady(JNIEnv *, jclass ,int typeofgame) {
    int sockCheck=1;
    if (!Create()) {
        perror("Creation failed");
        return false;
    }
    setsockopt(sock,SOL_SOCKET,SO_REUSEADDR,&sockCheck, sizeof(int));
    if (!Bind()) {
        perror("Bind failed");
        return false;
    }

    if (!Listen()) {
        perror("Listen failed");
        return false;
    }
    if (Accept()) {
       /* SetValue sv{};
        sv.mode=isck;
        //send((void*)&sv,sizeof(sv));*/
        return true;
    }
}


extern "C"
JNIEXPORT jstring JNICALL
Java_pubgm_loader_SAct_GetKey(JNIEnv *env, jclass clazz) {
    return env->NewStringUTF(OBFUSCATE("https://t.me/MON5LA"));
}

// 🔹 تم حذف دالة Java_pubgm_loader_utils_AuthTask_GetServerUrl نهائياً
// لأن الاتصال بالسيرفر يتم الآن عبر كود Java في AuthTask.java

extern "C"
JNIEXPORT jstring JNICALL
Java_pubgm_loader_Downtwo_PASSJKPAPA(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF("");
}

extern "C"
JNIEXPORT jstring JNICALL
Java_pubgm_loader_MAct_Tele(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF("https://t.me/MON5LA");
}

package pubgm.loader.app;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.configuration.ClientConfiguration;

public class BoxApplication extends Application {

    private static Context context;
    private static final String LOG_PATH = "/storage/emulated/0/Documents/box_log.txt";

    private void writeLog(String msg) {
        try {
            File file = new File(LOG_PATH);
            FileWriter writer = new FileWriter(file, true);
            writer.write(msg + "\n");
            writer.flush();
            writer.close();
        } catch (IOException e) {
            Log.e("BoxApplication", "Log write failed", e);
        }
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        context = base;

        writeLog("attachBaseContext called");

        try {
            BlackBoxCore.get().doAttachBaseContext(base, new ClientConfiguration() {

                @Override
                public String getHostPackageName() {
                    return base.getPackageName();
                }

                @Override
                public boolean isHideRoot() {
                    return true;
                }

                @Override
                public boolean isHideXposed() {
                    return true;
                }

                @Override
                public boolean isEnableDaemonService() {
                    return false;
                }

            });

            writeLog("BlackBoxCore attach success");

        } catch (Exception e) {
            writeLog("attachBaseContext error: " + e.toString());
            e.printStackTrace();
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();

        try {
            // تم إزالة السطر الذي يسبب خطأ الـ SdkKey لأنه غير معرف في هذا الإصدار من المكتبة،
            // وتم استبداله بتهيئة doCreate مباشرة لتجنب فشل التحويل البرمجي.
            BlackBoxCore.get().doCreate();

        } catch (Throwable e) {
            e.printStackTrace(); // Always log errors
        }
    }

    public static Context getAppContext() {
        return context;
    }
}

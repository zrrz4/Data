package pubgm.loader.utils;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import pubgm.loader.Prefs;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.json.JSONObject;

public class AuthTask extends AsyncTask<Void, Void, String> {

    private Context context;
    private String userKey;
    private AuthCallback callback;

    public interface AuthCallback {
        void onResult(boolean success, String message);
    }

    public AuthTask(Context context, String userKey, AuthCallback callback) {
        this.context = context;
        this.userKey = userKey;
        this.callback = callback;
    }

    @Override
    protected String doInBackground(Void... voids) {
        try {
            String urlString = "https://2.x10.mx/public/connect";
            URL url = new URL(urlString);
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();

            // تجاهل شهادة SSL
            if (urlString.startsWith("https")) {
                TrustManager[] trustAllCerts = new TrustManager[]{
                        new X509TrustManager() {
                            public X509Certificate[] getAcceptedIssuers() { return null; }
                            public void checkClientTrusted(X509Certificate[] certs, String authType) { }
                            public void checkServerTrusted(X509Certificate[] certs, String authType) { }
                        }
                };
                SSLContext sc = SSLContext.getInstance("TLS");
                sc.init(null, trustAllCerts, new java.security.SecureRandom());
                connection.setSSLSocketFactory(sc.getSocketFactory());
                connection.setHostnameVerifier(new HostnameVerifier() {
                    public boolean verify(String hostname, SSLSession session) { return true; }
                });
            }

            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setDoOutput(true);

            // الحصول على Android ID كـ serial (مثلما يفعل المشروع الآخر)
            String androidId = android.provider.Settings.Secure.getString(
                    context.getContentResolver(),
                    android.provider.Settings.Secure.ANDROID_ID
            );

            // استخدام game=PUBG كما في الكود الأصلي
            String postData = "game=PUBG&user_key=" + userKey + "&serial=" + androidId;
            Log.d("AuthTask", "Sending: " + postData);

            OutputStream os = connection.getOutputStream();
            os.write(postData.getBytes());
            os.flush();
            os.close();

            int responseCode = connection.getResponseCode();
            if (responseCode == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                return response.toString();
            } else {
                return "{\"status\":false,\"reason\":\"Server error: " + responseCode + "\"}";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "{\"status\":false,\"reason\":\"Connection failed: " + e.getMessage() + "\"}";
        }
    }

    @Override
    protected void onPostExecute(String result) {
        Log.d("AuthTask", "Server response: " + result);

        try {
            JSONObject json = new JSONObject(result);
            boolean status = json.optBoolean("status", false);
            String message = json.optString("reason", "Unknown error");

            if (status) {
                // استخراج EXP من data (كما في المشروع الآخر)
                JSONObject data = json.optJSONObject("data");
                String expiry = "";
                if (data != null) {
                    expiry = data.optString("EXP", "");
                }

                // إذا لم يوجد في data، حاول في الجذر (احتياطي)
                if (expiry.isEmpty()) {
                    expiry = json.optString("EXP", "");
                }
                if (expiry.isEmpty()) {
                    expiry = json.optString("expiry", "");
                }
                if (expiry.isEmpty()) {
                    expiry = json.optString("expire_date", "");
                }

                if (!expiry.isEmpty()) {
                    Prefs.with(context).write("expiry_time", expiry);
                    Log.d("AuthTask", "Expiry time saved: " + expiry);
                } else {
                    // إذا لم يرسل السيرفر وقتاً، استخدم 30 يوماً من الآن كقيمة افتراضية
                    long future = System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                    String defaultExpiry = sdf.format(new Date(future));
                    Prefs.with(context).write("expiry_time", defaultExpiry);
                    Log.d("AuthTask", "No expiry from server, using default: " + defaultExpiry);
                }

                callback.onResult(true, "تم التحقق بنجاح");
            } else {
                callback.onResult(false, message);
            }
        } catch (Exception e) {
            Log.e("AuthTask", "JSON parsing error", e);
            callback.onResult(false, "خطأ في تحليل الرد: " + e.getMessage());
        }
    }
}

package pubgm.loader;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Debug;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;

import org.lsposed.lsparanoid.Obfuscate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import pubgm.loader.drawing.FourService;
import pubgm.loader.drawing.Overlay;
import pubgm.loader.utils.LocaleHelper;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.entity.pm.InstallResult;

@Obfuscate
public class MAct extends AppCompatActivity {

    private static final String TAG = "MAct";

    private static final int STORAGE_PERMISSION = 142;
    private static final int PICK_APK_REQUEST = 1001;
    private static final int PICK_SO_REQUEST = 1002;
    private static final int UNKNOWN_SOURCE_REQUEST = 112;

    private Context ctx;
    private BlackBoxCore blackboxCore;
    private InstallResult installResult;

    private MaterialButton installTwitter;
    private MaterialButton installFacebook;

    private ImageView logoImage;
    private ImageView mbutton1;
    private ImageView mbutton2;

    private TextView tvDays;
    private TextView tvHours;
    private TextView tvMinutes;
    private TextView tvSeconds;

    private Handler timerHandler;
    private Runnable timerRunnable;

    private boolean isPatcherActive = false;
    private boolean countdownStarted = false;
    private boolean securityCheckDone = false;

    /*
     * Bottom Navigation
     */
    private BottomNavigationView bottomNavigationView;
    private View imenu1;
    private View imenu2;
    private View imenu3;

    public static String socket;

    public String daemonPath;
    public String libPath;
    public String verPath;

    public static int game_ver = 0;
    public static boolean Record = false;
    public static boolean isBgmi = false;

    private static final String[] APP_PACKAGES = {
            "com.tencent.ig",
            "com.pubg.krmobile",
            "com.pubg.imobile",
            "com.twitter.android",
            "com.facebook.katana",
            "com.vng.pubgmobile",
            "com.rekoo.pubgm"
    };

    private static final String[] FB_PACKAGES = {
            "com.facebook.katana",
            "com.webview.space",
            "com.facebook.services",
            "com.facebook.system"
    };

    private static final String LAUNCH_STR =
            decode("Launch");

    private static final String ROOT_ONLY_MSG =
            decode("Root Only!!");

    private static final String OBB_INSTALLED_MSG =
            decode("OBB Installed");

    private static final String INSTALL_SUCCESS_MSG =
            decode("App Installed in Virtual Space!");

    private static final String APK_INSTALLED_MSG =
            decode("APK Installed Successfully!");

    private static final String INVALID_APK_MSG =
            decode("Invalid APK File");

    private static final String CANNOT_LAUNCH_MSG =
            decode("Cannot launch app");

    private static final String UNINSTALLED_VIRTUAL_MSG =
            decode("Uninstalled from Virtual");

    private static final String NO_APPS_MSG =
            decode("No apps found");

    private static final String FAILED_GET_APK_MSG =
            decode("Failed to get APK path");

    private static final String SELECT_APP_MSG =
            decode("Select an App or APK File");

    private static final String CHOOSE_ACTION_MSG =
            decode("Choose Action");

    private static final String INSTALL_VIRTUAL_MSG =
            decode("Install in Virtual");

    private static final String UNINSTALL_MSG =
            decode("Uninstall");

    private static final String MENU_BUILDER_CLASS =
            decode("MenuBuilder");

    private static final String SET_OPTIONAL_ICONS_VISIBLE =
            decode("setOptionalIconsVisible");

    private static final String DO_NOT_DELETE_STR =
            decode("DO NOT DELETE");

    static {
        try {
            System.loadLibrary("ayan");
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "Unable to load native library", e);
        } catch (Exception e) {
            Log.e(TAG, "Native library initialization failed", e);
        }
    }

    private native String Tele();

    private static String decode(String value) {

        if (value == null) {
            return "";
        }

        try {
            return new String(
                    Base64.decode(
                            Base64.encodeToString(
                                    value.getBytes(),
                                    Base64.DEFAULT
                            ),
                            Base64.DEFAULT
                    )
            );
        } catch (Exception e) {
            return value;
        }
    }

    private static boolean equalsSafe(String a, String b) {

        if (a == null || b == null) {
            return false;
        }

        if (a.length() != b.length()) {
            return false;
        }

        int result = 0;

        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }

        return result == 0;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            setContentView(R.layout.activity_navigation);
        } catch (Exception e) {
            Log.e(TAG, "Unable to load activity_navigation", e);
            return;
        }

        ctx = this;

        try {
            LocaleHelper.applySavedLocale(this);
        } catch (Exception e) {
            Log.e(TAG, "Locale initialization failed", e);
        }

        try {
            WarningManager.checkWarning(this);
        } catch (Exception e) {
            Log.e(TAG, "Warning manager failed", e);
        }

        configureSystemUi();

        initializeBlackBox();

        makeDirectories();

        setupToolbar();

        /*
         * تشغيل Bottom Navigation
         */
        setupBottomNavigation();

        setupCountdown();

        setupButtons();

        setupLogoButton();

        setupOverlayPermission();

        setupVersionViews();

        applyPremiumAnimations();

        performSecurityCheck();
    }

    /*
     * =========================================================
     * Bottom Navigation
     * =========================================================
     */

    private void setupBottomNavigation() {

        try {

            bottomNavigationView =
                    findViewById(R.id.bottomNavigationView);

            imenu1 =
                    findViewById(R.id.imenu1);

            imenu2 =
                    findViewById(R.id.imenu2);

            imenu3 =
                    findViewById(R.id.imenu3);

            if (bottomNavigationView == null) {

                Log.w(
                        TAG,
                        "bottomNavigationView not found"
                );

                return;
            }

            /*
             * الصفحة الأولى عند تشغيل التطبيق
             */
            showNavigationPage(0);

            /*
             * تحديد أول عنصر
             */
            if (bottomNavigationView.getMenu().size() > 0) {

                bottomNavigationView
                        .getMenu()
                        .getItem(0)
                        .setChecked(true);
            }

            /*
             * عند الضغط على أي عنصر
             */
            bottomNavigationView.setOnItemSelectedListener(
                    item -> {

                        if (item == null) {
                            return false;
                        }

                        int position =
                                getMenuItemPosition(item);

                        if (position < 0) {
                            return false;
                        }

                        showNavigationPage(position);

                        return true;
                    }
            );

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Bottom navigation setup failed",
                    e
            );
        }
    }

    /*
     * معرفة ترتيب العنصر داخل BottomNavigationView
     */
    private int getMenuItemPosition(
            @NonNull MenuItem selectedItem
    ) {

        try {

            Menu menu =
                    bottomNavigationView.getMenu();

            for (int i = 0; i < menu.size(); i++) {

                MenuItem item =
                        menu.getItem(i);

                if (item == selectedItem) {
                    return i;
                }

                if (item.getItemId()
                        == selectedItem.getItemId()) {

                    return i;
                }
            }

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Unable to get menu position",
                    e
            );
        }

        return -1;
    }

    /*
     * إظهار الصفحة المطلوبة
     *
     * 0 = imenu1
     * 1 = imenu2
     * 2 = imenu3
     */
    private void showNavigationPage(
            int position
    ) {

        try {

            if (imenu1 != null) {
                imenu1.setVisibility(View.GONE);
            }

            if (imenu2 != null) {
                imenu2.setVisibility(View.GONE);
            }

            if (imenu3 != null) {
                imenu3.setVisibility(View.GONE);
            }

            View selectedPage = null;

            switch (position) {

                case 0:

                    selectedPage = imenu1;

                    break;

                case 1:

                    selectedPage = imenu2;

                    break;

                case 2:

                    selectedPage = imenu3;

                    break;

                default:

                    selectedPage = imenu1;

                    break;
            }

            if (selectedPage != null) {

                selectedPage.setVisibility(
                        View.VISIBLE
                );

                animateNavigationPage(
                        selectedPage
                );
            }

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Unable to switch navigation page",
                    e
            );
        }
    }

    /*
     * أنيميشن خفيف عند الانتقال بين الصفحات
     */
    private void animateNavigationPage(
            View view
    ) {

        if (view == null
                || isActivityInvalid()) {
            return;
        }

        try {

            Animation animation =
                    AnimationUtils.loadAnimation(
                            this,
                            R.anim.fade_in_up
                    );

            if (animation != null) {
                view.startAnimation(animation);
            }

        } catch (Exception e) {

            /*
             * إذا لم يكن ملف الأنيميشن موجودًا
             * لا نوقف التطبيق.
             */
            Log.w(
                    TAG,
                    "Navigation animation unavailable",
                    e
            );
        }
    }

    /*
     * =========================================================
     * System UI
     * =========================================================
     */

    private void configureSystemUi() {

        try {

            Window window = getWindow();

            if (window == null) {
                return;
            }

            window.setNavigationBarColor(Color.BLACK);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                window.setNavigationBarContrastEnforced(false);
            }

            hideNavigationBar();

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "System UI configuration failed",
                    e
            );
        }
    }

    private void hideNavigationBar() {

        try {

            final View decorView =
                    getWindow().getDecorView();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {

                android.view.WindowInsetsController controller =
                        decorView.getWindowInsetsController();

                if (controller != null) {

                    controller.hide(
                            android.view.WindowInsets.Type.navigationBars()
                    );

                    controller.setSystemBarsBehavior(
                            android.view.WindowInsetsController
                                    .BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    );
                }

            } else {

                int flags =
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                    flags |=
                            decorView.getSystemUiVisibility()
                                    & View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                }

                decorView.setSystemUiVisibility(flags);
            }

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Unable to hide navigation bar",
                    e
            );
        }
    }

    @Override
    public void onWindowFocusChanged(
            boolean hasFocus
    ) {

        super.onWindowFocusChanged(hasFocus);

        if (hasFocus) {

            new Handler(
                    Looper.getMainLooper()
            ).postDelayed(
                    this::hideNavigationBar,
                    100L
            );
        }
    }

    private void initializeBlackBox() {

        try {

            blackboxCore = BlackBoxCore.get();

            if (blackboxCore != null) {
                blackboxCore.doCreate();
            }

        } catch (Exception e) {

            blackboxCore = null;

            Log.e(
                    TAG,
                    "BlackBox initialization failed",
                    e
            );
        }
    }

    private void setupToolbar() {

        Toolbar toolbar =
                findViewById(R.id.toolbar);

        if (toolbar == null) {
            return;
        }

        try {

            setSupportActionBar(toolbar);

            try {

                toolbar.inflateMenu(
                        R.menu.options_home
                );

            } catch (Exception e) {

                Log.w(
                        TAG,
                        "options_home menu not available",
                        e
                );
            }

            try {

                toolbar.setOverflowIcon(
                        ContextCompat.getDrawable(
                                this,
                                R.drawable.ic_menu_custom
                        )
                );

            } catch (Exception e) {

                Log.w(
                        TAG,
                        "Custom overflow icon unavailable",
                        e
                );
            }

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Toolbar setup failed",
                    e
            );
        }
    }

    private void setupButtons() {

        MaterialButton installGlobal =
                findViewById(R.id.InstallGlobal);

        MaterialButton installKorea =
                findViewById(R.id.installkorea);

        MaterialButton installBgmi =
                findViewById(R.id.InstallBgmi);

        MaterialButton installVng =
                findViewById(R.id.installvng);

        MaterialButton installTw =
                findViewById(R.id.installtw);

        MaterialButton installVia =
                findViewById(R.id.installvia);

        installTwitter =
                findViewById(R.id.installtwitter);

        installFacebook =
                findViewById(R.id.installfacebook);

        MaterialButton fixObbButton =
                findViewById(R.id.fixObbButton);

        MaterialButton libBindButton =
                findViewById(R.id.libbind);

        mbutton1 =
                findViewById(R.id.b01);

        mbutton2 =
                findViewById(R.id.b02);

        if (fixObbButton != null) {

            fixObbButton.setOnClickListener(
                    this::showFixObbMenu
            );
        }

        if (libBindButton != null) {

            libBindButton.setOnClickListener(
                    v -> openSoPicker()
            );
        }

        if (mbutton1 != null) {

            mbutton1.setOnClickListener(v -> {

                if (!isActivityValid()) {
                    return;
                }

                if (!LogAct.Container) {

                    startFloater();

                    isPatcherActive = true;

                } else {

                    showToast(
                            ROOT_ONLY_MSG,
                            Toast.LENGTH_LONG
                    );
                }
            });
        }

        if (mbutton2 != null) {

            mbutton2.setOnClickListener(v -> {

                if (!isActivityValid()) {
                    return;
                }

                if (!LogAct.Container) {

                    stopFloating();

                    isPatcherActive = false;

                } else {

                    showToast(
                            ROOT_ONLY_MSG,
                            Toast.LENGTH_LONG
                    );
                }
            });
        }

        if (installGlobal != null) {

            installGlobal.setOnClickListener(
                    v -> installGame(
                            installGlobal,
                            APP_PACKAGES[0]
                    )
            );
        }

        if (installKorea != null) {

            installKorea.setOnClickListener(
                    v -> installGame(
                            installKorea,
                            APP_PACKAGES[1]
                    )
            );
        }

        if (installBgmi != null) {

            installBgmi.setOnClickListener(
                    v -> installGame(
                            installBgmi,
                            APP_PACKAGES[2]
                    )
            );
        }

        if (installVng != null) {

            installVng.setOnClickListener(
                    v -> installGame(
                            installVng,
                            APP_PACKAGES[5]
                    )
            );
        }

        if (installTw != null) {

            installTw.setOnClickListener(
                    v -> installGame(
                            installTw,
                            APP_PACKAGES[6]
                    )
            );
        }

        if (installFacebook != null) {

            installFacebook.setOnClickListener(
                    v -> openUrl(
                            "https://www.facebook.com/login"
                    )
            );
        }

        if (installTwitter != null) {

            installTwitter.setOnClickListener(
                    v -> launchOrInstallSocial(
                            installTwitter,
                            APP_PACKAGES[3]
                    )
            );
        }

        if (installVia != null) {

            installVia.setOnClickListener(v -> {

                if (LogAct.Container) {

                    showAppPickerDialog();

                } else {

                    showToast(
                            ROOT_ONLY_MSG,
                            Toast.LENGTH_SHORT
                    );
                }
            });
        }

        updateGameButtonStates(
                installGlobal,
                installKorea,
                installBgmi,
                installVng,
                installTw
        );
    }

    private void updateGameButtonStates(
            MaterialButton global,
            MaterialButton korea,
            MaterialButton bgmi,
            MaterialButton vng,
            MaterialButton tw
    ) {

        if (isPackageInstalled(APP_PACKAGES[0])
                && global != null) {

            global.setText(LAUNCH_STR);
            game_ver = 0;
        }

        if (isPackageInstalled(APP_PACKAGES[1])
                && korea != null) {

            korea.setText(LAUNCH_STR);
            game_ver = 1;
        }

        if (isPackageInstalled(APP_PACKAGES[2])
                && bgmi != null) {

            bgmi.setText(LAUNCH_STR);
            game_ver = 2;
            isBgmi = true;
        }

        if (isPackageInstalled(APP_PACKAGES[3])
                && installTwitter != null) {

            installTwitter.setText(LAUNCH_STR);
        }

        if (isPackageInstalled(APP_PACKAGES[4])
                && installFacebook != null) {

            installFacebook.setText(LAUNCH_STR);
        }

        if (isPackageInstalled(APP_PACKAGES[5])
                && vng != null) {

            vng.setText(LAUNCH_STR);
            game_ver = 3;
        }

        if (isPackageInstalled(APP_PACKAGES[6])
                && tw != null) {

            tw.setText(LAUNCH_STR);
            game_ver = 4;
        }
    }

    private void setupLogoButton() {

        logoImage =
                findViewById(R.id.logoImage);

        if (logoImage == null) {

            Log.w(
                    TAG,
                    "R.id.logoImage was not found"
            );

            return;
        }

        logoImage.setOnClickListener(
                v -> toggleFloater()
        );
    }

    private void toggleFloater() {

        if (!isActivityValid()) {
            return;
        }

        try {

            if (!isPatcherActive) {

                startFloater();

                isPatcherActive = true;

                showToast(
                        "Menu opened",
                        Toast.LENGTH_SHORT
                );

            } else {

                stopFloating();

                isPatcherActive = false;

                showToast(
                        "Menu closed",
                        Toast.LENGTH_SHORT
                );
            }

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Toggle floater error",
                    e
            );
        }
    }

    private void setupCountdown() {

        tvDays =
                findTextViewByName("tv_d");

        tvHours =
                findTextViewByName("tv_h");

        tvMinutes =
                findTextViewByName("tv_m");

        tvSeconds =
                findTextViewByName("tv_s");

        startCountdownTimer();
    }

    private TextView findTextViewByName(
            String idName
    ) {

        View view =
                findViewByName(idName);

        if (view instanceof TextView) {
            return (TextView) view;
        }

        return null;
    }

    private View findViewByName(
            String idName
    ) {

        if (idName == null
                || idName.trim().isEmpty()) {

            return null;
        }

        try {

            int id =
                    getResources()
                            .getIdentifier(
                                    idName,
                                    "id",
                                    getPackageName()
                            );

            if (id == 0) {

                Log.w(
                        TAG,
                        "View ID not found: " + idName
                );

                return null;
            }

            return findViewById(id);

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Unable to find View: " + idName,
                    e
            );

            return null;
        }
    }

    private void startCountdownTimer() {

        if (countdownStarted) {
            return;
        }

        countdownStarted = true;

        timerHandler =
                new Handler(
                        Looper.getMainLooper()
                );

        timerRunnable = new Runnable() {

            @Override
            public void run() {

                if (isActivityInvalid()) {
                    return;
                }

                updateCountdown();

                if (timerHandler != null
                        && !isActivityInvalid()) {

                    timerHandler.postDelayed(
                            this,
                            1000L
                    );
                }
            }
        };

        timerHandler.post(timerRunnable);
    }

    private void updateCountdown() {

        try {

            String expiry =
                    getIntent()
                            .getStringExtra(
                                    "EXPIRY_TIME"
                            );

            if (expiry == null
                    || expiry.trim().isEmpty()) {

                setTimerToZero();
                return;
            }

            SimpleDateFormat format =
                    new SimpleDateFormat(
                            "yyyy-MM-dd HH:mm:ss",
                            Locale.getDefault()
                    );

            format.setLenient(false);

            Date expiryDate;

            try {

                expiryDate =
                        format.parse(
                                expiry.trim()
                        );

            } catch (ParseException e) {

                Log.e(
                        TAG,
                        "Invalid expiry date",
                        e
                );

                setTimerToZero();
                return;
            }

            if (expiryDate == null) {

                setTimerToZero();
                return;
            }

            long distance =
                    expiryDate.getTime()
                            - System.currentTimeMillis();

            if (distance <= 0) {

                setTimerToZero();
                return;
            }

            long days =
                    distance / 86400000L;

            long hours =
                    (distance / 3600000L) % 24L;

            long minutes =
                    (distance / 60000L) % 60L;

            long seconds =
                    (distance / 1000L) % 60L;

            setTextIfNotNull(
                    tvDays,
                    String.format(
                            Locale.getDefault(),
                            "%02d",
                            days
                    )
            );

            setTextIfNotNull(
                    tvHours,
                    String.format(
                            Locale.getDefault(),
                            "%02d",
                            hours
                    )
            );

            setTextIfNotNull(
                    tvMinutes,
                    String.format(
                            Locale.getDefault(),
                            "%02d",
                            minutes
                    )
            );

            setTextIfNotNull(
                    tvSeconds,
                    String.format(
                            Locale.getDefault(),
                            "%02d",
                            seconds
                    )
            );

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Countdown error",
                    e
            );

            setTimerToZero();
        }
    }

    private void setTimerToZero() {

        setTextIfNotNull(tvDays, "00");
        setTextIfNotNull(tvHours, "00");
        setTextIfNotNull(tvMinutes, "00");
        setTextIfNotNull(tvSeconds, "00");
    }

    private void setTextIfNotNull(
            TextView view,
            String text
    ) {

        if (view != null) {

            view.setText(
                    text == null
                            ? ""
                            : text
            );
        }
    }

    @Override
    protected void onResume() {

        super.onResume();

        hideNavigationBar();

        if (timerHandler != null
                && timerRunnable != null) {

            timerHandler.removeCallbacks(
                    timerRunnable
            );

            if (!isActivityInvalid()) {

                timerHandler.post(
                        timerRunnable
                );
            }
        }
    }

    @Override
    protected void onPause() {

        if (timerHandler != null
                && timerRunnable != null) {

            timerHandler.removeCallbacks(
                    timerRunnable
            );
        }

        super.onPause();
    }

    private void setupOverlayPermission() {

        try {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    && !Settings.canDrawOverlays(this)) {

                Intent intent =
                        new Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse(
                                        "package:"
                                                + getPackageName()
                                )
                        );

                startActivity(intent);
            }

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Overlay permission error",
                    e
            );
        }
    }

    private void setupVersionViews() {

        TextView global =
                findViewById(R.id.vrglobal);

        TextView korea =
                findViewById(R.id.vrkorea);

        TextView vng =
                findViewById(R.id.vrvng);

        TextView tw =
                findViewById(R.id.vrtw);

        TextView india =
                findViewById(R.id.vrindia);

        setVersion(global);
        setVersion(korea);
        setVersion(vng);
        setVersion(tw);
        setVersion(india);
    }

    private void setVersion(TextView view) {

        if (view == null) {
            return;
        }

        String value =
                view.getText() == null
                        ? ""
                        : view.getText().toString();

        view.setText(
                value.replace(
                        "4.5.0",
                        "4.5.0"
                )
        );
    }

    private void applyPremiumAnimations() {

        new Handler(
                Looper.getMainLooper()
        ).postDelayed(() -> {

            if (isActivityInvalid()) {
                return;
            }

            View subCard =
                    findViewByName("sub_card");

            View gamesTitle =
                    findViewByName("games_list_title");

            Toolbar toolbar =
                    findViewById(R.id.toolbar);

            try {

                Animation fadeInUp =
                        AnimationUtils.loadAnimation(
                                this,
                                R.anim.fade_in_up
                        );

                Animation scaleUp =
                        AnimationUtils.loadAnimation(
                                this,
                                R.anim.scale_up
                        );

                if (toolbar != null) {
                    toolbar.startAnimation(fadeInUp);
                }

                new Handler(
                        Looper.getMainLooper()
                ).postDelayed(() -> {

                    if (isActivityInvalid()) {
                        return;
                    }

                    if (subCard != null) {

                        subCard.setVisibility(
                                View.VISIBLE
                        );

                        subCard.startAnimation(
                                scaleUp
                        );
                    }

                }, 200L);

                new Handler(
                        Looper.getMainLooper()
                ).postDelayed(() -> {

                    if (isActivityInvalid()) {
                        return;
                    }

                    if (gamesTitle != null) {

                        gamesTitle.setVisibility(
                                View.VISIBLE
                        );

                        gamesTitle.startAnimation(
                                fadeInUp
                        );
                    }

                }, 400L);

            } catch (Exception e) {

                Log.e(
                        TAG,
                        "Animation error",
                        e
                );
            }

        }, 100L);
    }

    private void openSoPicker() {

        try {

            Intent intent =
                    new Intent(
                            Intent.ACTION_GET_CONTENT
                    );

            intent.setType("*/*");

            intent.addCategory(
                    Intent.CATEGORY_OPENABLE
            );

            intent.putExtra(
                    Intent.EXTRA_MIME_TYPES,
                    new String[]{
                            "application/octet-stream",
                            "application/x-sharedlib",
                            "*/*"
                    }
            );

            startActivityForResult(
                    Intent.createChooser(
                            intent,
                            "Choose a .so file"
                    ),
                    PICK_SO_REQUEST
            );

        } catch (Exception e) {

            showToast(
                    "Unable to open file picker",
                    Toast.LENGTH_SHORT
            );
        }
    }

    private void launchOrInstallSocial(
            MaterialButton button,
            String packageName
    ) {

        if (!LogAct.Container
                || blackboxCore == null) {

            return;
        }

        if (packageName == null
                || packageName.trim().isEmpty()) {

            return;
        }

        try {

            if (isPackageInstalled(packageName)) {

                blackboxCore.launchApk(
                        packageName,
                        0
                );

            } else {

                installResult =
                        blackboxCore
                                .installPackageAsUser(
                                        packageName,
                                        0
                                );

                if (installResult != null
                        && installResult.success) {

                    if (button != null) {

                        button.setText(
                                LAUNCH_STR
                        );
                    }

                } else if (installResult != null) {

                    showToast(
                            installResult.msg,
                            Toast.LENGTH_SHORT
                    );
                }
            }

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Social application error",
                    e
            );

            showToast(
                    "Unable to install application",
                    Toast.LENGTH_SHORT
            );
        }
    }

    private void showFixObbMenu(
            View anchorView
    ) {

        if (isActivityInvalid()) {
            return;
        }

        final String[] names = {
                "Global",
                "Korea",
                "VNG",
                "Taiwan",
                "BGMI"
        };

        final int[] icons = {
                R.drawable.ic_global,
                R.drawable.ic_korea,
                R.drawable.ic_vng,
                R.drawable.ic_taiwan,
                R.drawable.ic_bgmi
        };

        AlertDialog.Builder builder =
                new AlertDialog.Builder(this);

        builder.setTitle(
                "Select OBB Fix Option"
        );

        builder.setAdapter(
                new ArrayAdapter<String>(
                        this,
                        android.R.layout.simple_list_item_1,
                        names
                ) {

                    @NonNull
                    @Override
                    public View getView(
                            int position,
                            View convertView,
                            @NonNull ViewGroup parent
                    ) {

                        View view =
                                LayoutInflater
                                        .from(getContext())
                                        .inflate(
                                                R.layout.custom_dialog_item,
                                                parent,
                                                false
                                        );

                        TextView text =
                                view.findViewById(
                                        R.id.item_text
                                );

                        ImageView icon =
                                view.findViewById(
                                        R.id.item_icon
                                );

                        if (text != null) {
                            text.setText(names[position]);
                        }

                        if (icon != null
                                && position >= 0
                                && position < icons.length) {

                            icon.setImageResource(
                                    icons[position]
                            );
                        }

                        return view;
                    }
                },
                (dialog, which) ->
                        handleObbSelection(which)
        );

        builder.setNegativeButton(
                "Cancel",
                null
        );

        try {

            builder.show();

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "OBB dialog error",
                    e
            );
        }
    }

    private void handleObbSelection(
            int position
    ) {

        if (!LogAct.Container) {
            return;
        }

        String packageName;
        String versionCode = "20325";

        switch (position) {

            case 0:
                packageName = "com.tencent.ig";
                break;

            case 1:
                packageName = "com.pubg.krmobile";
                break;

            case 2:
                packageName = "com.vng.pubgmobile";
                break;

            case 3:
                packageName = "com.rekoo.pubgm";
                break;

            case 4:
                packageName = "com.pubg.imobile";
                versionCode = "19935";
                break;

            default:
                return;
        }

        String sourcePath =
                "/storage/emulated/0/Android/obb/"
                        + packageName
                        + "/main."
                        + versionCode
                        + "."
                        + packageName
                        + ".obb";

        String destinationDirectory =
                "/storage/emulated/0/blackbox/Android/obb/"
                        + packageName;

        String destinationPath =
                destinationDirectory
                        + "/main."
                        + versionCode
                        + "."
                        + packageName
                        + ".obb";

        File destination =
                new File(destinationPath);

        if (destination.exists()) {

            showToast(
                    OBB_INSTALLED_MSG,
                    Toast.LENGTH_LONG
            );

            return;
        }

        File directory =
                new File(destinationDirectory);

        if (!directory.exists()
                && !directory.mkdirs()) {

            showToast(
                    "Unable to create OBB directory",
                    Toast.LENGTH_LONG
            );

            return;
        }

        new MyCopyTask().execute(
                sourcePath,
                packageName
        );
    }

    private class MyCopyTask
            extends AsyncTask<String, Integer, File> {

        private ProgressDialog progressDialog;
        private String errorMessage;

        @Override
        protected void onPreExecute() {

            if (isActivityInvalid()) {

                cancel(true);
                return;
            }

            progressDialog =
                    new ProgressDialog(MAct.this);

            progressDialog.setTitle(
                    "Copying OBB..."
            );

            progressDialog.setMessage(
                    "Please wait"
            );

            progressDialog.setProgressStyle(
                    ProgressDialog.STYLE_HORIZONTAL
            );

            progressDialog.setMax(100);
            progressDialog.setProgress(0);
            progressDialog.setCancelable(false);

            try {

                progressDialog.show();

            } catch (Exception e) {

                Log.e(
                        TAG,
                        "ProgressDialog error",
                        e
                );

                progressDialog = null;
            }
        }

        @Override
        protected File doInBackground(
                String... params
        ) {

            if (params == null
                    || params.length < 2) {

                errorMessage =
                        "Invalid parameters";

                return null;
            }

            File source =
                    new File(params[0]);

            String packageName =
                    params[1];

            if (!source.exists()
                    || !source.isFile()) {

                errorMessage =
                        "Source OBB not found";

                return null;
            }

            File destination =
                    new File(
                            "/storage/emulated/0/"
                                    + "blackbox/Android/obb/"
                                    + packageName
                                    + "/"
                                    + source.getName()
                    );

            File parent =
                    destination.getParentFile();

            if (parent != null
                    && !parent.exists()
                    && !parent.mkdirs()) {

                errorMessage =
                        "Unable to create destination";

                return null;
            }

            long totalBytes =
                    source.length();

            if (totalBytes <= 0) {

                errorMessage =
                        "Invalid OBB file";

                return null;
            }

            long copiedBytes = 0;

            byte[] buffer =
                    new byte[64 * 1024];

            try (
                    FileInputStream input =
                            new FileInputStream(source);

                    FileOutputStream output =
                            new FileOutputStream(destination)
            ) {

                int count;

                while (
                        (count = input.read(buffer))
                                != -1
                ) {

                    if (isCancelled()) {

                        if (destination.exists()) {
                            destination.delete();
                        }

                        return null;
                    }

                    output.write(
                            buffer,
                            0,
                            count
                    );

                    copiedBytes += count;

                    int progress =
                            (int) (
                                    copiedBytes
                                            * 100L
                                            / totalBytes
                            );

                    publishProgress(
                            Math.min(progress, 100)
                    );
                }

                output.flush();

                return destination;

            } catch (IOException e) {

                errorMessage =
                        e.getMessage();

                if (destination.exists()) {
                    destination.delete();
                }

                return null;
            }
        }

        @Override
        protected void onProgressUpdate(
                Integer... values
        ) {

            super.onProgressUpdate(values);

            if (progressDialog == null
                    || !progressDialog.isShowing()
                    || values == null
                    || values.length == 0) {

                return;
            }

            int progress = values[0];

            progressDialog.setProgress(progress);

            progressDialog.setMessage(
                    progress + "%"
            );
        }

        @Override
        protected void onPostExecute(
                File result
        ) {

            dismissProgressDialog();

            if (isActivityInvalid()) {
                return;
            }

            if (errorMessage != null) {

                showToast(
                        "Error: " + errorMessage,
                        Toast.LENGTH_LONG
                );

            } else if (result != null
                    && result.exists()) {

                showToast(
                        "OBB Copied Successfully!",
                        Toast.LENGTH_LONG
                );

            } else {

                showToast(
                        "Failed to copy OBB",
                        Toast.LENGTH_LONG
                );
            }
        }

        private void dismissProgressDialog() {

            try {

                if (progressDialog != null
                        && progressDialog.isShowing()) {

                    progressDialog.dismiss();
                }

            } catch (Exception ignored) {
            }

            progressDialog = null;
        }
    }

    private void showAppPickerDialog() {

        if (blackboxCore == null) {

            showToast(
                    "BlackBox is not ready",
                    Toast.LENGTH_SHORT
            );

            return;
        }

        List<ApplicationInfo> virtualApps =
                new ArrayList<>();

        List<ApplicationInfo> physicalApps =
                new ArrayList<>();

        try {

            List<ApplicationInfo> result =
                    blackboxCore
                            .getInstalledApplications(
                                    0,
                                    0
                            );

            if (result != null) {
                virtualApps.addAll(result);
            }

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Virtual application list error",
                    e
            );
        }

        try {

            List<ApplicationInfo> installed =
                    getPackageManager()
                            .getInstalledApplications(0);

            if (installed != null) {
                physicalApps.addAll(installed);
            }

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Physical application list error",
                    e
            );
        }

        List<String> names =
                new ArrayList<>();

        List<String> packages =
                new ArrayList<>();

        for (ApplicationInfo app : virtualApps) {

            if (app == null
                    || app.packageName == null) {
                continue;
            }

            String label =
                    getApplicationLabel(app);

            names.add(
                    "Installed  " + label
            );

            packages.add(
                    app.packageName
            );
        }

        for (ApplicationInfo app : physicalApps) {

            if (app == null
                    || app.packageName == null) {
                continue;
            }

            if ((app.flags
                    & ApplicationInfo.FLAG_SYSTEM) != 0) {
                continue;
            }

            if (packages.contains(app.packageName)) {
                continue;
            }

            String label =
                    getApplicationLabel(app);

            names.add(
                    "+ " + label
            );

            packages.add(
                    app.packageName
            );
        }

        names.add(
                "Pick APK from Storage..."
        );

        packages.add(null);

        if (names.isEmpty()) {

            showToast(
                    NO_APPS_MSG,
                    Toast.LENGTH_SHORT
            );

            return;
        }

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_list_item_1,
                        names
                );

        try {

            new AlertDialog.Builder(this)
                    .setTitle(SELECT_APP_MSG)
                    .setAdapter(
                            adapter,
                            (dialog, which) -> {

                                if (which < 0
                                        || which >= packages.size()) {
                                    return;
                                }

                                String packageName =
                                        packages.get(which);

                                if (packageName == null) {

                                    pickApkFromStorage();

                                } else {

                                    showAppOptionsDialog(
                                            packageName
                                    );
                                }
                            }
                    )
                    .setNegativeButton(
                            "Cancel",
                            null
                    )
                    .show();

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Application picker dialog error",
                    e
            );
        }
    }

    private String getApplicationLabel(
            ApplicationInfo app
    ) {

        if (app == null) {
            return "";
        }

        try {

            CharSequence label =
                    app.loadLabel(
                            getPackageManager()
                    );

            if (label != null) {

                String value =
                        label.toString();

                if (!value.trim().isEmpty()) {
                    return value;
                }
            }

        } catch (Exception ignored) {
        }

        return app.packageName == null
                ? ""
                : app.packageName;
    }

    private void showAppOptionsDialog(
            String packageName
    ) {

        if (packageName == null
                || packageName.trim().isEmpty()) {

            return;
        }

        try {

            new AlertDialog.Builder(this)
                    .setTitle(CHOOSE_ACTION_MSG)
                    .setItems(
                            new String[]{
                                    LAUNCH_STR,
                                    UNINSTALL_MSG,
                                    INSTALL_VIRTUAL_MSG
                            },
                            (dialog, which) -> {

                                switch (which) {

                                    case 0:
                                        launchApp(packageName);
                                        break;

                                    case 1:
                                        uninstallApp(packageName);
                                        break;

                                    case 2:
                                        installSelectedApp(packageName);
                                        break;

                                    default:
                                        break;
                                }
                            }
                    )
                    .setNegativeButton(
                            "Cancel",
                            null
                    )
                    .show();

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "App options dialog error",
                    e
            );
        }
    }

    private void launchApp(
            String packageName
    ) {

        if (packageName == null
                || packageName.trim().isEmpty()) {

            return;
        }

        try {

            if (blackboxCore != null
                    && blackboxCore.isInstalled(
                    packageName,
                    0
            )) {

                blackboxCore.launchApk(
                        packageName,
                        0
                );

                return;
            }

            Intent launchIntent =
                    getPackageManager()
                            .getLaunchIntentForPackage(
                                    packageName
                            );

            if (launchIntent != null) {

                launchIntent.addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK
                );

                startActivity(launchIntent);

            } else {

                showToast(
                        CANNOT_LAUNCH_MSG,
                        Toast.LENGTH_SHORT
                );
            }

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Launch error",
                    e
            );

            showToast(
                    CANNOT_LAUNCH_MSG,
                    Toast.LENGTH_SHORT
            );
        }
    }

    private void uninstallApp(
            String packageName
    ) {

        if (packageName == null
                || packageName.trim().isEmpty()) {

            return;
        }

        try {

            if (blackboxCore != null
                    && blackboxCore.isInstalled(
                    packageName,
                    0
            )) {

                blackboxCore
                        .uninstallPackageAsUser(
                                packageName,
                                0
                        );

                showToast(
                        UNINSTALLED_VIRTUAL_MSG,
                        Toast.LENGTH_SHORT
                );

            } else {

                Intent intent =
                        new Intent(
                                Intent.ACTION_DELETE
                        );

                intent.setData(
                        Uri.parse(
                                "package:" + packageName
                        )
                );

                startActivity(intent);
            }

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Uninstall error",
                    e
            );
        }
    }

    private void installSelectedApp(
            String packageName
    ) {

        if (blackboxCore == null) {
            return;
        }

        String apkPath =
                getApkPathFromPackage(
                        packageName
                );

        if (apkPath == null) {

            showToast(
                    FAILED_GET_APK_MSG,
                    Toast.LENGTH_SHORT
            );

            return;
        }

        File apkFile =
                new File(apkPath);

        if (!apkFile.exists()
                || !apkFile.isFile()
                || apkFile.length() <= 0) {

            showToast(
                    INVALID_APK_MSG,
                    Toast.LENGTH_SHORT
            );

            return;
        }

        try {

            InstallResult result =
                    blackboxCore
                            .installPackageAsUser(
                                    apkFile,
                                    0
                            );

            handleInstallResult(
                    result,
                    INSTALL_SUCCESS_MSG
            );

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Application installation error",
                    e
            );

            showToast(
                    "Installation failed",
                    Toast.LENGTH_SHORT
            );
        }
    }

    private String getApkPathFromPackage(
            String packageName
    ) {

        if (packageName == null
                || packageName.trim().isEmpty()) {

            return null;
        }

        try {

            ApplicationInfo info =
                    getPackageManager()
                            .getApplicationInfo(
                                    packageName,
                                    0
                            );

            if (info == null) {
                return null;
            }

            return info.sourceDir;

        } catch (
                PackageManager.NameNotFoundException e
        ) {

            Log.e(
                    TAG,
                    "APK path not found",
                    e
            );

            return null;
        }
    }

    private void pickApkFromStorage() {

        try {

            Intent intent =
                    new Intent(
                            Intent.ACTION_GET_CONTENT
                    );

            intent.setType(
                    "application/vnd.android.package-archive"
            );

            intent.addCategory(
                    Intent.CATEGORY_OPENABLE
            );

            startActivityForResult(
                    Intent.createChooser(
                            intent,
                            "Select APK"
                    ),
                    PICK_APK_REQUEST
            );

        } catch (Exception e) {

            showToast(
                    "Unable to open APK picker",
                    Toast.LENGTH_SHORT
            );
        }
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            @Nullable Intent data
    ) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (resultCode != RESULT_OK
                || data == null) {

            return;
        }

        Uri uri = data.getData();

        if (uri == null) {
            return;
        }

        if (requestCode == PICK_APK_REQUEST) {

            installApkFromUri(uri);

        } else if (requestCode == PICK_SO_REQUEST) {

            showToast(
                    "SO file selected",
                    Toast.LENGTH_SHORT
            );
        }
    }

    private void installApkFromUri(
            Uri apkUri
    ) {

        if (apkUri == null
                || blackboxCore == null) {

            return;
        }

        String apkPath =
                copyUriToCache(apkUri);

        if (apkPath == null) {

            showToast(
                    INVALID_APK_MSG,
                    Toast.LENGTH_SHORT
            );

            return;
        }

        File apkFile =
                new File(apkPath);

        if (!apkFile.exists()
                || !apkFile.isFile()
                || apkFile.length() <= 0) {

            showToast(
                    INVALID_APK_MSG,
                    Toast.LENGTH_SHORT
            );

            return;
        }

        try {

            InstallResult result =
                    blackboxCore
                            .installPackageAsUser(
                                    apkFile,
                                    0
                            );

            handleInstallResult(
                    result,
                    APK_INSTALLED_MSG
            );

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "APK installation error",
                    e
            );

            showToast(
                    "APK installation failed",
                    Toast.LENGTH_SHORT
            );
        }
    }

    private void handleInstallResult(
            InstallResult result,
            String successMessage
    ) {

        if (result != null
                && result.success) {

            showToast(
                    successMessage,
                    Toast.LENGTH_SHORT
            );

        } else if (result != null
                && result.msg != null
                && !result.msg.trim().isEmpty()) {

            showToast(
                    result.msg,
                    Toast.LENGTH_SHORT
            );

        } else {

            showToast(
                    INVALID_APK_MSG,
                    Toast.LENGTH_SHORT
            );
        }
    }

    private String copyUriToCache(
            Uri uri
    ) {

        if (uri == null) {
            return null;
        }

        String fileName =
                "selected_"
                        + System.currentTimeMillis()
                        + ".apk";

        Cursor cursor = null;

        try {

            cursor =
                    getContentResolver()
                            .query(
                                    uri,
                                    null,
                                    null,
                                    null,
                                    null
                            );

            if (cursor != null
                    && cursor.moveToFirst()) {

                int index =
                        cursor.getColumnIndex(
                                OpenableColumns.DISPLAY_NAME
                        );

                if (index >= 0) {

                    String displayName =
                            cursor.getString(index);

                    if (displayName != null
                            && !displayName.trim().isEmpty()) {

                        fileName =
                                new File(
                                        displayName
                                ).getName();
                    }
                }
            }

        } catch (Exception e) {

            Log.w(
                    TAG,
                    "Unable to read file name",
                    e
            );

        } finally {

            if (cursor != null) {
                cursor.close();
            }
        }

        fileName =
                new File(fileName).getName();

        if (!fileName
                .toLowerCase(Locale.ROOT)
                .endsWith(".apk")) {

            fileName += ".apk";
        }

        File destination =
                new File(
                        getCacheDir(),
                        fileName
                );

        if (destination.exists()) {

            destination =
                    new File(
                            getCacheDir(),
                            System.currentTimeMillis()
                                    + "_"
                                    + fileName
                    );
        }

        try (
                InputStream input =
                        getContentResolver()
                                .openInputStream(uri);

                FileOutputStream output =
                        new FileOutputStream(
                                destination
                        )
        ) {

            if (input == null) {
                return null;
            }

            byte[] buffer =
                    new byte[64 * 1024];

            int count;

            while (
                    (count = input.read(buffer))
                            != -1
            ) {

                output.write(
                        buffer,
                        0,
                        count
                );
            }

            output.flush();

            return destination.getAbsolutePath();

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "URI copy error",
                    e
            );

            if (destination.exists()) {
                destination.delete();
            }

            return null;
        }
    }

    private void openUrl(
            String url
    ) {

        if (url == null
                || url.trim().isEmpty()) {

            return;
        }

        try {

            Intent intent =
                    new Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse(url)
                    );

            startActivity(intent);

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Unable to open URL",
                    e
            );
        }
    }

    private void goToTelegram() {

        try {

            String url = Tele();

            if (url == null
                    || url.trim().isEmpty()) {

                return;
            }

            openUrl(url);

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Telegram error",
                    e
            );
        }
    }

    private void startFloater() {

        if (!isActivityValid()) {
            return;
        }

        try {

            Intent serviceIntent =
                    new Intent(
                            getApplicationContext(),
                            FourService.class
                    );

            if (Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.O) {

                startForegroundService(
                        serviceIntent
                );

            } else {

                startService(
                        serviceIntent
                );
            }

            try {

                loadAssets();

            } catch (Exception e) {

                Log.e(
                        TAG,
                        "loadAssets failed",
                        e
                );
            }

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Unable to start floater",
                    e
            );

            showToast(
                    "Unable to start service",
                    Toast.LENGTH_SHORT
            );
        }
    }

    private void stopFloating() {

        try {

            stopService(
                    new Intent(
                            this,
                            Overlay.class
                    )
            );

            stopService(
                    new Intent(
                            this,
                            FourService.class
                    )
            );

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Unable to stop floater",
                    e
            );
        }
    }

    private void installGame(
            MaterialButton button,
            String packageName
    ) {

        if (!LogAct.Container) {
            return;
        }

        if (blackboxCore == null) {

            showToast(
                    "BlackBox is not ready",
                    Toast.LENGTH_SHORT
            );

            return;
        }

        if (packageName == null
                || packageName.trim().isEmpty()) {

            return;
        }

        try {

            if (isPackageInstalled(packageName)) {

                blackboxCore.launchApk(
                        packageName,
                        0
                );

                startFloater();

                return;
            }

            installResult =
                    blackboxCore
                            .installPackageAsUser(
                                    packageName,
                                    0
                            );

            if (installResult != null
                    && installResult.success) {

                if (button != null) {

                    button.setText(
                            LAUNCH_STR
                    );
                }

                showToast(
                        INSTALL_SUCCESS_MSG,
                        Toast.LENGTH_SHORT
                );

            } else if (installResult != null) {

                showToast(
                        installResult.msg,
                        Toast.LENGTH_SHORT
                );

            } else {

                showToast(
                        "Unable to install application",
                        Toast.LENGTH_SHORT
                );
            }

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Game installation error",
                    e
            );

            showToast(
                    "Unable to install or launch game",
                    Toast.LENGTH_SHORT
            );
        }
    }

    private boolean isPackageInstalled(
            String packageName
    ) {

        if (blackboxCore == null
                || packageName == null
                || packageName.trim().isEmpty()) {

            return false;
        }

        try {

            return blackboxCore.isInstalled(
                    packageName,
                    0
            );

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Package check error",
                    e
            );

            return false;
        }
    }

    public void loadAssets() {

        String filePath =
                Environment
                        .getExternalStorageDirectory()
                        + "/Android/data/.tyb";

        FileOutputStream output = null;

        try {

            File file =
                    new File(filePath);

            File parent =
                    file.getParentFile();

            if (parent != null
                    && !parent.exists()) {

                parent.mkdirs();
            }

            output =
                    new FileOutputStream(file);

            byte[] data =
                    DO_NOT_DELETE_STR.getBytes();

            output.write(
                    data,
                    0,
                    data.length
            );

            output.flush();

        } catch (FileNotFoundException e) {

            Log.e(
                    TAG,
                    "Asset file error",
                    e
            );

        } catch (IOException e) {

            Log.e(
                    TAG,
                    "Asset write error",
                    e
            );

        } finally {

            if (output != null) {

                try {
                    output.close();
                } catch (IOException ignored) {
                }
            }
        }

        daemonPath =
                new File(
                        getFilesDir(),
                        "socu64"
                ).getAbsolutePath();

        try {

            if (LogAct.isRootGiven()) {

                socket =
                        "su -c "
                                + daemonPath;

            } else {

                socket = daemonPath;
            }

        } catch (Exception e) {

            socket = daemonPath;
        }

        try {

            Runtime.getRuntime().exec(
                    new String[]{
                            "sh",
                            "-c",
                            "chmod 777 \""
                                    + daemonPath
                                    + "\""
                    }
            );

        } catch (IOException e) {

            Log.w(
                    TAG,
                    "chmod failed",
                    e
            );
        }
    }

    private void makeDirectories() {

        String base =
                "/storage/emulated/0/"
                        + "blackbox/Android/obb/";

        String[] packages = {
                "com.tencent.ig",
                "com.pubg.krmobile",
                "com.pubg.imobile",
                "com.vng.pubgmobile",
                "com.rekoo.pubgm"
        };

        for (String packageName : packages) {

            if (packageName == null) {
                continue;
            }

            try {

                File folder =
                        new File(
                                base + packageName
                        );

                if (!folder.exists()) {
                    folder.mkdirs();
                }

            } catch (Exception e) {

                Log.w(
                        TAG,
                        "Unable to create directory",
                        e
                );
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == STORAGE_PERMISSION
                && !hasAllPermissionsGranted(
                grantResults
        )) {

            showToast(
                    "Unable To Get Storage Permission",
                    Toast.LENGTH_SHORT
            );
        }
    }

    private boolean hasAllPermissionsGranted(
            @NonNull int[] results
    ) {

        if (results.length == 0) {
            return false;
        }

        for (int result : results) {

            if (result
                    == PackageManager.PERMISSION_DENIED) {

                return false;
            }
        }

        return true;
    }

    private void runShell(
            String command
    ) {

        if (command == null
                || command.trim().isEmpty()) {

            return;
        }

        try {

            Runtime.getRuntime().exec(
                    new String[]{
                            "sh",
                            "-c",
                            command
                    }
            );

        } catch (IOException e) {

            Log.e(
                    TAG,
                    "Shell execution failed",
                    e
            );
        }
    }

    @Override
    public boolean onMenuOpened(
            int featureId,
            Menu menu
    ) {

        if (menu != null
                && equalsSafe(
                menu.getClass()
                        .getSimpleName(),
                MENU_BUILDER_CLASS
        )) {

            try {

                Method method =
                        menu.getClass()
                                .getDeclaredMethod(
                                        SET_OPTIONAL_ICONS_VISIBLE,
                                        boolean.class
                                );

                method.setAccessible(true);

                method.invoke(
                        menu,
                        true
                );

            } catch (Exception e) {

                Log.e(
                        TAG,
                        "Menu icon error",
                        e
                );
            }
        }

        return super.onMenuOpened(
                featureId,
                menu
        );
    }

    @Override
    public boolean onCreateOptionsMenu(
            Menu menu
    ) {

        try {

            MenuInflater inflater =
                    getMenuInflater();

            inflater.inflate(
                    R.menu.main_menu,
                    menu
            );

            return true;

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Unable to create options menu",
                    e
            );

            return super.onCreateOptionsMenu(
                    menu
            );
        }
    }

    @Override
    public boolean onOptionsItemSelected(
            MenuItem item
    ) {

        if (item == null) {
            return super.onOptionsItemSelected(item);
        }

        return super.onOptionsItemSelected(item);
    }

    private boolean detectTamperingTools() {

        boolean detected = false;

        try {

            if (Debug.isDebuggerConnected()
                    || Debug.waitingForDebugger()) {

                Log.w(
                        TAG,
                        "Debugger detected"
                );

                detected = true;
            }

        } catch (Exception e) {

            Log.w(
                    TAG,
                    "Debugger check failed",
                    e
            );
        }

        try {

            String fingerprint =
                    Build.FINGERPRINT == null
                            ? ""
                            : Build.FINGERPRINT;

            String model =
                    Build.MODEL == null
                            ? ""
                            : Build.MODEL;

            String product =
                    Build.PRODUCT == null
                            ? ""
                            : Build.PRODUCT;

            String board =
                    Build.BOARD == null
                            ? ""
                            : Build.BOARD;

            boolean emulator =
                    fingerprint.startsWith("generic")
                            || model.contains("google_sdk")
                            || model.contains("Emulator")
                            || product.contains("sdk")
                            || board.contains("goldfish");

            if (emulator) {

                Log.w(
                        TAG,
                        "Emulator detected"
                );

                detected = true;
            }

        } catch (Exception e) {

            Log.w(
                    TAG,
                    "Emulator check failed",
                    e
            );
        }

        String[] suspiciousPaths = {
                "/sbin/su",
                "/system/bin/su",
                "/system/xbin/su",
                "/data/local/tmp/frida-server",
                "/data/local/tmp/frida"
        };

        for (String path : suspiciousPaths) {

            try {

                if (new File(path).exists()) {

                    Log.w(
                            TAG,
                            "Suspicious file detected: "
                                    + path
                    );

                    detected = true;
                }

            } catch (Exception ignored) {
            }
        }

        return detected;
    }

    private void triggerSecurityCrash(
            String reason
    ) {

        Log.w(
                TAG,
                "Security check warning: " + reason
        );
    }

    private void performSecurityCheck() {

        if (securityCheckDone) {
            return;
        }

        securityCheckDone = true;

        try {

            if (detectTamperingTools()) {

                triggerSecurityCrash(
                        "ENVIRONMENT_CHECK"
                );
            }

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Security check failed",
                    e
            );
        }
    }

    private void showToast(
            String message,
            int duration
    ) {

        if (message == null
                || message.trim().isEmpty()) {

            return;
        }

        try {

            Toast.makeText(
                    getApplicationContext(),
                    message,
                    duration
            ).show();

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Toast error",
                    e
            );
        }
    }

    private boolean isActivityValid() {

        if (isFinishing()) {
            return false;
        }

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.JELLY_BEAN_MR1
                && isDestroyed()) {

            return false;
        }

        return true;
    }

    private boolean isActivityInvalid() {
        return !isActivityValid();
    }

    private boolean isDestroyedCompat() {

        if (Build.VERSION.SDK_INT
                >= Build.VERSION_CODES.JELLY_BEAN_MR1) {

            return isDestroyed();
        }

        return false;
    }

    @Override
    protected void onDestroy() {

        if (timerHandler != null
                && timerRunnable != null) {

            timerHandler.removeCallbacks(
                    timerRunnable
            );

            timerHandler = null;
            timerRunnable = null;
        }

        countdownStarted = false;

        try {

            stopService(
                    new Intent(
                            this,
                            Overlay.class
                    )
            );

            stopService(
                    new Intent(
                            this,
                            FourService.class
                    )
            );

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Service cleanup error",
                    e
            );
        }

        super.onDestroy();
    }
}
package pubgm.loader.utils;
import android.content.Context;
import android.widget.Toast;
import android.view.LayoutInflater;
import android.app.Activity;
import android.view.ViewGroup;
import android.view.View;
import android.widget.TextView;
import android.view.Gravity;
import pubgm.loader.R;

public class Tmes {
    private Context context;
	
    private Tmes(Context context) {
        this.context = context;
    }
    public synchronized static Tmes getInstance(Context context) {
        return new Tmes(context);
    }
    
    public void sToas(String message) {
        LayoutInflater inflater = ((Activity) context).getLayoutInflater();
        View layout = inflater.inflate(R.layout.toastt, (ViewGroup) ((Activity) context).findViewById(R.id.toastroot));
        TextView msgTv = (TextView) layout.findViewById(R.id.txttoast);
         msgTv.setText(message);
        Toast toast = new Toast(context);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(layout);
        toast.show();
		
    }

}
    




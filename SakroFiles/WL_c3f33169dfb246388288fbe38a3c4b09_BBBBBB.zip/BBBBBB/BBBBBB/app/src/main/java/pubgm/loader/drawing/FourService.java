package pubgm.loader.drawing;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.view.View;
import android.os.PowerManager;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.content.Context;
import android.view.LayoutInflater;
import pubgm.loader.R;
import android.view.View.OnClickListener;
import android.view.MotionEvent;
import android.view.Gravity;
import android.graphics.PixelFormat;
import android.os.Build;
import android.widget.Toast;
import android.widget.ImageView;
import android.graphics.Color;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.SharedPreferences;
import android.widget.Switch;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.CheckBox;
import android.content.pm.PackageManager;
import android.app.ActivityManager;

import java.util.List;

import pubgm.loader.utils.myTools;
import android.view.Display;
import pubgm.loader.LogAct;
import pubgm.loader.MAct;
import android.os.Handler;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import android.os.Environment;
import android.os.Looper;
import pubgm.loader.utils.LocaleHelper;

public class FourService extends Service {

    static {
        System.loadLibrary("ayan");
    }

    private static native void main();

    private View mainView;
    private PowerManager.WakeLock mWakeLock;
    private WindowManager windowManagerMainView;
    private WindowManager.LayoutParams paramsMainView;
    private RelativeLayout layout_main_view;
    private RelativeLayout layout_icon_control_view;
    private TextView logoText;

    static Context ctx;

    public native void SettingValue(int setting_code, boolean value);
    public native void SettingMemory(int setting_code, boolean value);
    public native void SettingInt(int setting_code, int value);
    public native void WideView(int wideview);

    myTools m = new myTools(this);

    static int fps;

    @Override
    public IBinder onBind(Intent p1) {
        return null;
    }

    @Override
    public void onCreate() {
        LocaleHelper.applySavedLocale(this);

        super.onCreate();

        setTheme(m.geInt("myTheme", "myTheme", R.style.AppTheme));

        ctx = getApplicationContext();

        ShowMainView();
    }

    private void ShowMainView() {

        mainView = LayoutInflater.from(this).inflate(R.layout.service_four, null);

        paramsMainView =
                new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        getLayoutType(),
                        getFlagsType(),
                        PixelFormat.TRANSLUCENT);

        paramsMainView.gravity = Gravity.CENTER | Gravity.CENTER;
        paramsMainView.x = 0;
        paramsMainView.y = 0;

        if (MAct.Record) {
            HideRecorder.setFakeRecorderWindowLayoutParams(paramsMainView);
        }

        windowManagerMainView =
                (WindowManager) getSystemService(WINDOW_SERVICE);

        windowManagerMainView.addView(mainView, paramsMainView);

        InitShowMainView();
    }

    public static boolean isAppRunning(final String packageName) {

        final ActivityManager activityManager =
                (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);

        if (activityManager == null) {
            return false;
        }

        final List<ActivityManager.RunningAppProcessInfo> procInfos =
                activityManager.getRunningAppProcesses();

        if (procInfos != null) {

            for (final ActivityManager.RunningAppProcessInfo processInfo : procInfos) {

                if (processInfo.processName.equals(packageName)) {
                    return true;
                }
            }
        }

        return false;
    }

    /*
     * حل مشكلة IDs غير الموجودة في R.id
     *
     * بدل:
     * R.id.sdkunsafe
     *
     * نبحث عن ID بالاسم.
     *
     * إذا كان موجوداً في XML يرجع الـ ID.
     * إذا لم يكن موجوداً يرجع 0.
     */
    private int getViewId(String name) {

        return getResources().getIdentifier(
                name,
                "id",
                getPackageName()
        );
    }

    private <T extends View> T findOptionalView(String name) {

        int id = getViewId(name);

        if (id == 0 || mainView == null) {
            return null;
        }

        return mainView.findViewById(id);
    }

    private void InitShowMainView() {

        layout_icon_control_view =
                mainView.findViewById(R.id.rl2);

        layout_main_view =
                mainView.findViewById(R.id.rl3);

        LinearLayout layout_close_main_view =
                mainView.findViewById(R.id.ln1);

        if (layout_close_main_view != null) {

            layout_close_main_view.setOnClickListener(
                    new OnClickListener() {

                        @Override
                        public void onClick(View p1) {

                            if (layout_main_view != null) {
                                layout_main_view.setVisibility(View.GONE);
                            }

                            if (layout_icon_control_view != null) {
                                layout_icon_control_view.setVisibility(View.VISIBLE);
                            }
                        }
                    });
        }

        RelativeLayout layout_view =
                mainView.findViewById(R.id.rl1);

        if (layout_view != null) {
            layout_view.setOnTouchListener(onTouchListener());
        }

        final ImageView menu1 =
                mainView.findViewById(R.id.img1);

        final ScrollView lay1 =
                mainView.findViewById(R.id.layout_menu1);

        final ImageView menu2 =
                mainView.findViewById(R.id.img2);

        final ScrollView lay2 =
                mainView.findViewById(R.id.layout_menu2);

        final ImageView menu3 =
                mainView.findViewById(R.id.img3);

        final ScrollView lay3 =
                mainView.findViewById(R.id.layout_menu3);

        final ImageView menu4 =
                mainView.findViewById(R.id.img4);

        final ScrollView lay4 =
                mainView.findViewById(R.id.layout_menu4);

        final ImageView menu5 =
                mainView.findViewById(R.id.img5);

        final ScrollView lay5 =
                mainView.findViewById(R.id.layout_menu5);

        final TextView title =
                mainView.findViewById(R.id.tv1);

        if (title != null) {
            title.setText(getString(R.string.Display));
        }

        View.OnClickListener cmnu =
                new OnClickListener() {

                    @Override
                    public void onClick(View p1) {

                        switch (p1.getId()) {

                            case R.id.img1:

                                if (title != null) {
                                    title.setText(getString(R.string.Display));
                                }

                                laymenu(
                                        menu1,
                                        menu2,
                                        menu3,
                                        menu4,
                                        menu5,
                                        lay1,
                                        lay2,
                                        lay3,
                                        lay4,
                                        lay5
                                );

                                break;

                            case R.id.img2:

                                if (title != null) {
                                    title.setText(getString(R.string.Items));
                                }

                                laymenu(
                                        menu2,
                                        menu1,
                                        menu3,
                                        menu4,
                                        menu5,
                                        lay2,
                                        lay1,
                                        lay3,
                                        lay4,
                                        lay5
                                );

                                break;

                            case R.id.img3:

                                if (title != null) {
                                    title.setText(getString(R.string.Control));
                                }

                                laymenu(
                                        menu3,
                                        menu2,
                                        menu1,
                                        menu4,
                                        menu5,
                                        lay3,
                                        lay2,
                                        lay1,
                                        lay4,
                                        lay5
                                );

                                break;

                            case R.id.img4:

                                if (title != null) {
                                    title.setText(getString(R.string.Memory));
                                }

                                laymenu(
                                        menu4,
                                        menu2,
                                        menu3,
                                        menu1,
                                        menu5,
                                        lay4,
                                        lay2,
                                        lay3,
                                        lay1,
                                        lay5
                                );

                                break;

                            case R.id.img5:

                                if (title != null) {
                                    title.setText(getString(R.string.Misc));
                                }

                                laymenu(
                                        menu5,
                                        menu2,
                                        menu3,
                                        menu4,
                                        menu1,
                                        lay5,
                                        lay2,
                                        lay3,
                                        lay4,
                                        lay1
                                );

                                break;
                        }
                    }
                };

        if (menu1 != null) menu1.setOnClickListener(cmnu);
        if (menu2 != null) menu2.setOnClickListener(cmnu);
        if (menu3 != null) menu3.setOnClickListener(cmnu);
        if (menu4 != null) menu4.setOnClickListener(cmnu);
        if (menu5 != null) menu5.setOnClickListener(cmnu);

        final LinearLayout navitem1 =
                mainView.findViewById(R.id.navitem1);

        final LinearLayout navitem2 =
                mainView.findViewById(R.id.navitem2);

        final LinearLayout navitem3 =
                mainView.findViewById(R.id.navitem3);

        final LinearLayout navitem4 =
                mainView.findViewById(R.id.navitem4);

        final LinearLayout lay_item1 =
                mainView.findViewById(R.id.lay_item1);

        final LinearLayout lay_item2 =
                mainView.findViewById(R.id.lay_item2);

        final LinearLayout lay_item3 =
                mainView.findViewById(R.id.lay_item3);

        final LinearLayout lay_item4 =
                mainView.findViewById(R.id.lay_item4);

        final TextView navtxtitem1 =
                mainView.findViewById(R.id.navtxtitem1);

        final TextView navtxtitem2 =
                mainView.findViewById(R.id.navtxtitem2);

        final TextView navtxtitem3 =
                mainView.findViewById(R.id.navtxtitem3);

        final TextView navtxtitem4 =
                mainView.findViewById(R.id.navtxtitem4);

        View.OnClickListener cnavitem =
                new OnClickListener() {

                    @Override
                    public void onClick(View p1) {

                        switch (p1.getId()) {

                            case R.id.navitem1:

                                navitem(
                                        navitem1,
                                        navitem2,
                                        navitem3,
                                        navitem4,
                                        lay_item1,
                                        lay_item2,
                                        lay_item3,
                                        lay_item4,
                                        navtxtitem1,
                                        navtxtitem2,
                                        navtxtitem3,
                                        navtxtitem4
                                );

                                break;

                            case R.id.navitem2:

                                navitem(
                                        navitem2,
                                        navitem1,
                                        navitem3,
                                        navitem4,
                                        lay_item2,
                                        lay_item1,
                                        lay_item3,
                                        lay_item4,
                                        navtxtitem2,
                                        navtxtitem1,
                                        navtxtitem3,
                                        navtxtitem4
                                );

                                break;

                            case R.id.navitem3:

                                navitem(
                                        navitem3,
                                        navitem2,
                                        navitem1,
                                        navitem4,
                                        lay_item3,
                                        lay_item2,
                                        lay_item1,
                                        lay_item4,
                                        navtxtitem3,
                                        navtxtitem2,
                                        navtxtitem1,
                                        navtxtitem4
                                );

                                break;

                            case R.id.navitem4:

                                navitem(
                                        navitem4,
                                        navitem2,
                                        navitem3,
                                        navitem1,
                                        lay_item4,
                                        lay_item2,
                                        lay_item3,
                                        lay_item1,
                                        navtxtitem4,
                                        navtxtitem2,
                                        navtxtitem3,
                                        navtxtitem1
                                );

                                break;
                        }
                    }
                };

        if (navitem1 != null) navitem1.setOnClickListener(cnavitem);
        if (navitem2 != null) navitem2.setOnClickListener(cnavitem);
        if (navitem3 != null) navitem3.setOnClickListener(cnavitem);
        if (navitem4 != null) navitem4.setOnClickListener(cnavitem);

        /*
         * FIX:
         * sdkunsafe غير موجود في R.id.
         *
         * نستخدم البحث بالاسم حتى لا يفشل compile.
         */
        LinearLayout sdkunsafe =
                findOptionalView("sdkunsafe");

        if (menu3 != null) {
            menu3.setVisibility(View.GONE);
        }

        if (sdkunsafe != null) {
            sdkunsafe.setVisibility(View.GONE);
        }

        Switch island =
                mainView.findViewById(R.id.island);

        if (island != null) {

            island.setOnCheckedChangeListener(
                    new Switch.OnCheckedChangeListener() {

                        @Override
                        public void onCheckedChanged(
                                CompoundButton p1,
                                boolean isChecked) {

                            if (isChecked) {

                                if (LogAct.Container == true) {
                                    runant("/ayan 5");
                                }

                            } else {

                                runant("/ayan 6");
                            }
                        }
                    });
        }

        /*
         * FIX:
         * rangewide و rangetextwide غير موجودين في R.id.
         */
        final SeekBar wideviewSeekBar =
                findOptionalView("rangewide");

        final TextView wideviewText =
                findOptionalView("rangetextwide");

        if (wideviewSeekBar != null && wideviewText != null) {

            setupSeekBar(
                    wideviewSeekBar,
                    wideviewText,
                    getwideview(),
                    new Runnable() {

                        @Override
                        public void run() {

                            WideView(
                                    wideviewSeekBar.getProgress()
                            );

                            getwideview(
                                    wideviewSeekBar.getProgress()
                            );
                        }
                    }
            );
        }

        final Switch ismagic2 =
                mainView.findViewById(R.id.MagicBullet);

        if (ismagic2 != null) {

            ismagic2.setOnCheckedChangeListener(
                    new CompoundButton.OnCheckedChangeListener() {

                        @Override
                        public void onCheckedChanged(
                                CompoundButton buttonView,
                                boolean isChecked) {

                            if (isChecked) {
                                // reserved
                            }
                        }
                    });
        }

        final Switch isEnable =
                mainView.findViewById(R.id.isEnable);

        if (isEnable != null) {

            isEnable.setVisibility(View.VISIBLE);
            isEnable.setChecked(false);

            isEnable.setOnCheckedChangeListener(
                    new CompoundButton.OnCheckedChangeListener() {

                        @Override
                        public void onCheckedChanged(
                                CompoundButton p1,
                                boolean isChecked) {

                            if (isChecked) {

                                startService(
                                        new Intent(
                                                ctx,
                                                Overlay.class
                                        )
                                );

                            } else {

                                stopService(
                                        new Intent(
                                                ctx,
                                                Overlay.class
                                        )
                                );
                            }
                        }
                    });
        }

        final Switch isLine =
                mainView.findViewById(R.id.isLine);

        if (isLine != null) {
            fitesp(isLine, 2, "isLine");
        }

        final Switch isBox =
                mainView.findViewById(R.id.isBox);

        if (isBox != null) {
            fitesp(isBox, 3, "isBox");
        }

        final Switch isName =
                mainView.findViewById(R.id.isName);

        if (isName != null) {
            fitesp(isName, 7, "isName");
        }

        final Switch isSkeleton =
                mainView.findViewById(R.id.isSkeleton);

        if (isSkeleton != null) {
            fitesp(isSkeleton, 4, "isSkeleton");
        }

        final Switch isHead =
                mainView.findViewById(R.id.isHead);

        if (isHead != null) {
            fitesp(isHead, 8, "isHead");
        }

        final Switch isDistance =
                mainView.findViewById(R.id.isDistance);

        if (isDistance != null) {
            fitesp(isDistance, 5, "isDistance");
        }

        final Switch isWpText =
                mainView.findViewById(R.id.isWpText);

        if (isWpText != null) {
            fitesp(isWpText, 20, "isWpText");
        }

        final Switch isWpImage =
                mainView.findViewById(R.id.isWpImage);

        if (isWpImage != null) {
            fitesp(isWpImage, 10, "isWpImage");
        }

        final Switch isAlert360 =
                mainView.findViewById(R.id.isAlert360);

        if (isAlert360 != null) {
            fitesp(isAlert360, 9, "isAlert360");
        }

        final Switch isWarnGranade =
                mainView.findViewById(R.id.isWarnGranade);

        if (isWarnGranade != null) {
            fitesp(isWarnGranade, 11, "isWarnGranade");
        }

        final Switch isHelath =
                mainView.findViewById(R.id.isHelath);

        if (isHelath != null) {
            fitesp(isHelath, 6, "isHelath");
        }

        final Switch isHidenAi =
                mainView.findViewById(R.id.isHidenAi);

        if (isHidenAi != null) {
            fitesp(isHidenAi, 29, "isHidenAi");
        }

        final Switch isSmallCross =
                mainView.findViewById(R.id.isSmallCross);

        if (isSmallCross != null) {
            fitsdk(isSmallCross, 6, "isSmallCross");
        }

        final Switch isAimKnock =
                mainView.findViewById(R.id.isAimKnock);

        if (isAimKnock != null) {
            fitesp(isAimKnock, 14, "isAimKnock");
        }

        final Switch isAimIgronebot =
                mainView.findViewById(R.id.isAimIgronebot);

        if (isAimIgronebot != null) {

            isAimIgronebot.setChecked(true);

            fitesp(
                    isAimIgronebot,
                    28,
                    "isAimIgronebot"
            );
        }

        final SeekBar radiusaim =
                mainView.findViewById(R.id.radiusaim);

        final TextView intradius =
                mainView.findViewById(R.id.intradius);

        if (radiusaim != null && intradius != null) {
            fitsekbar(
                    radiusaim,
                    intradius,
                    "radiusaim"
            );
        }

        final SeekBar distaim =
                mainView.findViewById(R.id.distaim);

        final TextView intdistaim =
                mainView.findViewById(R.id.intdistaim);

        if (distaim != null && intdistaim != null) {

            fitsekbar(
                    distaim,
                    intdistaim,
                    "distaim"
            );

            distaim.setProgress(
                    getEspValue("distaim", 100)
            );
        }

        SeekBar recoilaim =
                mainView.findViewById(R.id.recoilaim);

        final TextView intrecoil =
                mainView.findViewById(R.id.intrecoil);

        if (recoilaim != null && intrecoil != null) {

            fitsekbar(
                    recoilaim,
                    intrecoil,
                    "recoilaim"
            );
        }

        SeekBar predictaim =
                mainView.findViewById(R.id.predictaim);

        final TextView intpredict =
                mainView.findViewById(R.id.intpredict);

        if (predictaim != null && intpredict != null) {

            fitsekbar(
                    predictaim,
                    intpredict,
                    "predictaim"
            );
        }

        final RadioGroup aimtarget =
                mainView.findViewById(R.id.aimtarget);

        if (aimtarget != null) {
            Radio3(aimtarget, "aimtarget");
        }

        final RadioGroup aimpriority =
                mainView.findViewById(R.id.aimpriority);

        if (aimpriority != null) {
            Radio3(aimpriority, "aimpriority");
        }

        final RadioGroup aimmode =
                mainView.findViewById(R.id.aimmode);

        if (aimmode != null) {
            Radio3(aimmode, "aimmode");
        }

        final SeekBar linethicknes =
                mainView.findViewById(R.id.linethicknes);

        final TextView intline =
                mainView.findViewById(R.id.intline);

        if (linethicknes != null && intline != null) {

            fitsekbar(
                    linethicknes,
                    intline,
                    "linethicknes"
            );
        }

        /*
         * FIX:
         * boxthick و intbox غير موجودين في R.id.
         */
        final SeekBar boxthick =
                findOptionalView("boxthick");

        final TextView intbox =
                findOptionalView("intbox");

        if (boxthick != null && intbox != null) {

            fitsekbar(
                    boxthick,
                    intbox,
                    "boxthick"
            );
        }

        /*
         * FIX:
         * skelthick و intskel غير موجودين في R.id.
         */
        final SeekBar skelthick =
                findOptionalView("skelthick");

        final TextView intskel =
                findOptionalView("intskel");

        if (skelthick != null && intskel != null) {

            fitsekbar(
                    skelthick,
                    intskel,
                    "skelthick"
            );
        }

        final RadioGroup boxdisplay =
                mainView.findViewById(R.id.boxdisplay);

        if (boxdisplay != null) {
            Radio3(boxdisplay, "boxdisplay");
        }

        final RadioGroup alertdisplay =
                mainView.findViewById(R.id.alertdisplay);

        if (alertdisplay != null) {
            Radio3(alertdisplay, "alertdisplay");
        }

        final RadioGroup countdisplay =
                mainView.findViewById(R.id.countdisplay);

        if (countdisplay != null) {
            Radio3(countdisplay, "countdisplay");
        }

        final RadioGroup itemdisplay =
                mainView.findViewById(R.id.itemdisplay);

        if (itemdisplay != null) {
            Radio3(itemdisplay, "itemdisplay");
        }

        /*
         * Items
         */

        fititemvehicle(R.id.is12guage);
        fititemvehicle(R.id.is2x);
        fititemvehicle(R.id.is300magnum);
        fititemvehicle(R.id.is3x);
        fititemvehicle(R.id.is45acp);
        fititemvehicle(R.id.is4x);
        fititemvehicle(R.id.is50bmg);
        fititemvehicle(R.id.is556mm);
        fititemvehicle(R.id.is6x);
        fititemvehicle(R.id.is762mm);
        fititemvehicle(R.id.is8x);
        fititemvehicle(R.id.is9mm);
        fititemvehicle(R.id.isairdrop);
        fititemvehicle(R.id.isAKM);
        fititemvehicle(R.id.isamr);
        fititemvehicle(R.id.isandrenaline);
        fititemvehicle(R.id.isanglegrip);
        fititemvehicle(R.id.isarcompe);
        fititemvehicle(R.id.isarrow);
        fititemvehicle(R.id.isASMAR);
        fititemvehicle(R.id.isatv1);
        fititemvehicle(R.id.isAug);
        fititemvehicle(R.id.isawm);
        fititemvehicle(R.id.isbags1);
        fititemvehicle(R.id.isbags2);
        fititemvehicle(R.id.isbags3);
        fititemvehicle(R.id.isbandage);
        fititemvehicle(R.id.isbike);
        fititemvehicle(R.id.isBizon);
        fititemvehicle(R.id.isboat);
        fititemvehicle(R.id.isbrdm);
        fititemvehicle(R.id.isBuggy);
        fititemvehicle(R.id.isbulletloop);
        fititemvehicle(R.id.isbus);
        fititemvehicle(R.id.iscanted);
        fititemvehicle(R.id.iscapsule);
        fititemvehicle(R.id.iscapsuleitem);
        fititemvehicle(R.id.ischeeckpad);
        fititemvehicle(R.id.ischoke);
        fititemvehicle(R.id.iscoperb);
        fititemvehicle(R.id.iscrate);
        fititemvehicle(R.id.iscrosbow);
        fititemvehicle(R.id.iscrowbar);
        fititemvehicle(R.id.isdacia);
        fititemvehicle(R.id.isdbs);
        fititemvehicle(R.id.isdesserteagle);
        fititemvehicle(R.id.isDp28);
        fititemvehicle(R.id.isdropplane);
        fititemvehicle(R.id.isduckbill);
        fititemvehicle(R.id.isenergydrink);
        fititemvehicle(R.id.isexar);
        fititemvehicle(R.id.isExplosiveBow);
        fititemvehicle(R.id.isexqdar);
        fititemvehicle(R.id.isexqdsmg);
        fititemvehicle(R.id.isexqdsniper);
        fititemvehicle(R.id.isexsmg);
        fititemvehicle(R.id.isexsniper);
        fititemvehicle(R.id.isfalregun);
        fititemvehicle(R.id.isFAMAS);
        fititemvehicle(R.id.isfirstaid);
        fititemvehicle(R.id.isflashhiderar);
        fititemvehicle(R.id.isflashhidersmg);
        fititemvehicle(R.id.isflashhidersnip);
        fititemvehicle(R.id.isG36C);
        fititemvehicle(R.id.isgascan);
        fititemvehicle(R.id.isghilliesuit);
        fititemvehicle(R.id.isgranade);
        fititemvehicle(R.id.isGroza);
        fititemvehicle(R.id.ishalfgrip);
        fititemvehicle(R.id.ishangglider);
        fititemvehicle(R.id.ishelm1);
        fititemvehicle(R.id.ishelm2);
        fititemvehicle(R.id.ishelm3);
        fititemvehicle(R.id.ishollow);
        fititemvehicle(R.id.isHoneyBadger);
        fititemvehicle(R.id.isinjecti);
        fititemvehicle(R.id.isjet);
        fititemvehicle(R.id.iskar98k);
        fititemvehicle(R.id.isladaniva);
        fititemvehicle(R.id.islasersight);
        fititemvehicle(R.id.islightgrip);
        fititemvehicle(R.id.isM1014);
        fititemvehicle(R.id.isM16A4);
        fititemvehicle(R.id.ism24);
        fititemvehicle(R.id.isM249);
        fititemvehicle(R.id.isM416);
        fititemvehicle(R.id.isM762);
        fititemvehicle(R.id.ismachete);
        fititemvehicle(R.id.ismedkit);
        fititemvehicle(R.id.isMg3);
        fititemvehicle(R.id.ismini14);
        fititemvehicle(R.id.ismirado);
        fititemvehicle(R.id.ismk12);
        fititemvehicle(R.id.ismk14);
        fititemvehicle(R.id.isMK47);
        fititemvehicle(R.id.ismolotov);
        fititemvehicle(R.id.ismonster);
        fititemvehicle(R.id.ismosin);
        fititemvehicle(R.id.ismotorglider);
        fititemvehicle(R.id.isMp5k);
        fititemvehicle(R.id.isnowmobile);
        fititemvehicle(R.id.isns2000);
        fititemvehicle(R.id.isp18c);
        fititemvehicle(R.id.isp1911);
        fititemvehicle(R.id.isP90);
        fititemvehicle(R.id.isp92);
        fititemvehicle(R.id.ispainkiller);
        fititemvehicle(R.id.ispan);
        fititemvehicle(R.id.isqbu);
        fititemvehicle(R.id.isQBZ);
        fititemvehicle(R.id.isqdar);
        fititemvehicle(R.id.isqdsmg);
        fititemvehicle(R.id.isqdsniper);
        fititemvehicle(R.id.isquivercrossbow);
        fititemvehicle(R.id.isr1895);
        fititemvehicle(R.id.isr45);
        fititemvehicle(R.id.isreddot);
        fititemvehicle(R.id.isrony);
        fititemvehicle(R.id.iss12k);
        fititemvehicle(R.id.iss1897);
        fititemvehicle(R.id.iss686);
        fititemvehicle(R.id.issawedoff);
        fititemvehicle(R.id.isScarL);
        fititemvehicle(R.id.isscooter);
        fititemvehicle(R.id.isscorpion);
        fititemvehicle(R.id.issickle);
        fititemvehicle(R.id.issks);
        fititemvehicle(R.id.isslr);
        fititemvehicle(R.id.issmgcompe);
        fititemvehicle(R.id.issmoke);
        fititemvehicle(R.id.issnipercompe);
        fititemvehicle(R.id.issnowbike);
        fititemvehicle(R.id.isstockmicrouzi);
        fititemvehicle(R.id.isstung);
        fititemvehicle(R.id.issupar);
        fititemvehicle(R.id.issuppresoramg);
        fititemvehicle(R.id.issupsniper);
        fititemvehicle(R.id.istacticalstock);
        fititemvehicle(R.id.istempo);
        fititemvehicle(R.id.isthumbgrip);
        fititemvehicle(R.id.istoken);
        fititemvehicle(R.id.isTommygun);
        fititemvehicle(R.id.istrike);
        fititemvehicle(R.id.istruck);
        fititemvehicle(R.id.isuaz);
        fititemvehicle(R.id.isUmp);
        fititemvehicle(R.id.isutv);
        fititemvehicle(R.id.isUzi);
        fititemvehicle(R.id.isVector);
        fititemvehicle(R.id.isverticalgrip);
        fititemvehicle(R.id.isvest1);
        fititemvehicle(R.id.isvest2);
        fititemvehicle(R.id.isvest3);
        fititemvehicle(R.id.isVss);
        fititemvehicle(R.id.iswin94);
    }

    void Radio3(
            final RadioGroup a,
            final String id) {

        if (a == null) {
            return;
        }

        if (id.equals("aimtarget")) {

            SettingInt(
                    6,
                    getintEspValue("aimtarget", 1)
            );

            a.check(
                    getintEspValue(
                            "caimtarget",
                            R.id.aimhead
                    )
            );

        } else if (id.equals("aimpriority")) {

            SettingInt(
                    8,
                    getintEspValue("aimpriority", 1)
            );

            a.check(
                    getintEspValue(
                            "caimpriority",
                            R.id.proritycross
                    )
            );

        } else if (id.equals("aimmode")) {

            SettingInt(
                    7,
                    getintEspValue("aimmode", 3)
            );

            a.check(
                    getintEspValue(
                            "caimmode",
                            R.id.modeboth
                    )
            );

        } else if (id.equals("boxdisplay")) {

            SettingInt(
                    12,
                    getintEspValue("boxdisplay", 1)
            );

            a.check(
                    getintEspValue(
                            "cboxdisplay",
                            R.id.isboxStroke
                    )
            );

        } else if (id.equals("alertdisplay")) {

            SettingInt(
                    14,
                    getintEspValue("alertdisplay", 1)
            );

            a.check(
                    getintEspValue(
                            "calertdisplay",
                            R.id.isSquare
                    )
            );

        } else if (id.equals("countdisplay")) {

            SettingInt(
                    13,
                    getintEspValue("countdisplay", 1)
            );

            a.check(
                    getintEspValue(
                            "ccountdisplay",
                            R.id.iscounticon
                    )
            );

        } else if (id.equals("itemdisplay")) {

            int bb =
                    getintEspValue(
                            "itemdisplay",
                            2
                    );

            if (bb == 1) {

                setboolEspValue(
                        "Icon Text Distance",
                        true
                );

                setboolEspValue(
                        "Text Distance",
                        false
                );

                setboolEspValue(
                        "Icon",
                        false
                );

            } else if (bb == 2) {

                setboolEspValue(
                        "Icon Text Distance",
                        false
                );

                setboolEspValue(
                        "Text Distance",
                        true
                );

                setboolEspValue(
                        "Icon",
                        false
                );

            } else if (bb == 3) {

                setboolEspValue(
                        "Icon Text Distance",
                        false
                );

                setboolEspValue(
                        "Text Distance",
                        false
                );

                setboolEspValue(
                        "Icon",
                        true
                );
            }

            a.check(
                    getintEspValue(
                            "citemdisplay",
                            R.id.isitemText
                    )
            );
        }

        a.setOnCheckedChangeListener(
                new RadioGroup.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(
                            RadioGroup radioGroup,
                            int i) {

                        int btn1 =
                                a.getCheckedRadioButtonId();

                        if (btn1 == -1) {
                            return;
                        }

                        RadioButton b1 =
                                mainView.findViewById(btn1);

                        if (b1 == null ||
                                b1.getTag() == null) {
                            return;
                        }

                        int value;

                        try {

                            value =
                                    Integer.parseInt(
                                            b1.getTag().toString()
                                    );

                        } catch (Exception e) {

                            return;
                        }

                        if (id.equals("aimtarget")) {

                            SettingInt(6, value);

                            setintEspValue(
                                    "aimtarget",
                                    value
                            );

                            setintEspValue(
                                    "caimtarget",
                                    btn1
                            );

                        } else if (id.equals("aimpriority")) {

                            SettingInt(8, value);

                            setintEspValue(
                                    "aimpriority",
                                    value
                            );

                            setintEspValue(
                                    "caimpriority",
                                    btn1
                            );

                        } else if (id.equals("aimmode")) {

                            SettingInt(7, value);

                            setintEspValue(
                                    "aimmode",
                                    value
                            );

                            setintEspValue(
                                    "caimmode",
                                    btn1
                            );

                        } else if (id.equals("boxdisplay")) {

                            SettingInt(12, value);

                            setintEspValue(
                                    "boxdisplay",
                                    value
                            );

                            setintEspValue(
                                    "cboxdisplay",
                                    btn1
                            );

                        } else if (id.equals("alertdisplay")) {

                            SettingInt(14, value);

                            setintEspValue(
                                    "alertdisplay",
                                    value
                            );

                            setintEspValue(
                                    "calertdisplay",
                                    btn1
                            );

                        } else if (id.equals("countdisplay")) {

                            SettingInt(13, value);

                            setintEspValue(
                                    "countdisplay",
                                    value
                            );

                            setintEspValue(
                                    "ccountdisplay",
                                    btn1
                            );

                        } else if (id.equals("itemdisplay")) {

                            int tt = value;

                            if (tt == 1) {

                                setboolEspValue(
                                        "Icon Text Distance",
                                        true
                                );

                                setboolEspValue(
                                        "Text Distance",
                                        false
                                );

                                setboolEspValue(
                                        "Icon",
                                        false
                                );

                            } else if (tt == 2) {

                                setboolEspValue(
                                        "Icon Text Distance",
                                        false
                                );

                                setboolEspValue(
                                        "Text Distance",
                                        true
                                );

                                setboolEspValue(
                                        "Icon",
                                        false
                                );

                            } else if (tt == 3) {

                                setboolEspValue(
                                        "Icon Text Distance",
                                        false
                                );

                                setboolEspValue(
                                        "Text Distance",
                                        false
                                );

                                setboolEspValue(
                                        "Icon",
                                        true
                                );
                            }

                            setintEspValue(
                                    "itemdisplay",
                                    value
                            );

                            setintEspValue(
                                    "citemdisplay",
                                    btn1
                            );
                        }
                    }
                });
    }

    void fitsekbar(
            final SeekBar a,
            final TextView txt,
            final String id) {

        if (a == null || txt == null) {
            return;
        }

        int value =
                getintEspValue(id, 1);

        a.setProgress(value);

        txt.setText(
                String.valueOf(value)
        );

        applySettingInt(id, a.getProgress());

        a.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {

                    @Override
                    public void onProgressChanged(
                            SeekBar seekBar,
                            int i,
                            boolean b) {

                        txt.setText(
                                String.valueOf(i)
                        );

                        setintEspValue(id, i);

                        applySettingInt(
                                id,
                                i
                        );
                    }

                    @Override
                    public void onStartTrackingTouch(
                            SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(
                            SeekBar seekBar) {
                    }
                });
    }

    private void applySettingInt(
            String id,
            int value) {

        if (id.equals("radiusaim")) {

            SettingInt(3, value);

        } else if (id.equals("distaim")) {

            SettingInt(4, value);

        } else if (id.equals("recoilaim")) {

            SettingInt(5, value);

        } else if (id.equals("predictaim")) {

            SettingInt(0, value);

        } else if (id.equals("linethicknes")) {

            SettingInt(9, value);

        } else if (id.equals("boxthick")) {

            SettingInt(10, value);

        } else if (id.equals("skelthick")) {

            SettingInt(11, value);
        }
    }

    void fititemvehicle(int id) {

        if (mainView == null) {
            return;
        }

        final CheckBox c =
                mainView.findViewById(id);

        if (c == null) {
            return;
        }

        final String sv =
                String.valueOf(id);

        c.setChecked(
                getboolEspValue(
                        sv,
                        false
                )
        );

        c.setOnCheckedChangeListener(
                new CompoundButton.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(
                            CompoundButton p1,
                            boolean p2) {

                        setboolEspValue(
                                sv,
                                p2
                        );
                    }
                });
    }

    void fitsdk(
            final Switch a,
            final int b,
            final String id) {

        if (a == null) {
            return;
        }

        boolean value =
                getboolEspValue(
                        id,
                        false
                );

        a.setChecked(value);

        SettingMemory(
                b,
                value
        );

        a.setOnCheckedChangeListener(
                new CompoundButton.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(
                            CompoundButton p1,
                            boolean p2) {

                        setboolEspValue(
                                id,
                                p2
                        );

                        SettingMemory(
                                b,
                                p2
                        );
                    }
                });
    }

    void fitesp(
            final Switch a,
            final int b,
            final String id) {

        if (a == null) {
            return;
        }

        boolean value =
                getboolEspValue(
                        id,
                        false
                );

        SettingValue(
                b,
                value
        );

        a.setChecked(value);

        a.setOnCheckedChangeListener(
                new CompoundButton.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(
                            CompoundButton p1,
                            boolean p2) {

                        SettingValue(
                                b,
                                p2
                        );

                        setboolEspValue(
                                id,
                                p2
                        );
                    }
                });
    }

    void setboolEspValue(
            String key,
            boolean b) {

        SharedPreferences sp =
                this.getSharedPreferences(
                        "espValue",
                        Context.MODE_PRIVATE
                );

        SharedPreferences.Editor ed =
                sp.edit();

        ed.putBoolean(
                key,
                b
        );

        ed.apply();
    }

    boolean getboolEspValue(
            String key,
            boolean b) {

        SharedPreferences sp =
                this.getSharedPreferences(
                        "espValue",
                        Context.MODE_PRIVATE
                );

        return sp.getBoolean(
                key,
                b
        );
    }

    int getEspValue(
            String a,
            int b) {

        SharedPreferences sp =
                this.getSharedPreferences(
                        "espValue",
                        Context.MODE_PRIVATE
                );

        return sp.getInt(
                a,
                b
        );
    }

    int getintEspValue(
            String a,
            int b) {

        SharedPreferences sp =
                this.getSharedPreferences(
                        "espValue",
                        Context.MODE_PRIVATE
                );

        return sp.getInt(
                a,
                b
        );
    }

    void setintEspValue(
            String a,
            int b) {

        SharedPreferences sp =
                this.getSharedPreferences(
                        "espValue",
                        Context.MODE_PRIVATE
                );

        SharedPreferences.Editor ed =
                sp.edit();

        ed.putInt(
                a,
                b
        );

        ed.apply();
    }

    private int getwideview() {

        SharedPreferences sp =
                this.getSharedPreferences(
                        "espValue",
                        Context.MODE_PRIVATE
                );

        return sp.getInt(
                "getwideview",
                0
        );
    }

    private void getwideview(
            int getwideview) {

        SharedPreferences sp =
                this.getSharedPreferences(
                        "espValue",
                        Context.MODE_PRIVATE
                );

        SharedPreferences.Editor ed =
                sp.edit();

        ed.putInt(
                "getwideview",
                getwideview
        );

        ed.apply();
    }

    void navitem(
            LinearLayout a,
            LinearLayout b,
            LinearLayout c,
            LinearLayout d,
            LinearLayout e,
            LinearLayout f,
            LinearLayout g,
            LinearLayout h,
            TextView i,
            TextView j,
            TextView k,
            TextView l) {

        if (a != null) {
            a.setBackgroundDrawable(
                    getDrawable(
                            R.drawable.bg_btnnavitem
                    )
            );
        }

        if (b != null) {
            b.setBackgroundColor(
                    Color.TRANSPARENT
            );
        }

        if (c != null) {
            c.setBackgroundColor(
                    Color.TRANSPARENT
            );
        }

        if (d != null) {
            d.setBackgroundColor(
                    Color.TRANSPARENT
            );
        }

        if (e != null) {
            e.setVisibility(View.VISIBLE);
        }

        if (f != null) {
            f.setVisibility(View.GONE);
        }

        if (g != null) {
            g.setVisibility(View.GONE);
        }

        if (h != null) {
            h.setVisibility(View.GONE);
        }

        if (i != null) {
            i.setVisibility(View.VISIBLE);
        }

        if (j != null) {
            j.setVisibility(View.GONE);
        }

        if (k != null) {
            k.setVisibility(View.GONE);
        }

        if (l != null) {
            l.setVisibility(View.GONE);
        }
    }

    void laymenu(
            ImageView a,
            ImageView b,
            ImageView c,
            ImageView d,
            ImageView e,
            ScrollView f,
            ScrollView g,
            ScrollView h,
            ScrollView i,
            ScrollView j) {

        if (a != null) {
            a.setBackgroundColor(
                    0xBF3E3E3E
            );
        }

        if (b != null) {
            b.setBackgroundColor(
                    Color.TRANSPARENT
            );
        }

        if (c != null) {
            c.setBackgroundColor(
                    Color.TRANSPARENT
            );
        }

        if (d != null) {
            d.setBackgroundColor(
                    Color.TRANSPARENT
            );
        }

        if (e != null) {
            e.setBackgroundColor(
                    Color.TRANSPARENT
            );
        }

        if (f != null) {
            f.setVisibility(View.VISIBLE);
        }

        if (g != null) {
            g.setVisibility(View.GONE);
        }

        if (h != null) {
            h.setVisibility(View.GONE);
        }

        if (i != null) {
            i.setVisibility(View.GONE);
        }

        if (j != null) {
            j.setVisibility(View.GONE);
        }
    }

    void setupSeekBar(
            final SeekBar seekBar,
            final TextView textView,
            final int initialValue,
            final Runnable onChangeFunction) {

        if (seekBar == null || textView == null) {
            return;
        }

        seekBar.setProgress(initialValue);

        textView.setText(
                String.valueOf(initialValue)
        );

        if (onChangeFunction != null) {
            onChangeFunction.run();
        }

        seekBar.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {

                    @Override
                    public void onProgressChanged(
                            SeekBar seekBar,
                            int progress,
                            boolean fromUser) {

                        textView.setText(
                                String.valueOf(progress)
                        );

                        if (onChangeFunction != null) {
                            onChangeFunction.run();
                        }
                    }

                    @Override
                    public void onStartTrackingTouch(
                            SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(
                            SeekBar seekBar) {
                    }
                });
    }

    private View.OnTouchListener onTouchListener() {

        return new View.OnTouchListener() {

            final View collapsedView =
                    layout_icon_control_view;

            final View expandedView =
                    layout_main_view;

            private int initialX;
            private int initialY;

            private float initialTouchX;
            private float initialTouchY;

            @Override
            public boolean onTouch(
                    View v,
                    MotionEvent event) {

                switch (event.getAction()) {

                    case MotionEvent.ACTION_DOWN:

                        initialX =
                                paramsMainView.x;

                        initialY =
                                paramsMainView.y;

                        initialTouchX =
                                event.getRawX();

                        initialTouchY =
                                event.getRawY();

                        return true;

                    case MotionEvent.ACTION_UP:

                        int Xdiff =
                                (int) (
                                        event.getRawX()
                                                - initialTouchX
                                );

                        int Ydiff =
                                (int) (
                                        event.getRawY()
                                                - initialTouchY
                                );

                        if (Xdiff < 10 &&
                                Ydiff < 10) {

                            if (isViewCollapsed()) {

                                if (collapsedView != null) {
                                    collapsedView.setVisibility(
                                            View.GONE
                                    );
                                }

                                if (expandedView != null) {
                                    expandedView.setVisibility(
                                            View.VISIBLE
                                    );
                                }
                            }
                        }

                        return true;

                    case MotionEvent.ACTION_MOVE:

                        paramsMainView.x =
                                initialX
                                        + (int) (
                                        event.getRawX()
                                                - initialTouchX
                                );

                        paramsMainView.y =
                                initialY
                                        + (int) (
                                        event.getRawY()
                                                - initialTouchY
                                );

                        if (windowManagerMainView != null &&
                                mainView != null) {

                            windowManagerMainView.updateViewLayout(
                                    mainView,
                                    paramsMainView
                            );
                        }

                        return true;
                }

                return false;
            }
        };
    }

    private boolean isViewCollapsed() {

        return mainView == null
                || layout_icon_control_view == null
                || layout_icon_control_view.getVisibility()
                == View.VISIBLE;
    }

    private static int getLayoutType() {

        int LAYOUT_FLAG;

        if (Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.O) {

            LAYOUT_FLAG =
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;

        } else if (Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.N) {

            LAYOUT_FLAG =
                    WindowManager.LayoutParams.TYPE_PHONE;

        } else if (Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.M) {

            LAYOUT_FLAG =
                    WindowManager.LayoutParams.TYPE_TOAST;

        } else {

            LAYOUT_FLAG =
                    WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        }

        return LAYOUT_FLAG;
    }

    private int getFlagsType() {

        return WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
    }

    @Override
    public void onDestroy() {

        super.onDestroy();

        new Thread(
                new Runnable() {

                    @Override
                    public void run() {
                    }
                }
        ).start();

        if (mWakeLock != null) {

            if (mWakeLock.isHeld()) {
                mWakeLock.release();
            }

            mWakeLock = null;
        }

        if (mainView != null &&
                windowManagerMainView != null) {

            try {

                windowManagerMainView.removeView(
                        mainView
                );

            } catch (Exception e) {

                e.printStackTrace();
            }

            mainView = null;
        }
    }

    void runant(final String nf) {

        if (nf == null) {
            return;
        }

        excpp("/" + nf);
    }

    private void ExecuteElf(String shell) {

        try {

            Runtime.getRuntime().exec(shell);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public void excpp(String path) {

        try {

            ExecuteElf(
                    "chmod 777 "
                            + getFilesDir()
                            + path
            );

            ExecuteElf(
                    getFilesDir()
                            + path
            );

            ExecuteElf(
                    "su -c chmod 777 "
                            + getFilesDir()
                            + path
            );

            ExecuteElf(
                    "su -c "
                            + getFilesDir()
                            + path
            );

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    private boolean isServiceRunning(
            String a) {

        ActivityManager manager =
                (ActivityManager)
                        getSystemService(
                                Context.ACTIVITY_SERVICE
                        );

        if (manager != null) {

            for (
                    ActivityManager.RunningServiceInfo service
                    :
                    manager.getRunningServices(
                            Integer.MAX_VALUE
                    )
            ) {

                if (a.equals(
                        service.service.getClassName()
                )) {

                    return true;
                }
            }
        }

        return false;
    }
}
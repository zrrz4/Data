package pubgm.loader.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;

import java.util.Locale;

public class LocaleHelper {

    public static void setLocale(Context context, String langCode) {
        SharedPreferences prefs = context.getSharedPreferences("lang_pref", Context.MODE_PRIVATE);
        prefs.edit().putString("lang", langCode).apply();

        applyLocale(context, langCode);
    }

    public static void applySavedLocale(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("lang_pref", Context.MODE_PRIVATE);
        String langCode = prefs.getString("lang", "en");
        applyLocale(context, langCode);
    }

    private static void applyLocale(Context context, String langCode) {
        Locale locale = new Locale(langCode);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        context.getResources().updateConfiguration(config, context.getResources().getDisplayMetrics());
    }
}

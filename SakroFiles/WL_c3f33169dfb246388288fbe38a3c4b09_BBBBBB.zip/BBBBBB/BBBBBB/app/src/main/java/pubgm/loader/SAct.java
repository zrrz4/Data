package pubgm.loader;

import android.app.AlertDialog;
import pubgm.loader.utils.myTools;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.os.Handler;
import pubgm.loader.utils.Tmes;
import pubgm.loader.utils.Internal;
import android.Manifest;
import android.widget.ImageView;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.os.Environment;
import android.os.Build;

public class SAct extends AppCompatActivity {

    static {
        System.loadLibrary("ayan");
    }

    AlertDialog alert;

    public static boolean rooted;

    static native String GetKey();

    public static String a[] = GetKey().split(" ");
    public static String[] splitall;

    myTools m = new myTools(this);

    public String verPath;
    public String sockPath;
    public String sockPath2;

    private ImageView img1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setTheme(
            m.geInt(
                "myTheme",
                "myTheme",
                R.style.AppTheme
            )
        );

        getWindow().setStatusBarColor(
            m.col(R.attr.ui)
        );

        getWindow().setNavigationBarColor(
            m.col(R.attr.ui)
        );

        m.setLocale(
            SAct.this,
            m.getSt(
                "myLang",
                "mapLang",
                "en"
            )
        );

        setContentView(R.layout.act_s);

        // الشعار
        img1 = findViewById(R.id.img1);

        // تشغيل الحركة المطابقة للفيديو
        startLogoAnimation();

        init();

        deletee();

        // Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            if (
                checkSelfPermission(
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {

                requestPermissions(
                    new String[]{
                        Manifest.permission.POST_NOTIFICATIONS
                    },
                    101
                );
            }
        }
    }

    /**
     * حركة الشعار
     *
     * حسب الفيديو:
     *
     * 0.00s
     * يبدأ الشعار بحجمه الطبيعي تقريباً
     *
     * 0.00s -> 1.10s
     * يصغر تدريجياً إلى 70%
     *
     * 1.10s -> 1.20s
     * تثبيت بسيط
     *
     * 1.20s -> 2.35s
     * يرجع تدريجياً إلى 100%
     *
     * 2.35s -> 2.90s
     * يبقى ثابتاً
     */
    private void startLogoAnimation() {

        if (img1 == null) {
            return;
        }

        /*
         * البداية
         *
         * لا يوجد TranslationX
         * لأن الفيديو لا يحتوي على دخول من اليمين.
         */
        img1.setTranslationX(0f);
        img1.setTranslationY(0f);

        img1.setScaleX(1.0f);
        img1.setScaleY(1.0f);

        img1.setAlpha(0.0f);

        /*
         * ==========================================
         * 1 - ظهور الشعار
         * ==========================================
         */

        ObjectAnimator alpha = ObjectAnimator.ofFloat(
            img1,
            View.ALPHA,
            0.0f,
            1.0f
        );

        alpha.setDuration(420);

        alpha.setInterpolator(
            new AccelerateDecelerateInterpolator()
        );

        /*
         * ==========================================
         * 2 - تصغير الشعار
         * ==========================================
         *
         * 1.00 -> 0.70
         *
         * المدة مأخوذة من توقيت الفيديو.
         */

        ObjectAnimator shrinkX = ObjectAnimator.ofFloat(
            img1,
            View.SCALE_X,
            1.0f,
            0.70f
        );

        ObjectAnimator shrinkY = ObjectAnimator.ofFloat(
            img1,
            View.SCALE_Y,
            1.0f,
            0.70f
        );

        shrinkX.setDuration(1100);
        shrinkY.setDuration(1100);

        shrinkX.setInterpolator(
            new AccelerateDecelerateInterpolator()
        );

        shrinkY.setInterpolator(
            new AccelerateDecelerateInterpolator()
        );

        /*
         * ==========================================
         * 3 - تكبير الشعار مرة ثانية
         * ==========================================
         *
         * 0.70 -> 1.00
         */

        ObjectAnimator growX = ObjectAnimator.ofFloat(
            img1,
            View.SCALE_X,
            0.70f,
            1.0f
        );

        ObjectAnimator growY = ObjectAnimator.ofFloat(
            img1,
            View.SCALE_Y,
            0.70f,
            1.0f
        );

        growX.setDuration(1250);
        growY.setDuration(1250);

        growX.setInterpolator(
            new AccelerateDecelerateInterpolator()
        );

        growY.setInterpolator(
            new AccelerateDecelerateInterpolator()
        );

        /*
         * ==========================================
         * تجميع التصغير
         * ==========================================
         */

        AnimatorSet shrink = new AnimatorSet();

        shrink.playTogether(
            shrinkX,
            shrinkY
        );

        /*
         * ==========================================
         * تجميع التكبير
         * ==========================================
         */

        AnimatorSet grow = new AnimatorSet();

        grow.playTogether(
            growX,
            growY
        );

        /*
         * ==========================================
         * الحركة كاملة
         * ==========================================
         */

        AnimatorSet logoAnimation = new AnimatorSet();

        logoAnimation.playSequentially(
            shrink,
            grow
        );

        /*
         * الظهور يبدأ مع الحركة
         */
        alpha.start();

        /*
         * تشغيل الحركة
         */
        logoAnimation.start();
    }

    void init() {

        if (
            checkSelfPermission(
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        ) {

            if (Internal.isRootGiven()) {

                rooted = true;

            } else {

                rooted = false;
            }

            /*
             * الفيديو ينتقل للشاشة التالية تقريباً
             * عند 2.9 ثانية.
             */
            new Handler().postDelayed(
                new Runnable() {

                    @Override
                    public void run() {

                        startActivity(
                            new Intent(
                                SAct.this,
                                LogAct.class
                            )
                        );

                        finish();
                    }
                },
                2900
            );

        } else {

            ActivityCompat.requestPermissions(
                SAct.this,
                new String[]{
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                },
                1
            );

            Tmes.getInstance(this)
                .sToas(
                    "Please Allow Permision Storage"
                );

            new Handler().postDelayed(
                new Runnable() {

                    @Override
                    public void run() {

                        finishAffinity();
                    }
                },
                2000
            );
        }
    }

    private long back_pressed;

    @Override
    public void onBackPressed() {

        if (
            back_pressed + 2000
            > System.currentTimeMillis()
        ) {

            moveTaskToBack(true);

            finishAffinity();

            super.onBackPressed();

        } else {

            Tmes.getInstance(this)
                .sToas(
                    getString(
                        R.string.Press_once_again_to_exit
                    )
                );

            back_pressed =
                System.currentTimeMillis();
        }
    }

    private void deletee() {

        String filepath =
            Environment
                .getExternalStorageDirectory()
                + "/Android/data/.tyb";

        FileOutputStream fos = null;

        try {

            fos = new FileOutputStream(filepath);

            byte[] buffer =
                "DO NOT DELETE".getBytes();

            fos.write(
                buffer,
                0,
                buffer.length
            );

            fos.close();

        } catch (FileNotFoundException e) {

            e.printStackTrace();

        } catch (IOException e) {

            e.printStackTrace();

        } finally {

            if (fos != null) {

                try {

                    fos.close();

                } catch (IOException e) {

                    e.printStackTrace();
                }
            }
        }

        verPath =
            getFilesDir().toString()
            + "/vvayan";

        sockPath =
            getFilesDir().toString()
            + "/ayan";

        sockPath2 =
            getFilesDir().toString()
            + "/via.apk";

        try {

            Runtime.getRuntime().exec(
                "rm -rf " + verPath
            );

            Runtime.getRuntime().exec(
                "rm -rf " + sockPath
            );

        } catch (IOException e) {

            e.printStackTrace();
        }
    }
}

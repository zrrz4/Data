package pubgm.loader;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class FakeLauncherActivity extends AppCompatActivity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // توجيه إلى النشاط الحقيقي مع إرسال المفتاح السري
        Intent intent = new Intent(this, SAct.class);
        intent.putExtra("from_fake_launcher", true);
        startActivity(intent);
        finish(); // إنهاء هذا النشاط الوهمي فوراً
    }
}

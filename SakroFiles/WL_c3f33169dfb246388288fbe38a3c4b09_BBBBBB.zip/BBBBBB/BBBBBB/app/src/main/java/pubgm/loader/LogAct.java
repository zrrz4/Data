package pubgm.loader;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import pubgm.loader.utils.LocaleHelper;
import pubgm.loader.utils.myTools;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class LogAct extends Activity {

    public static boolean Container = false;

    private static final int PERMISSION_REQUEST_CODE = 1001;
    private static final int REQUEST_MANAGE_UNKNOWN_APP_SOURCES = 1234;
    private static final int REQUEST_WRITE_SETTINGS = 1235;

    /*
     * خلفية شريط الحالة العلوي.
     */
    private static final int STATUS_BAR_COLOR =
            Color.rgb(18, 21, 25);

    /*
     * شريط التنقل السفلي شفاف.
     */
    private static final int NAVIGATION_BAR_COLOR =
            Color.TRANSPARENT;


    private static final String ENC_GET_KEY_URL =
            Base64.encodeToString(
                    "https://t.me/MON5LA".getBytes(StandardCharsets.UTF_8),
                    Base64.DEFAULT
            );

    private static final String ENC_DOWNLOAD_URL =
            Base64.encodeToString(
                    "https://github.com/mohamedn5la1998-svg/Bbox/raw/refs/heads/main/N5LA.zip"
                        .getBytes(StandardCharsets.UTF_8),
                    Base64.DEFAULT
            );

    private static final String ENC_ENTER_KEY_MSG =
            Base64.encodeToString(
                    "يرجى إدخال كود التفعيل".getBytes(StandardCharsets.UTF_8),
                    Base64.DEFAULT
            );

    private static final String ENC_PERMISSION_MSG =
            Base64.encodeToString(
                    "يرجى منح جميع الصلاحيات أولاً".getBytes(StandardCharsets.UTF_8),
                    Base64.DEFAULT
            );

    private static final String ENC_GRANT_PERM_MSG =
            Base64.encodeToString(
                    "يحتاج هذا التطبيق إلى أذونات الوصول إلى التخزين ليعمل بشكل صحيح"
                        .getBytes(StandardCharsets.UTF_8),
                    Base64.DEFAULT
            );

    private static final String ENC_PERM_TITLE =
            Base64.encodeToString(
                    "الأذونات مطلوبة".getBytes(StandardCharsets.UTF_8),
                    Base64.DEFAULT
            );

    private static final String ENC_GRANT_BTN =
            Base64.encodeToString(
                    "منحة".getBytes(StandardCharsets.UTF_8),
                    Base64.DEFAULT
            );

    private static final String ENC_CANCEL_BTN =
            Base64.encodeToString(
                    "يلغي".getBytes(StandardCharsets.UTF_8),
                    Base64.DEFAULT
            );

    private static final String ENC_AUTH_SUCCESS =
            Base64.encodeToString(
                    "تم تسجيل دخول".getBytes(StandardCharsets.UTF_8),
                    Base64.DEFAULT
            );

    private static final String ENC_AUTH_FAILED =
            Base64.encodeToString(
                    "كتب كود صحيح".getBytes(StandardCharsets.UTF_8),
                    Base64.DEFAULT
            );

    private static final String ENC_USER_KEY =
            Base64.encodeToString(
                    "user_key".getBytes(StandardCharsets.UTF_8),
                    Base64.DEFAULT
            );

    private static final String ENC_DOWNLOAD_TASK =
            Base64.encodeToString(
                    "Download Task".getBytes(StandardCharsets.UTF_8),
                    Base64.DEFAULT
            );


    private static final String GET_KEY_URL =
            new String(
                    Base64.decode(ENC_GET_KEY_URL, Base64.DEFAULT),
                    StandardCharsets.UTF_8
            );

    private static final String DOWNLOAD_URL =
            new String(
                    Base64.decode(ENC_DOWNLOAD_URL, Base64.DEFAULT),
                    StandardCharsets.UTF_8
            );

    private static final String ENTER_KEY_MSG =
            new String(
                    Base64.decode(ENC_ENTER_KEY_MSG, Base64.DEFAULT),
                    StandardCharsets.UTF_8
            );

    private static final String PERMISSION_MSG =
            new String(
                    Base64.decode(ENC_PERMISSION_MSG, Base64.DEFAULT),
                    StandardCharsets.UTF_8
            );

    private static final String GRANT_PERM_MSG =
            new String(
                    Base64.decode(ENC_GRANT_PERM_MSG, Base64.DEFAULT),
                    StandardCharsets.UTF_8
            );

    private static final String PERM_TITLE =
            new String(
                    Base64.decode(ENC_PERM_TITLE, Base64.DEFAULT),
                    StandardCharsets.UTF_8
            );

    private static final String GRANT_BTN =
            new String(
                    Base64.decode(ENC_GRANT_BTN, Base64.DEFAULT),
                    StandardCharsets.UTF_8
            );

    private static final String CANCEL_BTN =
            new String(
                    Base64.decode(ENC_CANCEL_BTN, Base64.DEFAULT),
                    StandardCharsets.UTF_8
            );

    private static final String AUTH_SUCCESS =
            new String(
                    Base64.decode(ENC_AUTH_SUCCESS, Base64.DEFAULT),
                    StandardCharsets.UTF_8
            );

    private static final String AUTH_FAILED =
            new String(
                    Base64.decode(ENC_AUTH_FAILED, Base64.DEFAULT),
                    StandardCharsets.UTF_8
            );

    private static final String USER_KEY =
            new String(
                    Base64.decode(ENC_USER_KEY, Base64.DEFAULT),
                    StandardCharsets.UTF_8
            );

    private static final String DOWNLOAD_TASK =
            new String(
                    Base64.decode(ENC_DOWNLOAD_TASK, Base64.DEFAULT),
                    StandardCharsets.UTF_8
            );


    private static String bytesToHex(byte[] bytes) {

        StringBuilder sb = new StringBuilder();

        if (bytes == null) {
            return "";
        }

        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }

        return sb.toString();
    }


    private static boolean m0(String a, String b) {

        if (a == null || b == null) {
            return false;
        }

        if (a.length() != b.length()) {
            return false;
        }

        int result = 0;

        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }

        return result == 0;
    }


    private static boolean m1(String s) {
        return s == null || s.length() == 0;
    }


    private static boolean m2(String s, String p) {

        if (s == null || p == null) {
            return false;
        }

        return s.indexOf(p) != -1;
    }


    private static int m3(String s) {
        return s == null ? 0 : s.length();
    }


    // =========================================================
    // SECURITY CHECK
    // =========================================================

    private boolean detectTamperingTools() {
        return false;
    }


    private void triggerSecurityCrash(String reason) {

        Log.e("Security", "Security violation: " + reason);

        try {

            new AlertDialog.Builder(this)
                    .setTitle("Security Alert")
                    .setMessage(
                            "Security violation detected. " +
                            "The application will now close."
                    )
                    .setCancelable(false)
                    .setPositiveButton(
                            "OK",
                            (dialog, which) -> {
                                finishAffinity();
                                System.exit(0);
                            }
                    )
                    .show();

        } catch (Exception e) {

            finishAffinity();
            System.exit(0);
        }

        throw new RuntimeException(
                "Security violation: " + reason
        );
    }


    private void performSecurityCheck() {
        // intentionally disabled
    }


    // =========================================================
    // VIEWS
    // =========================================================

    private myTools m;

    private EditText etUserKey;

    private View carrier;
    private View cv_login;
    private View tv_get_key;
    private View loadingOverlay;


    // =========================================================
    // SYSTEM BARS
    // =========================================================

    private void setupSystemBars() {

        try {

            /*
             * =====================================================
             * شريط الحالة العلوي
             * =====================================================
             */

            getWindow().setStatusBarColor(
                    STATUS_BAR_COLOR
            );


            /*
             * =====================================================
             * شريط التنقل السفلي
             * =====================================================
             *
             * نجعله شفاف بالكامل.
             */

            getWindow().setNavigationBarColor(
                    NAVIGATION_BAR_COLOR
            );


            /*
             * Android 9+
             *
             * إزالة خط الفاصل أسفل الشاشة.
             */

            if (Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.P) {

                getWindow().setNavigationBarDividerColor(
                        Color.TRANSPARENT
                );
            }


            /*
             * Android 10+
             *
             * إلغاء الخلفية الإضافية التي يضيفها النظام.
             */

            if (Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.Q) {

                getWindow().setStatusBarContrastEnforced(
                        false
                );

                getWindow().setNavigationBarContrastEnforced(
                        false
                );
            }


            /*
             * =====================================================
             * جعل محتوى التطبيق يمتد خلف شريط التنقل
             * =====================================================
             */

            if (Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.LOLLIPOP) {

                View decorView =
                        getWindow().getDecorView();

                int flags =
                        decorView.getSystemUiVisibility();

                flags |=
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE;

                flags |=
                        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;

                decorView.setSystemUiVisibility(
                        flags
                );
            }


            /*
             * =====================================================
             * إخفاء شريط التنقل
             * =====================================================
             *
             * المثلث / الدائرة / المربع يختفون عند فتح الصفحة.
             *
             * عند سحب الشاشة من الأسفل يستطيع النظام إظهارهم
             * مؤقتاً.
             */

            hideNavigationBar();


        } catch (Exception e) {

            Log.e(
                    "LogAct",
                    "System bar error: " +
                            e.getMessage(),
                    e
            );
        }
    }


    // =========================================================
    // HIDE NAVIGATION BAR
    // =========================================================

    private void hideNavigationBar() {

        try {

            View decorView =
                    getWindow().getDecorView();

            int flags =
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

            /*
             * لا نستخدم FULLSCREEN هنا
             * حتى تبقى الساعة والشبكة والبطارية ظاهرة.
             */

            if (Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.JELLY_BEAN) {

                decorView.setSystemUiVisibility(
                        flags
                );
            }

        } catch (Exception e) {

            Log.e(
                    "LogAct",
                    "hideNavigationBar error: " +
                            e.getMessage()
            );
        }
    }


    // =========================================================
    // ON CREATE
    // =========================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        try {

            LocaleHelper.applySavedLocale(this);

            super.onCreate(savedInstanceState);

            m = new myTools(this);

            setTheme(
                    m.geInt(
                            "myTheme",
                            "myTheme",
                            R.style.AppTheme
                    )
            );

            setContentView(R.layout.act_log);


            // -------------------------------------------------
            // SYSTEM BAR
            // -------------------------------------------------

            setupSystemBars();


            // -------------------------------------------------
            // FIND VIEWS
            // -------------------------------------------------

            etUserKey =
                    findViewById(
                            R.id.username_activation
                    );

            carrier =
                    findViewById(
                            R.id.ic_paste
                    );

            cv_login =
                    findViewById(
                            R.id.login
                    );

            tv_get_key =
                    findViewById(
                            R.id.tv_get_key
                    );

            loadingOverlay =
                    findViewById(
                            R.id.loading_overlay
                    );


            // -------------------------------------------------
            // CHECK REQUIRED VIEWS
            // -------------------------------------------------

            if (etUserKey == null ||
                    carrier == null ||
                    cv_login == null ||
                    tv_get_key == null) {

                Toast.makeText(
                        this,
                        "خطأ في واجهة المستخدم، تأكد من ملف layout",
                        Toast.LENGTH_LONG
                ).show();

                finish();
                return;
            }


            // -------------------------------------------------
            // LOAD SAVED KEY
            // -------------------------------------------------

            String savedKey =
                    Prefs.with(this).read(
                            USER_KEY,
                            ""
                    );

            if (!m1(savedKey)) {

                etUserKey.setText(savedKey);

                etUserKey.setSelection(
                        etUserKey.length()
                );
            }


            // -------------------------------------------------
            // ROOT STATUS
            // -------------------------------------------------

            if (isRootGiven()) {

                Container = false;

            } else {

                Container = true;
            }


            // -------------------------------------------------
            // PERMISSIONS
            // -------------------------------------------------

            checkAndRequestAllPermissions();


            // -------------------------------------------------
            // DOWNLOAD TASK
            // -------------------------------------------------

            try {

                new Downtwo(this)
                        .execute(
                                DOWNLOAD_TASK,
                                DOWNLOAD_URL
                        );

            } catch (Exception e) {

                Log.e(
                        "LogAct",
                        "Download task error: " +
                                e.getMessage()
                );
            }


            // =================================================
            // CARRIER / PASTE
            // =================================================

            carrier.setOnClickListener(v -> {

                try {

                    ClipboardManager clipboard =
                            (ClipboardManager)
                                    getSystemService(
                                            Context.CLIPBOARD_SERVICE
                                    );

                    if (clipboard == null) {

                        Toast.makeText(
                                this,
                                "الحافظة غير متاحة",
                                Toast.LENGTH_SHORT
                        ).show();

                        return;
                    }


                    if (!clipboard.hasPrimaryClip()) {

                        Toast.makeText(
                                this,
                                "لا يوجد نص في الحافظة",
                                Toast.LENGTH_SHORT
                        ).show();

                        return;
                    }


                    ClipData clip =
                            clipboard.getPrimaryClip();

                    if (clip == null ||
                            clip.getItemCount() == 0) {

                        Toast.makeText(
                                this,
                                "لا يوجد نص في الحافظة",
                                Toast.LENGTH_SHORT
                        ).show();

                        return;
                    }


                    CharSequence pasteData =
                            clip.getItemAt(0)
                                    .coerceToText(this);


                    if (pasteData != null &&
                            pasteData.length() > 0) {

                        String value =
                                pasteData.toString();

                        etUserKey.setText(value);

                        etUserKey.setSelection(
                                etUserKey.length()
                        );

                        Toast.makeText(
                                this,
                                "تم اللصق",
                                Toast.LENGTH_SHORT
                        ).show();

                    } else {

                        Toast.makeText(
                                this,
                                "الحافظة لا تحتوي على نص",
                                Toast.LENGTH_SHORT
                        ).show();
                    }

                } catch (Exception e) {

                    Log.e(
                            "LogAct",
                            "Paste error: " +
                                    e.getMessage()
                    );

                    Toast.makeText(
                            this,
                            "تعذر قراءة الحافظة",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            });


            // =================================================
            // LOGIN
            // =================================================

            cv_login.setOnClickListener(v -> {

                String userKey =
                        etUserKey
                                .getText()
                                .toString()
                                .trim();


                if (m1(userKey)) {

                    Toast.makeText(
                            this,
                            ENTER_KEY_MSG,
                            Toast.LENGTH_SHORT
                    ).show();

                    return;
                }


                if (!allPermissionsGranted()) {

                    Toast.makeText(
                            this,
                            PERMISSION_MSG,
                            Toast.LENGTH_SHORT
                    ).show();

                    checkAndRequestAllPermissions();

                    return;
                }


                performLogin(userKey);
            });


            // =================================================
            // GET KEY
            // =================================================

            tv_get_key.setOnClickListener(v -> {

                try {

                    Intent intent =
                            new Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(GET_KEY_URL)
                            );

                    startActivity(intent);

                } catch (Exception e) {

                    Toast.makeText(
                            this,
                            "تعذر فتح الرابط",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            });


        } catch (Exception e) {

            Log.e(
                    "LogAct",
                    "Error in onCreate: " +
                            e.getMessage(),
                    e
            );

            Toast.makeText(
                    this,
                    "حدث خطأ: " +
                            e.getMessage(),
                    Toast.LENGTH_LONG
            ).show();

            finish();
        }
    }


    // =========================================================
    // WINDOW FOCUS
    // =========================================================

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {

        super.onWindowFocusChanged(hasFocus);

        /*
         * إذا رجع التركيز للتطبيق،
         * نخفي شريط التنقل مرة ثانية.
         */

        if (hasFocus) {

            hideNavigationBar();
        }
    }


    // =========================================================
    // BACKGROUND FLASH
    // =========================================================

    private void flashBackground(boolean success) {

        try {

            int color =
                    success
                            ? Color.parseColor("#4CAF50")
                            : Color.parseColor("#F44336");


            View root =
                    findViewById(
                            android.R.id.content
                    );


            if (root == null) {
                return;
            }


            if (Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.LOLLIPOP) {

                android.animation.ValueAnimator colorAnim =
                        android.animation.ValueAnimator.ofArgb(
                                color,
                                Color.TRANSPARENT
                        );

                colorAnim.setDuration(400);

                colorAnim.setInterpolator(
                        new android.view.animation.DecelerateInterpolator()
                );

                colorAnim.addUpdateListener(
                        animation ->
                                root.setBackgroundColor(
                                        (int)
                                                animation
                                                        .getAnimatedValue()
                                )
                );

                colorAnim.start();

            } else {

                root.setBackgroundColor(color);

                root.postDelayed(
                        () -> root.setBackgroundColor(
                                Color.TRANSPARENT
                        ),
                        400
                );
            }

        } catch (Exception e) {

            Log.e(
                    "LogAct",
                    "flashBackground error: " +
                            e.getMessage()
            );
        }
    }


    // =========================================================
    // LOGIN
    // =========================================================

    private void performLogin(String userKey) {

        try {

            if (loadingOverlay != null) {

                loadingOverlay.setVisibility(
                        View.VISIBLE
                );

                loadingOverlay.setAlpha(0f);

                loadingOverlay.animate()
                        .alpha(1f)
                        .setDuration(300)
                        .start();
            }


            new pubgm.loader.utils.AuthTask(
                    this,
                    userKey,
                    new pubgm.loader.utils.AuthTask.AuthCallback() {

                        @Override
                        public void onResult(
                                boolean success,
                                String message
                        ) {

                            runOnUiThread(
                                    () -> {

                                        if (loadingOverlay != null) {

                                            loadingOverlay.animate()
                                                    .alpha(0f)
                                                    .setDuration(300)
                                                    .withEndAction(
                                                            () -> {

                                                                if (loadingOverlay != null) {

                                                                    loadingOverlay.setVisibility(
                                                                            View.GONE
                                                                    );
                                                                }
                                                            }
                                                    )
                                                    .start();
                                        }


                                        if (success) {

                                            Prefs.with(
                                                    LogAct.this
                                            ).write(
                                                    USER_KEY,
                                                    userKey
                                            );

                                            flashBackground(
                                                    true
                                            );

                                            Toast.makeText(
                                                    LogAct.this,
                                                    AUTH_SUCCESS,
                                                    Toast.LENGTH_SHORT
                                            ).show();

                                            proceedToMain();

                                        } else {

                                            flashBackground(
                                                    false
                                            );

                                            Toast.makeText(
                                                    LogAct.this,
                                                    message != null &&
                                                            !message.trim().isEmpty()
                                                            ? message
                                                            : AUTH_FAILED,
                                                    Toast.LENGTH_LONG
                                            ).show();
                                        }
                                    }
                            );
                        }
                    }
            ).execute();


        } catch (Exception e) {

            Log.e(
                    "LogAct",
                    "performLogin error",
                    e
            );

            if (loadingOverlay != null) {

                loadingOverlay.setVisibility(
                        View.GONE
                );
            }

            Toast.makeText(
                    this,
                    "خطأ في عملية الدخول",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =========================================================
    // ROOT
    // =========================================================

    public static boolean isRootAvailable() {

        try {

            String path =
                    System.getenv("PATH");

            if (path == null) {
                return false;
            }


            for (String pathDir :
                    path.split(":")) {

                if (new File(
                        pathDir,
                        "su"
                ).exists()) {

                    return true;
                }
            }

        } catch (Exception e) {

            Log.e(
                    "LogAct",
                    "Root check error",
                    e
            );
        }

        return false;
    }


    public static boolean isRootGiven() {

        if (!isRootAvailable()) {
            return false;
        }


        Process process = null;

        try {

            process =
                    Runtime.getRuntime().exec(
                            new String[]{
                                    "su",
                                    "-c",
                                    "id"
                            }
                    );


            BufferedReader in =
                    new BufferedReader(
                            new InputStreamReader(
                                    process.getInputStream()
                            )
                    );


            String output =
                    in.readLine();


            return output != null &&
                    output.toLowerCase()
                            .contains("uid=0");

        } catch (Exception e) {

            Log.e(
                    "LogAct",
                    "Root permission error",
                    e
            );

        } finally {

            if (process != null) {

                try {
                    process.destroy();
                } catch (Exception ignored) {
                }
            }
        }

        return false;
    }


    // =========================================================
    // PERMISSIONS
    // =========================================================

    private boolean allPermissionsGranted() {

        if (Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.TIRAMISU) {

            return true;
        }


        boolean readGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED;


        boolean writeGranted = true;


        if (Build.VERSION.SDK_INT <
                Build.VERSION_CODES.Q) {

            writeGranted =
                    ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ) == PackageManager.PERMISSION_GRANTED;
        }


        return readGranted && writeGranted;
    }


    private void checkAndRequestAllPermissions() {

        List<String> needed =
                new ArrayList<>();


        if (Build.VERSION.SDK_INT <
                Build.VERSION_CODES.TIRAMISU) {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED) {

                needed.add(
                        Manifest.permission.READ_EXTERNAL_STORAGE
                );
            }


            if (Build.VERSION.SDK_INT <
                    Build.VERSION_CODES.Q) {

                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED) {

                    needed.add(
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                    );
                }
            }
        }


        if (!needed.isEmpty()) {

            ActivityCompat.requestPermissions(
                    this,
                    needed.toArray(
                            new String[0]
                    ),
                    PERMISSION_REQUEST_CODE
            );

            return;
        }


        // -----------------------------------------------------
        // UNKNOWN APP SOURCES
        // -----------------------------------------------------

        if (Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.O) {

            try {

                if (!getPackageManager()
                        .canRequestPackageInstalls()) {

                    Intent intent =
                            new Intent(
                                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                    Uri.parse(
                                            "package:" +
                                                    getPackageName()
                                    )
                            );

                    startActivityForResult(
                            intent,
                            REQUEST_MANAGE_UNKNOWN_APP_SOURCES
                    );

                    return;
                }

            } catch (Exception e) {

                Log.e(
                        "LogAct",
                        "Unknown sources error",
                        e
                );
            }
        }


        // -----------------------------------------------------
        // WRITE SETTINGS
        // -----------------------------------------------------

        try {

            if (!Settings.System.canWrite(this)) {

                Intent intent =
                        new Intent(
                                Settings.ACTION_MANAGE_WRITE_SETTINGS,
                                Uri.parse(
                                        "package:" +
                                                getPackageName()
                                )
                        );

                startActivityForResult(
                        intent,
                        REQUEST_WRITE_SETTINGS
                );
            }

        } catch (Exception e) {

            Log.e(
                    "LogAct",
                    "Write settings error",
                    e
            );
        }
    }


    // =========================================================
    // MAIN ACTIVITY
    // =========================================================

    private void proceedToMain() {

        try {

            Intent i =
                    new Intent(
                            getApplicationContext(),
                            MAct.class
                    );


            String expiryTime =
                    Prefs.with(this)
                            .read(
                                    "expiry_time",
                                    ""
                            );


            if (!expiryTime.isEmpty()) {

                i.putExtra(
                        "EXPIRY_TIME",
                        expiryTime
                );
            }


            startActivity(i);

            overridePendingTransition(
                    android.R.anim.fade_in,
                    android.R.anim.fade_out
            );

            finish();

        } catch (Exception e) {

            Log.e(
                    "LogAct",
                    "proceedToMain error",
                    e
            );

            Toast.makeText(
                    this,
                    "تعذر فتح الصفحة الرئيسية",
                    Toast.LENGTH_LONG
            ).show();
        }
    }


    // =========================================================
    // PERMISSION RESULT
    // =========================================================

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );


        if (requestCode !=
                PERMISSION_REQUEST_CODE) {

            return;
        }


        boolean allGranted = true;


        for (int res :
                grantResults) {

            if (res !=
                    PackageManager.PERMISSION_GRANTED) {

                allGranted = false;
                break;
            }
        }


        if (!allGranted) {

            new AlertDialog.Builder(this)
                    .setTitle(PERM_TITLE)
                    .setMessage(GRANT_PERM_MSG)
                    .setPositiveButton(
                            GRANT_BTN,
                            (dialog, which) ->
                                    checkAndRequestAllPermissions()
                    )
                    .setNegativeButton(
                            CANCEL_BTN,
                            null
                    )
                    .show();

        } else {

            checkAndRequestAllPermissions();
        }
    }


    // =========================================================
    // ACTIVITY RESULT
    // =========================================================

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );


        if (requestCode ==
                REQUEST_MANAGE_UNKNOWN_APP_SOURCES ||
                requestCode ==
                        REQUEST_WRITE_SETTINGS) {

            checkAndRequestAllPermissions();
        }
    }


    // =========================================================
    // RESUME
    // =========================================================

    @Override
    protected void onResume() {

        super.onResume();

        setupSystemBars();
    }


    // =========================================================
    // BACK
    // =========================================================

    @Override
    public void onBackPressed() {

        finishAffinity();

        overridePendingTransition(
                android.R.anim.fade_in,
                android.R.anim.fade_out
        );
    }
}

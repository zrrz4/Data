package pubgm.loader.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import android.app.ProgressDialog;
import android.os.Handler;
import android.widget.Toast;
import java.util.Locale;
import net.lingala.zip4j.ZipFile;
import pubgm.loader.LogAct;
import pubgm.loader.MAct;
import pubgm.loader.SAct;
import pubgm.loader.R;

public class DownC extends AsyncTask<String, String, String> {
    int values= 0;
    String val = "0%";
    private Context context;


    ProgressDialog loding2;
    @SuppressLint
    ("UseCompatLoadingForDrawables")
    public DownC(Context context){
        this.context = context;
        loding2 = new ProgressDialog(context,R.style.mydialog);
        loding2.setTitle(context.getString(R.string.status));
        loding2.setMessage("0 %");
        loding2.setCancelable(false);
    }
    @Override
    protected void onPreExecute() {
		for (File pppp :context.getCacheDir().listFiles())
			pppp.delete();
		for (File okok : context.getFilesDir().listFiles())
			okok.delete();
        loding2.show();

    }
    @Override
    protected String doInBackground(String... strings) {
        try {
            URL url = new URL(strings[1]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            int lenghtOfFile = connection.getContentLength();
            InputStream input = connection.getInputStream();
            File pathBase = new File(context.getCacheDir().getPath());
            String filen= "sock.zip";
            if (!pathBase.exists()){
                pathBase.mkdirs();
            } 
            File pathOutput = new File(pathBase +"/"+ filen);
            OutputStream output = new FileOutputStream(pathOutput.toString());
            byte data[] = new byte[1024];
            long total = 0;
            int count;

            while ((count = input.read(data)) != -1) {
                total += count;
                publishProgress("" + (int)((total*100)/lenghtOfFile));
                output.write(data, 0, count);
            }
            if (pathOutput.exists()){
                new File(pathOutput.toString()).setExecutable(true, true);
            } else{

            }
            output.close();
            input.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    } 

    @SuppressLint("SetTextI18n")
    @Override
    protected void onProgressUpdate(String... progress) {
        
        loding2.setMessage(progress[0] + "%");
    }

    @Override
    protected void onPostExecute(String result) {
        loding2.dismiss();
        final File pathBase = new File(context.getFilesDir().getPath());
        final File pathBase2 = new File(context.getCacheDir().getPath());
        try {
           new ZipFile(pathBase2+"/sock.zip",SAct.a[3].toCharArray()).extractAll(pathBase+"/");
        } catch (Exception e) {
            e.printStackTrace();
 
        }
     
		if(new File(pathBase2+"/sock.zip").exists()){
			context.startActivity(new Intent(context,MAct.class));
            
		} else {
			Tmes.getInstance(context).sToas("Failed download! \ncheck yourconection");
		}
       
        
    }
    private void ExecuteElf(String shell) {
        String s=shell;
        try {
            Runtime.getRuntime().exec(s, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void excpp(String path) {
        try {
            ExecuteElf("chmod 777 " + context.getFilesDir() + path);
            ExecuteElf(context.getFilesDir() + path);
            ExecuteElf("su -c chmod 777 " + context.getFilesDir() + path);
            ExecuteElf("su -c " + context.getFilesDir() + path);
        } catch (Exception e) {

        }
    }

}





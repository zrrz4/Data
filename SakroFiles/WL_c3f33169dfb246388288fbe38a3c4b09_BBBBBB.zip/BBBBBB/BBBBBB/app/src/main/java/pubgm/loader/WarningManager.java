package pubgm.loader;

import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

public class WarningManager {

    private static final String BASE_URL =
            "https://github.com/zoroczoromm-cyber/Generalvip/raw/refs/heads/main/news.json";

    public static void checkWarning(Context context) {

        if (context == null) {
            return;
        }

        try {

            RequestQueue queue =
                    Volley.newRequestQueue(
                            context.getApplicationContext()
                    );

            String url =
                    BASE_URL
                            + "?t="
                            + System.currentTimeMillis();

            StringRequest request =
                    new StringRequest(
                            Request.Method.GET,
                            url,

                            response -> {

                                try {

                                    if (response == null
                                            || response.trim().isEmpty()) {
                                        return;
                                    }

                                    JSONObject obj =
                                            new JSONObject(response);

                                    boolean show =
                                            obj.optBoolean(
                                                    "show",
                                                    false
                                            );

                                    if (!show) {
                                        return;
                                    }

                                    String title =
                                            obj.optString(
                                                    "title",
                                                    ""
                                            );

                                    String message =
                                            obj.optString(
                                                    "message",
                                                    ""
                                            );

                                    showDialog(
                                            context,
                                            title,
                                            message
                                    );

                                } catch (Exception e) {

                                    e.printStackTrace();
                                }
                            },

                            error -> {
                                // تجاهل خطأ الاتصال
                            }
                    ) {

                        @Override
                        public java.util.Map<String, String> getHeaders() {

                            java.util.Map<String, String> headers =
                                    new java.util.HashMap<>();

                            headers.put(
                                    "Cache-Control",
                                    "no-cache"
                            );

                            return headers;
                        }
                    };

            queue.getCache().clear();
            queue.add(request);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    private static void showDialog(
            Context context,
            String title,
            String message
    ) {

        if (context == null) {
            return;
        }

        try {

            Dialog dialog =
                    new Dialog(context);

            dialog.requestWindowFeature(
                    Window.FEATURE_NO_TITLE
            );

            dialog.setContentView(
                    R.layout.warning_layout
            );

            TextView warningTitle =
                    dialog.findViewById(
                            R.id.warningTitle
                    );

            TextView warningMessage =
                    dialog.findViewById(
                            R.id.warningMessage
                    );

            Button btnDone =
                    dialog.findViewById(
                            R.id.btnDone
                    );

            if (warningTitle != null) {
                warningTitle.setText(
                        title == null ? "" : title
                );
            }

            if (warningMessage != null) {
                warningMessage.setText(
                        message == null ? "" : message
                );
            }

            if (btnDone != null) {

                btnDone.setOnClickListener(
                        v -> dialog.dismiss()
                );
            }

            Window window =
                    dialog.getWindow();

            if (window != null) {

                hideNavigationBar(window);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    window.setNavigationBarContrastEnforced(false);
                }

                window.setNavigationBarColor(
                        android.graphics.Color.TRANSPARENT
                );
            }

            dialog.setOnShowListener(
                    d -> {

                        try {

                            Window dialogWindow =
                                    dialog.getWindow();

                            if (dialogWindow != null) {

                                hideNavigationBar(
                                        dialogWindow
                                );
                            }

                        } catch (Exception e) {

                            e.printStackTrace();
                        }
                    }
            );

            dialog.show();

            try {

                Window dialogWindow =
                        dialog.getWindow();

                if (dialogWindow != null) {
                    hideNavigationBar(
                            dialogWindow
                    );
                }

            } catch (Exception e) {

                e.printStackTrace();
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    private static void hideNavigationBar(
            Window window
    ) {

        if (window == null) {
            return;
        }

        try {

            int flags =
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;

            window.getDecorView().setSystemUiVisibility(
                    flags
            );

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {

                window.getDecorView().setSystemUiVisibility(
                        flags
                );
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}
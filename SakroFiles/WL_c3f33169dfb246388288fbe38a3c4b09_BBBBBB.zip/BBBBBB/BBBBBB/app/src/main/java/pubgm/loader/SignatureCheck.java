package pubgm.loader;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.io.OutputStream;
import org.lsposed.lsparanoid.Obfuscate;
@Obfuscate

public class SignatureCheck {
    private static final String VALID_SIGNATURE = "eb0baaaee9f952be8c2fdfb83e3bcd84518d45e247c555a89407a468f3469ad3"; // Replace with your actual SHA-256 signature

    public static boolean isSignatureValid(PackageManager pm, String packageName) {
        try {
            PackageInfo packageInfo = pm.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES);
            byte[] signature = packageInfo.signingInfo.getSigningCertificateHistory()[0].toByteArray();
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(signature);
            StringBuilder hexString = new StringBuilder();

            for (byte b : digest) {
                String hex = Integer.toHexString(0xFF & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }

            String calculatedSignature = hexString.toString();
            Log.d("SignatureCheck", "Calculated Signature: " + calculatedSignature);

            return VALID_SIGNATURE.equalsIgnoreCase(calculatedSignature);
        } catch (PackageManager.NameNotFoundException | NoSuchAlgorithmException e) {
            e.printStackTrace();
            return false;
        }
    }
}
 

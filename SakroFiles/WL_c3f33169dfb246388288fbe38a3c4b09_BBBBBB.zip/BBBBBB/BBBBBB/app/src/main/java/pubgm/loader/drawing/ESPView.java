package pubgm.loader.drawing;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.SystemClock;
import android.util.LruCache;
import android.view.View;
import pubgm.loader.R;
import pubgm.loader.drawing.Overlay;
import java.util.concurrent.TimeUnit;

import static pubgm.loader.drawing.Overlay.getConfig;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.FileInputStream;

public class ESPView extends View implements Runnable {
    Paint mStrokePaint;
    Paint mFilledPaint;
    Paint mTextPaint;
    Thread mThread;
    Paint p,p2;
    Bitmap[] WEP = new Bitmap[127];
    Bitmap[] VEH = new Bitmap[24];


    Bitmap[] OTHER = new Bitmap[7]; //dihitung dari 0

    private static final int[] OTH_NAME = {
		R.drawable.ic_clear_enemy,
		R.drawable.ic_clear_boot,
		R.drawable.ic_danger_enemy,
		R.drawable.ic_danger_boot,
		R.drawable.ic_warning,
		R.drawable.ic_boot,
		R.drawable.ic_alert
    };

    Bitmap bitmap,out;
    int FPS = 120;
    static long sleepTime;
	public static int fsleepTime;
    private  static int itemPosition;
	private static LruCache<Integer, Bitmap> bitmapCache = new LruCache<>(10 * 1024 * 1024);

    public ESPView(Context context) {
        super(context, null, 0);
		fsleepTime=1000/FPS;
        InitializePaints();
        setFocusableInTouchMode(false);
        setBackgroundColor(Color.TRANSPARENT);
        sleepTime = fsleepTime;
        mThread = new Thread(this);
        mThread.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (canvas != null && getVisibility() == VISIBLE) {
            ClearCanvas(canvas);
            Overlay.DrawOn(this, canvas);
			
            
        }
    }

	@Override
    public void run() {
		long ressleepTime;
        long startTime = System.nanoTime();
        try {
            TimeUnit.MILLISECONDS.sleep(sleepTime);
        } catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			return;
        }        
        long endTime = System.nanoTime();
        long elapsedTime = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);
        ressleepTime = sleepTime + (sleepTime - elapsedTime);
        //android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
	   
        while (mThread.isAlive() && !mThread.isInterrupted()) {            
            try {
                long t1 = System.currentTimeMillis();
                postInvalidate();
                long td = System.currentTimeMillis() - t1;
                Thread.sleep(Math.max(Math.min(0, ressleepTime - td), ressleepTime));
            } catch (Exception e) {
                Thread.currentThread().interrupt();
                return;
            }           
        }
    }

    public void InitializePaints() {
        mStrokePaint = new Paint();
        mStrokePaint.setStyle(Paint.Style.STROKE);
        mStrokePaint.setAntiAlias(true);
        mStrokePaint.setColor(Color.rgb(0, 0, 0));
        mStrokePaint.setTextAlign(Paint.Align.CENTER);

        mFilledPaint = new Paint();
        mFilledPaint.setStyle(Paint.Style.FILL);
        mFilledPaint.setAntiAlias(true);       
        mFilledPaint.setColor(Color.rgb(0, 0, 0));

        mTextPaint = new Paint();
        mTextPaint.setStyle(Paint.Style.FILL);
        mTextPaint.setAntiAlias(true);
        mTextPaint.setColor(Color.rgb(0, 0, 0));
        mTextPaint.setAlpha(150);
        mStrokePaint.setStrokeWidth(0.1f);
        mTextPaint.setTextAlign(Paint.Align.CENTER);
        
        
		
		p2=new Paint();
        final int bitmap_count_veh = VEH_NAME.length;
        for(int i = 0 ; i < bitmap_count_veh ; i++) {
            VEH[i] = BitmapFactory.decodeResource(getResources(), VEH_NAME[i]);
            VEH[i] = scale(VEH[i],40,40);
        }
        final int bitmap_count_wep = ITEM_NAME.length;
        for(int i = 0 ; i < bitmap_count_wep ; i++) {
            WEP[i] = BitmapFactory.decodeResource(getResources(), ITEM_NAME[i]);
            WEP[i] = scale(WEP[i],50,50);
		}
        p = new Paint();
        final int bitmap_count_oth = OTHER.length;
        for (int i = 0 ; i < bitmap_count_oth ; i++) {
            OTHER[i] = BitmapFactory.decodeResource(getResources(), OTH_NAME[i]);
            if (i == 4) {
                OTHER[i] = scale(OTHER[i], 400, 35);
            } else if (i == 5) {
                OTHER[i] = scale(OTHER[i], 22, 22);
            } else {
                OTHER[i] = scale(OTHER[i], 80, 80);
            }
        }
    }
    public void ClearCanvas(Canvas cvs) {
        cvs.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
    }

    public void DrawLine(Canvas cvs, int a, int r, int g,int b, float lineWidth, float fromX, float fromY, float toX, float toY) {
        mStrokePaint.setColor(Color.rgb(r, g, b));
        mStrokePaint.setAlpha(a);
        mStrokePaint.setStrokeWidth(lineWidth);
        cvs.drawLine(fromX, fromY, toX, toY, mStrokePaint);
    }
  
    public void DrawRect(Canvas cvs, int a, int r, int g, int b, float stroke, float x, float y, float width, float height) {
        mStrokePaint.setStrokeWidth(stroke);
        mStrokePaint.setColor(Color.rgb(r, g, b));
        mStrokePaint.setAlpha(a);
        cvs.drawRoundRect(new RectF(x, y, width, height), 5, 5, mStrokePaint);

    }

    public void DrawFilledRect(Canvas cvs, int a, int r, int g, int b, float x, float y, float width, float height) {
        mFilledPaint.setColor(Color.rgb(r, g, b));
        mFilledPaint.setAlpha(a);
        cvs.drawRoundRect(new RectF(x, y, width, height), 5, 5, mFilledPaint);

    }

    public void DebugText(String s) {
        System.out.println(s);
    }

    public void DrawText(Canvas cvs, int a, int r, int g, int b, String txt, float posX, float posY, float size) {
        mTextPaint.setARGB(a, r, g, b);
        mTextPaint.setTextSize(size);
        cvs.drawText(txt, posX, posY, mTextPaint);
    }

    


	

    
    public void DrawEnemyCountC(Canvas cvs, int a, int r, int g, int b, int x, int y, int width, int height) {
        int colors[] = {Color.TRANSPARENT, Color.rgb(r, g, b), Color.TRANSPARENT};
        GradientDrawable mDrawable = new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, colors);
        mDrawable.setShape(GradientDrawable.RECTANGLE);
        mDrawable.setGradientRadius(2.0f * 60);
        Rect mRect = new Rect(x, y, width, height);
        mDrawable.setBounds(mRect);
        cvs.save();
        mDrawable.setGradientType(GradientDrawable.LINEAR_GRADIENT);
        mDrawable.draw(cvs);
        cvs.restore();
    }
    public void DrawEnemyCount(Canvas cvs, int a, int r, int g, int b, int x, int y, int width, int height) {
        int colors[] = {Color.TRANSPARENT, Color.rgb(r,g,b), Color.TRANSPARENT};
        GradientDrawable mDrawable = new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, colors);
        mDrawable.setShape(GradientDrawable.RECTANGLE);
        mDrawable.setGradientRadius(2.0f * 60);
        Rect mRect = new Rect(x,y,width,height);
        mDrawable.setBounds(mRect);
        cvs.save();
        mDrawable.setGradientType(GradientDrawable.LINEAR_GRADIENT);
        mDrawable.draw(cvs);
        cvs.restore();
    }
   

    public void DrawName(Canvas cvs, int a, int r, int g, int b, String nametxt, int teamid, float posX, float posY, float size) {
        String[] namesp = nametxt.split(":");
        char[] nameint = new char[namesp.length];
        for (int i = 0; i < namesp.length; i++)
            nameint[i] = (char) Integer.parseInt(namesp[i]);
        String realname = new String(nameint);
        mTextPaint.setARGB(a, r, g, b);
        mTextPaint.setTextSize(size);
        cvs.drawText("(" + teamid + ")" + realname, posX, posY, mTextPaint);
    }
    
    

    public void DrawItems(Canvas cvs, String itemName, /*int a, int r, int g, int b,*/ float distance, float posX, float posY, float size) {
		int realItemGambar = getItemNum(itemName);
        String realItemName = getItemName(itemName);
        mTextPaint.setTextSize(size);
		//mTextPaint.setShadowLayer(8.0f,1.5f,1.5f,Color.BLACK/*Color.rgb(r,g,b)*/);
		if(realItemGambar!=-1 && realItemName != null )
      
			if (true && getConfig("Icon Distance")){
				cvs.drawBitmap(WEP[realItemGambar],posX - 30,posY - 40 - itemPosition,p2);
				//cvs.drawText("["+Math.round(distance)+"m]", posX, posY-11, mTextPaint);
			}else if (true && getConfig("Text Distance")){
                cvs.drawText(realItemName+"[" + Math.round(distance) + "m]", posX, posY-11, mTextPaint);
            }else if (true && getConfig("Icon Text Distance")){
                cvs.drawBitmap(WEP[realItemGambar],posX - 50,posY - 70 - itemPosition,p2);
                cvs.drawText(realItemName+"[" + Math.round(distance) + "m]", posX, posY-11, mTextPaint);

			}
			
	}
    //车辆
    public void DrawVehicles(Canvas cvs, String VehicleName, /*int a, int r, int g, int b,*/ float distance, float posX, float posY, float size) {
		int realVehicleGambar = getVehicleName(VehicleName);
        String realVehicleName = VehicleName(VehicleName);
        mTextPaint.setColor(Color.WHITE);       
        //mTextPaint.setAlpha(150);
        mTextPaint.setTextSize(size);
		mTextPaint.setShadowLayer(10, 1, 1, Color.rgb(1,1,1));
        if(realVehicleGambar!=-1 && realVehicleName != null)
			if (true && getConfig("Icon")){
				cvs.drawBitmap(VEH[realVehicleGambar],posX - 20,posY - 40 - 30,p);
				}else if (true && getConfig("Text Distance")){
					cvs.drawText(realVehicleName+"[" + Math.round(distance) + "m]", posX, posY-11, mTextPaint);
				}else if (true && getConfig("Icon Text Distance")){
					cvs.drawBitmap(VEH[realVehicleGambar],posX - 20,posY - 40 - 30,p);
					cvs.drawText(realVehicleName+"[" + Math.round(distance) + "m]", posX, posY-11, mTextPaint);
					
			} else {//Text Only
				cvs.drawText(realVehicleName+" ("+Math.round(distance)+"m)", posX, posY, mTextPaint);
			}
	}



    public void DrawCircle(Canvas cvs, int a, int r, int g, int b, float posX, float posY, float radius, float stroke) {
        mStrokePaint.setARGB(a, r, g, b);
        mStrokePaint.setStrokeWidth(stroke);
        cvs.drawCircle(posX, posY, radius, mStrokePaint);
    }


    

    public void DrawFilledCircle(Canvas cvs, int a, int r, int g, int b, float posX, float posY, float radius) {
        mFilledPaint.setColor(Color.rgb(r, g, b));
        mFilledPaint.setAlpha(a);
        cvs.drawCircle(posX, posY, radius, mFilledPaint);
    }

    public void DrawOTH(Canvas cvs, int image_number, float X, float Y) {
        cvs.drawBitmap(OTHER[image_number], X, Y, p);
    }
    public void DrawWeapon(Canvas cvs, int a, int r, int g, int b, int id, int ammo, int ammo2, float posX, float posY, float size) {
        mTextPaint.setARGB(a, r, g, b);
        mTextPaint.setTextSize(size);
        String wname = getWeapon(id);
        if (wname != null) {
            if (wname == "Sickle" || wname == "Machete" || wname == "Crowbar" || wname == "Pan") {
                cvs.drawText(wname, posX, posY, mTextPaint);
            }else {
                cvs.drawText(wname + "(" + ammo + "/" + ammo2 + ")", posX, posY, mTextPaint);
            }
        } 
    }
    public void DrawWeaponIcon(Canvas cvs, int id, float posX, float posY) {
        Bitmap cachedBitmap = bitmapCache.get(id);
        if (cachedBitmap != null) {
            cvs.drawBitmap(cachedBitmap, posX, posY - 43, null);
        } else {
                        int weapon_icon = getWeaponIcon(id);
            if (weapon_icon != 0) {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), weapon_icon);
                Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, 100, 43, false);
                // Simpan gambar yang sudah di-decode ke dalam cache
                bitmapCache.put(id, scaledBitmap);
                cvs.drawBitmap(scaledBitmap, posX, posY - 43, null);
			} else {
				cvs.drawText(String.valueOf(id), posX, posY -43, mTextPaint);
			}
           }
        }
	
    private String getWeapon(int id) {
        if (id == 101006)
            return "AUG";

        if (id == 101008)
            return "M762" ;

        if (id == 101003)
            return "SCAR-L";

        if (id == 101004)
            return "M416";

        if (id == 101002)
            return "M16A4";

        if (id == 101009)
            return "MK47";

        if (id == 101010)
            return "G36C";

        if (id == 101007)
            return "QBZ";

        if (id == 101001)
            return "AKM";

        if (id == 101005)
            return "Groza";

        if (id == 102005)
            return "Bizon";

        if (id == 102004)
            return "TommyGun";

        if (id == 102007)
            return "MP5K";

        if (id == 102002)
            return "UMP";

        if (id == 102003)
            return "Vector";

        if (id == 102001)
            return "Uzi";

        if (id == 105002)
            return "DP28";

        if (id == 105001)
            return "M249";
            
        if (id == 101012)
            return "Honey Badger";
       
        if (id == 101101)
            return "ASM AR";
            
        if (id == 103100)
            return "MK12";   

        //snipers

        if (id == 103003)
            return "AWM";

        if (id == 103010)
            return "QBU";

        if (id == 103009)
            return "SLR";

        if (id == 103004)
            return "SKS";

        if (id == 103006)
            return "Mini14";

        if (id == 103002)
            return "M24";

        if (id == 103001)
            return "Kar98k";

        if (id == 103005)
            return "VSS";

        if (id == 103008)
            return "Win94";

        if (id == 103007)
            return "Mk14";
        
        if (id == 101100)
            return "FAMAS";    

//shotguns and hand weapons
        if (id == 104003)
            return "S12K";

        if (id == 104004)
            return "DBS";

        if (id == 104001)
            return "S686";

        if (id == 104002)
            return "S1897";

        if (id == 108003)
            return "Sickle";

        if (id == 108001)
            return "Machete";

        if (id == 108002)
            return "Crowbar";

        if (id == 107001)
            return "CrossBow";
        
        if (id == 107009)
            return "Explosive Bow";

        if (id == 108004)
            return "Pan";
            
        if (id == 104101)
            return "M1014";

        //pistols

        if (id == 106006)
            return "SawedOff";
        if (id == 106003)
            return "R1895";
        if (id == 106008)
            return "Vz61";
        if (id == 106001)
            return "P92";
        if (id == 106004)
            return "P18C";
        if (id == 106005)
            return "R45";
        if (id == 106002)
            return "P1911";
        if (id == 106010)
            return "Desert";
        if (id == 103011)
            return "Mosin";
        if (id == 107005)
            return "PanzerFaust";
        return "";

    }
	
	
	
	
    private int getWeaponIcon(int id) {
        if (id == 101006) 
            return R.drawable.c101006;
        if (id == 101008)
            return R.drawable.c101008;
        if (id == 101003)
            return R.drawable.c101003;
        if (id == 101004)
            return R.drawable.c101004;
        if (id == 101002)
            return R.drawable.c101002;
        if (id == 101009)
            return R.drawable.c101009;
        if (id == 101010)
            return R.drawable.c101010;
        if (id == 101007)
            return R.drawable.c101007;
        if (id == 101001)
            return R.drawable.c101001;
        if (id == 101005)
            return R.drawable.c101005;
        if (id == 102005)
            return R.drawable.c102005;
        if (id == 102004)
            return R.drawable.c102004;
        if (id == 102007)
            return R.drawable.c102007;
        if (id == 102002)
            return R.drawable.c102002;
        if (id == 102003)
            return R.drawable.c102003;
        if (id == 102001)
            return R.drawable.c102001;
        if (id == 105002)
            return R.drawable.c105002;
        if (id == 105001)
            return R.drawable.c105001;
		/*
		 if (id == 101012)
		 return R.drawable.c101012;
		 honney budger

		 if (id == 101101)
		 return R.drawable.c101101;
		 asmr

		 if (id == 103100)
		 return MK12;   
		 */
        //snipers
        if (id == 103003)
            return R.drawable.c103003;
        if (id == 103010)
            return R.drawable.c103010;
        if (id == 103009)
            return R.drawable.c103009;
        if (id == 103004)
            return R.drawable.c103004;
        if (id == 103006)
            return R.drawable.c103006;
        if (id == 103002)
            return R.drawable.c103002;
        if (id == 103001)
            return R.drawable.c103001;
        if (id == 103005)
            return R.drawable.c103005;
        if (id == 103008)
            return R.drawable.c103008;
        if (id == 103007)
            return R.drawable.c103007;
		/*
		 if (id == 101100)
		 return FAMAS;    
		 */
//shotguns and hand weapons
        if (id == 104003)
            return R.drawable.c104003;
        if (id == 104004)
            return R.drawable.c104004;
        if (id == 104001)
            return R.drawable.c104001;
        if (id == 104002)
            return R.drawable.c104002;
        if (id == 108003)
            return R.drawable.c108003;
        if (id == 108001)
            return R.drawable.c108001;
        if (id == 108002)
            return R.drawable.c108002;
        if (id == 107001)
            return R.drawable.c107001;
		/*
		 if (id == 107009)
		 return Explosive Bow;
		 */
        if (id == 108004)
            return R.drawable.c108004;
		/*
		 if (id == 104101)
		 return M1014;
		 */
        //pistols
        if (id == 106006)
            return R.drawable.c106006;
        if (id == 106003)
            return R.drawable.c106003;
        if (id == 106008)
            return R.drawable.c106008;
        if (id == 106001)
            return R.drawable.c106001;
        if (id == 106004)
            return R.drawable.c106004;
        if (id == 106005)
            return R.drawable.c106005;
        if (id == 106002)
            return R.drawable.c106002;
        if (id == 106010)
            return R.drawable.c106010;
		/*
		 if (id == 103011)
		 return Mosin;
		 if (id == 107005)
		 return PanzerFaust;*/
        if (id == 11223344)
            return R.drawable.fuckc;
        return 0;
    }

    private int getItemNum(String str) {
        if (str.contains("MZJ_8X") && getConfig(String.valueOf(R.id.is8x))) {
            this.mTextPaint.setARGB(255, 247, 99, 245);
            return 0;
        } else if (str.contains("MZJ_2X") && getConfig(String.valueOf(R.id.is2x))) {
            this.mTextPaint.setARGB(255, 230, 172, 226);
            return 1;
        } else if (str.contains("MZJ_HD") && getConfig(String.valueOf(R.id.isreddot))) {
            this.mTextPaint.setARGB(255, 230, 172, 226);
            return 2;
        } else if (str.contains("MZJ_3X") && getConfig(String.valueOf(R.id.is3x))) {
            this.mTextPaint.setARGB(255, 247, 99, 245);
            return 3;
        } else if (str.contains("MZJ_QX") && getConfig(String.valueOf(R.id.ishollow))) {
            this.mTextPaint.setARGB(255, 153, 75, 152);
            return 4;
        } else if (str.contains("MZJ_6X") && getConfig(String.valueOf(R.id.is6x))) {
            this.mTextPaint.setARGB(255, 247, 99, 245);
            return 5;
        } else if (str.contains("MZJ_4X") && getConfig(String.valueOf(R.id.is4x))) {
            this.mTextPaint.setARGB(255, 247, 99, 245);
            return 6;
        } else if (str.contains("MZJ_SideRMR") && getConfig(String.valueOf(R.id.iscanted))) {
            this.mTextPaint.setARGB(255, 153, 75, 152);
            return 7;
        } else if (str.contains("M416") && getConfig(String.valueOf(R.id.isM416))) {
            this.mTextPaint.setARGB(255, 115, 235, 223);
            return 8;
        } else if (str.contains("M16A4") && getConfig(String.valueOf(R.id.isM16A4))) {
            this.mTextPaint.setARGB(255, 116, 227, 123);
            return 9;
        } else if (str.contains("AUG") && getConfig(String.valueOf(R.id.isAug))) {
            this.mTextPaint.setARGB(255, 52, 224, 63);
            return 10;
        } else if (str.contains("SCAR") && getConfig(String.valueOf(R.id.isScarL))) {
            this.mTextPaint.setARGB(255, 52, 224, 63);
            return 11;
        } else if (str.contains("FAMAS") && getConfig(String.valueOf(R.id.isFAMAS))) {
            this.mTextPaint.setARGB(255, 52, 224, 63);
            return 12;
        } else if (str.contains("G36") && getConfig(String.valueOf(R.id.isG36C))) {
            this.mTextPaint.setARGB(255, 116, 227, 123);
            return 13;
        } else if (str.contains("QBZ") && getConfig(String.valueOf(R.id.isQBZ))) {
            this.mTextPaint.setARGB(255, 52, 224, 63);
            return 14;
        } else if (str.contains("AKM") && getConfig(String.valueOf(R.id.isAKM))) {
            this.mTextPaint.setARGB(255, 214, 99, 99);
            return 15;
        } else if (str.contains("M762") && getConfig(String.valueOf(R.id.isM762))) {
            this.mTextPaint.setARGB(255, 43, 26, 28);
            return 16;
        } else if (str.contains("HoneyBadger") && getConfig(String.valueOf(R.id.isHoneyBadger))) {
            this.mTextPaint.setARGB(255, 214, 99, 99);
            return 17;
        } else if (str.contains("Groza") && getConfig(String.valueOf(R.id.isGroza))) {
            this.mTextPaint.setARGB(255, 214, 99, 99);
            return 18;
        } else if (str.contains("PP19") && getConfig(String.valueOf(R.id.isBizon))) {
            this.mTextPaint.setARGB(255, 255, 246, 0);
            return 19;
        } else if (str.contains("TommyGun") && getConfig(String.valueOf(R.id.isTommygun))) {
            this.mTextPaint.setARGB(255, 207, 207, 207);
            return 20;
        } else if (str.contains("MP5K") && getConfig(String.valueOf(R.id.isMp5k))) {
            this.mTextPaint.setARGB(255, 207, 207, 207);
            return 21;
        } else if (str.contains("UMP9") && getConfig(String.valueOf(R.id.isUmp))) {
            this.mTextPaint.setARGB(255, 207, 207, 207);
            return 22;
        } else if (str.contains("Vector") && getConfig(String.valueOf(R.id.isVector))) {
            this.mTextPaint.setARGB(255, 255, 246, 0);
            return 23;
        } else if (str.contains("MachineGun_Uzi") && getConfig(String.valueOf(R.id.isUzi))) {
            this.mTextPaint.setARGB(255, 255, 246, 0);
            return 24;
        } else if (str.contains("BP_MachineGun_P90_Wrapper_C") && getConfig(String.valueOf(R.id.isP90))) {
            this.mTextPaint.setARGB(255, 0, 255, 0);
            return 25;
        } else if (str.contains("DP28") && getConfig(String.valueOf(R.id.isDp28))) {
            this.mTextPaint.setARGB(255, 43, 26, 28);
            return 26;
        } else if (str.contains("M249") && getConfig(String.valueOf(R.id.isM249))) {
            this.mTextPaint.setARGB(255, 247, 99, 245);
            return 27;
        } else if (str.contains("BP_Other_MG3_Wrapper_C") && getConfig(String.valueOf(R.id.isMg3))) {
            this.mTextPaint.setARGB(225, 255, 255, 255);
            return 28;
        } else if (str.contains("AWM") && getConfig(String.valueOf(R.id.isawm))) {
            this.mTextPaint.setColor(Color.BLACK);
            return 29;
        } else if (str.contains("AMR") && getConfig(String.valueOf(R.id.isamr))) {
            this.mTextPaint.setARGB(255, 247, 99, 245);
            return 30;
        } else if (str.contains("Kar98k") && getConfig(String.valueOf(R.id.iskar98k))) {
            this.mTextPaint.setARGB(255, 247, 99, 245);
            return 31;
        } else if (str.contains("M24") && getConfig(String.valueOf(R.id.ism24))) {
            this.mTextPaint.setARGB(255, 247, 99, 245);
            return 32;
        } else if (str.contains("Win94") && getConfig(String.valueOf(R.id.iswin94))) {
            this.mTextPaint.setARGB(255, 207, 207, 207);
            return 33;
        } else if (str.contains("Sniper_Mosin") && getConfig(String.valueOf(R.id.ismosin))) {
            this.mTextPaint.setARGB(255, 0, 0, 0);
            return 34;
        } else if (str.contains("QBU") && getConfig(String.valueOf(R.id.isqbu))) {
            this.mTextPaint.setARGB(255, 207, 207, 207);
            return 35;
        } else if (str.contains("S12K") && getConfig(String.valueOf(R.id.iss12k))) {
            this.mTextPaint.setARGB(255, 153, 109, 109);
            return 36;
        } else if (str.contains("SKS") && getConfig(String.valueOf(R.id.issks))) {
            this.mTextPaint.setARGB(255, 43, 26, 28);
            return 37;
        } else if (str.contains("Mini14") && getConfig(String.valueOf(R.id.ismini14))) {
            this.mTextPaint.setARGB(255, 247, 99, 245);
            return 38;
        } else if (str.contains("Sniper_MK12") && getConfig(String.valueOf(R.id.ismk12))) {
            this.mTextPaint.setARGB(255, 153, 0, 0);
            return 39;
        } else if (str.contains("Mk47") && getConfig(String.valueOf(R.id.isMK47))) {
            this.mTextPaint.setARGB(255, 247, 99, 245);
            return 40;
        } else if (str.contains("VSS") && getConfig(String.valueOf(R.id.isVss))) {
            this.mTextPaint.setARGB(255, 255, 246, 0);
            return 41;
        } else if (str.contains("Mk14") && getConfig(String.valueOf(R.id.ismk14))) {
            this.mTextPaint.setColor(Color.BLACK);
            return 42;
        } else if (str.contains("AN94") && getConfig(String.valueOf(R.id.isASMAR))) {
            this.mTextPaint.setARGB(255, 52, 224, 63);
            return 43;    
        } else if (str.contains("ShotGun_DP12") && getConfig(String.valueOf(R.id.isdbs))) {
            this.mTextPaint.setARGB(255, 153, 109, 109);
            return 44;
        } else if (str.contains("Neostead2000") && getConfig(String.valueOf(R.id.isns2000))) {
            this.mTextPaint.setARGB(255, 153, 109, 109);
            return 45;     
        } else if (str.contains("S686") && getConfig(String.valueOf(R.id.iss686))) {
            this.mTextPaint.setARGB(255, 153, 109, 109);
            return 46;
        } else if (str.contains("S1897") && getConfig(String.valueOf(R.id.iss1897))) {
            this.mTextPaint.setARGB(255, 153, 109, 109);
            return 47;
        } else if (str.contains("M1014") && getConfig(String.valueOf(R.id.isM1014))) {
            this.mTextPaint.setARGB(255, 153, 109, 109);
            return 48;
        } else if (str.contains("Ammo_762mm") && getConfig(String.valueOf(R.id.is762mm))) {
            this.mTextPaint.setARGB(255, 92, 36, 28);
            return 49;
        } else if (str.contains("Ammo_45AC") && getConfig(String.valueOf(R.id.is45acp))) {
            this.mTextPaint.setColor(-3355444);
            return 50;
        } else if (str.contains("Ammo_556mm") && getConfig(String.valueOf(R.id.is556mm))) {
            this.mTextPaint.setColor(-16711936);
            return 51;
        } else if (str.contains("Ammo_9mm") && getConfig(String.valueOf(R.id.is9mm))) {
            this.mTextPaint.setColor(Color.YELLOW);
            return 52;
        } else if (str.contains("Ammo_300Magnum") && getConfig(String.valueOf(R.id.is300magnum))) {
            this.mTextPaint.setColor(Color.BLACK);
            return 53;
        } else if (str.contains("Ammo_50BMG") && getConfig(String.valueOf(R.id.is50bmg))) {
            this.mTextPaint.setColor(Color.BLACK);
            return 54;           
        } else if (str.contains("Ammo_12Guage") && getConfig(String.valueOf(R.id.is12guage))) {
            this.mTextPaint.setARGB(255, 156, 91, 81);
            return 54;
        } else if (str.contains("Ammo_Bolt") && getConfig(String.valueOf(R.id.isarrow))) {
            this.mTextPaint.setARGB(255, 156, 113, 81);
            return 55;
        } else if (str.contains("Bag_Lv3") && getConfig(String.valueOf(R.id.isbags3))) {
            this.mTextPaint.setARGB(255, 36, 83, 255);
            return 56;
        } else if (str.contains("Bag_Lv1") && getConfig(String.valueOf(R.id.isbags1))) {
            this.mTextPaint.setARGB(255, 127, 154, 250);
            return 57;
        } else if (str.contains("Bag_Lv2") && getConfig(String.valueOf(R.id.isbags2))) {
            this.mTextPaint.setARGB(255, 77, 115, 255);
            return 58;
        } else if (str.contains("Armor_Lv2") && getConfig(String.valueOf(R.id.isvest2))) {
            this.mTextPaint.setARGB(255, 77, 115, 255);
            return 59;
        } else if (str.contains("Armor_Lv1") && getConfig(String.valueOf(R.id.isvest1))) {
            this.mTextPaint.setARGB(255, 127, 154, 250);
            return 60;
        } else if (str.contains("Armor_Lv3") && getConfig(String.valueOf(R.id.isvest3))) {
            this.mTextPaint.setARGB(255, 36, 83, 255);
            return 61;
        } else if (str.contains("Helmet_Lv2") && getConfig(String.valueOf(R.id.ishelm2))) {
            this.mTextPaint.setARGB(255, 77, 115, 255);
            return 62;
        } else if (str.contains("Helmet_Lv1") && getConfig(String.valueOf(R.id.ishelm1))) {
            this.mTextPaint.setARGB(255, 127, 154, 250);
            return 63;
        } else if (str.contains("Helmet_Lv3") && getConfig(String.valueOf(R.id.ishelm3))) {
            this.mTextPaint.setARGB(255, 36, 83, 255);
            return 64;
        } else if (str.contains("Pills") && getConfig(String.valueOf(R.id.ispainkiller))) {
            this.mTextPaint.setARGB(255, 227, 91, 54);
            return 65;
        } else if (str.contains("Injection") && getConfig(String.valueOf(R.id.isinjecti))) {
            this.mTextPaint.setARGB(255, 204, 193, 190);
            return 66;
        } else if (str.contains("Drink") && getConfig(String.valueOf(R.id.isenergydrink))) {
            this.mTextPaint.setARGB(255, 54, 175, 227);
            return 67;
        } else if (str.contains("Firstaid") && getConfig(String.valueOf(R.id.isfirstaid))) {
            this.mTextPaint.setARGB(255, 194, 188, 109);
            return 68;
        } else if (str.contains("Bandage") && getConfig(String.valueOf(R.id.isbandage))) {
            this.mTextPaint.setARGB(255, 43, 189, 48);
            return 69;
        } else if (str.contains("FirstAidbox") && getConfig(String.valueOf(R.id.ismedkit))) {
            this.mTextPaint.setARGB(255, 0, 171, 6);
            return 70;
        } else if (str.contains("Grenade_Stun") && getConfig(String.valueOf(R.id.isstung))) {
            this.mTextPaint.setARGB(255, 204, 193, 190);
            return 71;
        } else if (str.contains("Grenade_Shoulei") && getConfig(String.valueOf(R.id.isgranade))) {
            this.mTextPaint.setARGB(255, 2, 77, 4);
            return 72;
        } else if (str.contains("Grenade_Smoke") && getConfig(String.valueOf(R.id.issmoke))) {
            this.mTextPaint.setColor(-1);
            return 73;
        } else if (str.contains("Grenade_Burn") && getConfig(String.valueOf(R.id.ismolotov))) {
            this.mTextPaint.setARGB(255, 230, 175, 64);
            return 74;
        } else if (str.contains("Ghillie") && getConfig(String.valueOf(R.id.isghilliesuit))) {
            this.mTextPaint.setARGB(255, 139, 247, 67);
            return 75;
        } else if (str.contains("CheekPad") && getConfig(String.valueOf(R.id.ischeeckpad))) {
            this.mTextPaint.setARGB(255, 112, 55, 55);
            return 76;
        } else if (str.contains("Flare") && getConfig(String.valueOf(R.id.isfalregun))) {
            this.mTextPaint.setARGB(255, 242, 63, 159);
            return 77;

        } else if (str.contains("Large_FlashHider") && getConfig(String.valueOf(R.id.isflashhiderar))) {
            this.mTextPaint.setARGB(255, 255, 213, 130);
            return 79;
        } else if (str.contains("QK_Large_C") && getConfig(String.valueOf(R.id.isarcompe))) {
            this.mTextPaint.setARGB(255, 255, 213, 130);
            return 80;
        } else if (str.contains("Mid_FlashHider") && getConfig(String.valueOf(R.id.isflashhidersmg))) {
            this.mTextPaint.setARGB(255, 255, 213, 130);
            return 81;
        } else if (str.contains("QT_A_") && getConfig(String.valueOf(R.id.istacticalstock))) {
            this.mTextPaint.setARGB(255, 158, 222, 195);
            return 82;
        } else if (str.contains("DuckBill") && getConfig(String.valueOf(R.id.isduckbill))) {
            this.mTextPaint.setARGB(255, 158, 222, 195);
            return 83;
        } else if (str.contains("Sniper_FlashHider") && getConfig(String.valueOf(R.id.isflashhidersnip))) {
            this.mTextPaint.setARGB(255, 158, 222, 195);
            return 84;
        } else if (str.contains("Mid_Suppressor") && getConfig(String.valueOf(R.id.issuppresoramg))) {
            this.mTextPaint.setARGB(255, 158, 222, 195);
            return 85;
        } else if (str.contains("HalfGrip") && getConfig(String.valueOf(R.id.ishalfgrip))) {
            this.mTextPaint.setARGB(255, 155, 189, 222);
            return 86;
        } else if (str.contains("Choke") && getConfig(String.valueOf(R.id.ischoke))) {
            this.mTextPaint.setARGB(255, 155, 189, 222);
            return 87;
        } else if (str.contains("QT_UZI") && getConfig(String.valueOf(R.id.isstockmicrouzi))) {
            this.mTextPaint.setARGB(255, 155, 189, 222);
            return 88;
        } else if (str.contains("QK_Sniper") && getConfig(String.valueOf(R.id.issnipercompe))) {
            this.mTextPaint.setARGB(255, 60, 127, 194);
            return 89;
        } else if (str.contains("Sniper_Suppressor") && getConfig(String.valueOf(R.id.issupsniper))) {
            this.mTextPaint.setARGB(255, 60, 127, 194);
            return 90;
        } else if (str.contains("Large_Suppressor") && getConfig(String.valueOf(R.id.issupar))) {
            this.mTextPaint.setARGB(255, 60, 127, 194);
            return 91;
        } else if (str.contains("Sniper_EQ_") && getConfig(String.valueOf(R.id.isexqdsniper))) {
            this.mTextPaint.setARGB(255, 193, 140, 222);
            return 92;
        } else if (str.contains("Mid_Q_") && getConfig(String.valueOf(R.id.isqdsmg))) {
            this.mTextPaint.setARGB(255, 193, 163, 209);
            return 93;
        } else if (str.contains("Mid_E_") && getConfig(String.valueOf(R.id.isexsmg))) {
            this.mTextPaint.setARGB(255, 193, 163, 209);
            return 94;
        } else if (str.contains("Sniper_Q_") && getConfig(String.valueOf(R.id.isqdsniper))) {
            this.mTextPaint.setARGB(255, 193, 163, 209);
            return 95;
        } else if (str.contains("Sniper_E_") && getConfig(String.valueOf(R.id.isexsniper))) {
            this.mTextPaint.setARGB(255, 193, 163, 209);
            return 96;
        } else if (str.contains("Large_E_") && getConfig(String.valueOf(R.id.isexar))) {
            this.mTextPaint.setARGB(255, 193, 163, 209);
            return 97;
        } else if (str.contains("Large_EQ_") && getConfig(String.valueOf(R.id.isexqdar))) {
            this.mTextPaint.setARGB(255, 193, 140, 222);
            return 99;
        } else if (str.contains("Large_Q_") && getConfig(String.valueOf(R.id.isqdar))) {
            this.mTextPaint.setARGB(255, 193, 163, 209);
            return 100;
        } else if (str.contains("Mid_EQ_") && getConfig(String.valueOf(R.id.isexqdsmg))) {
            this.mTextPaint.setARGB(255, 193, 140, 222);
            return 101;
        } else if (str.contains("Crossbow_Q") && getConfig(String.valueOf(R.id.isquivercrossbow))) {
            this.mTextPaint.setARGB(255, 148, 121, 163);
            return 102;
        } else if (str.contains("ZDD_Sniper") && getConfig(String.valueOf(R.id.isbulletloop))) {
            this.mTextPaint.setARGB(255, 148, 121, 163);
            return 103;
        } else if (str.contains("ThumbGrip") && getConfig(String.valueOf(R.id.isthumbgrip))) {
            this.mTextPaint.setARGB(255, 148, 121, 163);
            return 104;
        } else if (str.contains("Lasersight") && getConfig(String.valueOf(R.id.islasersight))) {
            this.mTextPaint.setARGB(255, 148, 121, 163);
            return 105;
        } else if (str.contains("Angled") && getConfig(String.valueOf(R.id.isanglegrip))) {
            this.mTextPaint.setARGB(255, 219, 219, 219);
            return 106;
        } else if (str.contains("LightGrip") && getConfig(String.valueOf(R.id.islightgrip))) {
            this.mTextPaint.setARGB(255, 219, 219, 219);
            return 107;
        } else if (str.contains("Vertical") && getConfig(String.valueOf(R.id.isverticalgrip))) {
            this.mTextPaint.setARGB(255, 219, 219, 219);
            return 108;
        } else if (str.contains("GasCan") && getConfig(String.valueOf(R.id.isgascan))) {
            this.mTextPaint.setARGB(255, 255, 143, 203);
            return 109;
        } else if (str.contains("Mid_Compensator") && getConfig(String.valueOf(R.id.issmgcompe))) {
            this.mTextPaint.setARGB(255, 219, 219, 219);
            return 110;
        } else if (str.contains("PickUpListWrapperActor") && getConfig(String.valueOf(R.id.iscrate))) {
            this.mTextPaint.setARGB(255, 132, 201, 66);
            return 111;
        } else if (str.contains("BP_AirDropPlane_ZNQ5th_C") && getConfig(String.valueOf(R.id.isdropplane))) {
            this.mTextPaint.setARGB(255, 224, 177, 224);
            return 112;
        } else if (str.contains("BP_AirDropPlane_C") && getConfig(String.valueOf(R.id.isdropplane))) {
            this.mTextPaint.setARGB(255, 224, 177, 224);
            return 112;
        } else if (str.contains("AirDrop") && getConfig(String.valueOf(R.id.isairdrop))) {
            this.mTextPaint.setARGB(255, 224, 177, 224);
            return 113;
        } else if (str.contains("BP_AirDropBox_New_C") && getConfig(String.valueOf(R.id.isairdrop))) {
            this.mTextPaint.setARGB(255, 224, 177, 224);
            return 113;
        } else if (str.contains("SLR") && getConfig(String.valueOf(R.id.isslr))) {
            this.mTextPaint.setARGB(255, 43, 26, 28);
            return 114;
        } else if (str.contains("Sickle") && getConfig(String.valueOf(R.id.issickle))) {
            this.mTextPaint.setARGB(255, 102, 74, 74);
            return 115;
        } else if (str.contains("Machete") && getConfig(String.valueOf(R.id.ismachete))) {
            this.mTextPaint.setARGB(255, 102, 74, 74);
            return 116;
        } else if (str.contains("Pan") && getConfig(String.valueOf(R.id.ispan))) {
            this.mTextPaint.setARGB(255, 102, 74, 74);
            return 117;
        } else if (str.contains("SawedOff") && getConfig(String.valueOf(R.id.issawedoff))) {
            this.mTextPaint.setARGB(255, 156, 113, 81);
            return 118;
        } else if (str.contains("CrossBow") && getConfig(String.valueOf(R.id.iscrosbow))) {
            this.mTextPaint.setARGB(255, 102, 74, 74);
            return 119;
        } else if (str.contains("Cowbar") && getConfig(String.valueOf(R.id.iscrowbar))) {
            this.mTextPaint.setARGB(255, 102, 74, 74);
            return 120;
        } else if (str.contains("R1895") && getConfig(String.valueOf(R.id.isr1895))) {
            this.mTextPaint.setARGB(255, 156, 113, 81);
            return 121;
        } else if (str.contains("Vz61") && getConfig(String.valueOf(R.id.isscorpion))) {
            this.mTextPaint.setARGB(255, 156, 113, 81);
            return 121;
        } else if (str.contains("P92") && getConfig(String.valueOf(R.id.isp92))) {
            this.mTextPaint.setARGB(255, 156, 113, 81);
            return 121;
        } else if (str.contains("P18C") && getConfig(String.valueOf(R.id.isp18c))) {
            this.mTextPaint.setARGB(255, 156, 113, 81);
            return 121;
        } else if (str.contains("R45") && getConfig(String.valueOf(R.id.isr45))) {
            this.mTextPaint.setARGB(255, 156, 113, 81);
            return 121;
        } else if (str.contains("P1911") && getConfig(String.valueOf(R.id.isp1911))) {
            this.mTextPaint.setARGB(255, 156, 113, 81);
            return 121;
        } else if (str.contains("DesertEagle") && getConfig(String.valueOf(R.id.isdesserteagle))) {
            this.mTextPaint.setARGB(255, 156, 113, 81);
            return 121;
            //event 
        } else if (str.contains("GoldenTokenWrapper_C") && getConfig(String.valueOf(R.id.istoken))) {
            this.mTextPaint.setARGB(255, 224, 177, 224);
            return 122;
        }
        else if (str.contains("Grenade_BuildCapsuleVehicle_ForVehicle") && getConfig(String.valueOf(R.id.iscapsuleitem))) {
            this.mTextPaint.setARGB(255, 224, 177, 224);
            return 123;

        } 


        return -1;
    }
    
    private static final int[] ITEM_NAME = {
        R.drawable.i0,
        R.drawable.i1,
        R.drawable.i2,
        R.drawable.i3,
        R.drawable.i4,
        R.drawable.i5,
        R.drawable.i6,
        R.drawable.i7,
        R.drawable.i8,
        R.drawable.i9,
        R.drawable.i10,
        R.drawable.i11,
        R.drawable.i12,
        R.drawable.i13,
        R.drawable.i14,
        R.drawable.i15,
        R.drawable.i16,
        R.drawable.i17,
        R.drawable.i18,
        R.drawable.i19,
        R.drawable.i20,
        R.drawable.i21,
        R.drawable.i22,
        R.drawable.i23,
        R.drawable.i24,
        R.drawable.i25,
        R.drawable.i26,
        R.drawable.i27,
        R.drawable.i28,
        R.drawable.i29,
        R.drawable.i30,
        R.drawable.i31,
        R.drawable.i32,
        R.drawable.i33,
        R.drawable.i33,
        R.drawable.i35,
        R.drawable.i36,
        R.drawable.i37,
        R.drawable.i38,
        R.drawable.i39,
        R.drawable.i39,
        R.drawable.i41,
        R.drawable.i42,
        R.drawable.i43,
        R.drawable.i44,
        R.drawable.i45,
        R.drawable.i46,
        R.drawable.i47,
        R.drawable.i48,
        R.drawable.i49,
        R.drawable.i50,
        R.drawable.i51,
        R.drawable.i52,
        R.drawable.i53,
        R.drawable.i54,
        R.drawable.i55,
        R.drawable.i56,
        R.drawable.i57,
        R.drawable.i58,
        R.drawable.i59,
        R.drawable.i60,
        R.drawable.i61,
        R.drawable.i62,
        R.drawable.i63,
        R.drawable.i64,
        R.drawable.i65,
        R.drawable.i66,
        R.drawable.i67,
        R.drawable.i68,
        R.drawable.i69,
        R.drawable.i70,
        R.drawable.i71,
        R.drawable.i72,
        R.drawable.i73,
        R.drawable.i74,
        R.drawable.i75,
        R.drawable.i76,
        R.drawable.i77,
        R.drawable.i78,
        R.drawable.i79,
        R.drawable.i80,
        R.drawable.i81,
        R.drawable.i82,
        R.drawable.i83,
        R.drawable.i84,
        R.drawable.i85,
        R.drawable.i86,
        R.drawable.i87,
        R.drawable.i88,
        R.drawable.i89,
        R.drawable.i90,
        R.drawable.i91,
        R.drawable.i92,
        R.drawable.i93,
        R.drawable.i94,
        R.drawable.i95,
        R.drawable.i96,
        R.drawable.i97,
        R.drawable.i98,
        R.drawable.i99,
        R.drawable.i100,
        R.drawable.i101,
        R.drawable.i102,
        R.drawable.i103,
        R.drawable.i104,
        R.drawable.i105,
        R.drawable.i106,
        R.drawable.i107,
        R.drawable.i108,
        R.drawable.i109,
        R.drawable.i110,
        R.drawable.i111,
        R.drawable.i112,
        R.drawable.i113,
        R.drawable.i114,
        R.drawable.i115,
        R.drawable.i116,
        R.drawable.i117,
        R.drawable.i118,
        R.drawable.i119,
        R.drawable.i120,
        R.drawable.i121,
        R.drawable.i122,
        R.drawable.i123
    };
    
    private String getItemName(String s) {
        //Scopes
        if (s.contains("MZJ_8X") && getConfig(String.valueOf(R.id.is8x))) {
            mTextPaint.setARGB(255, 247, 99, 245);
            return "8x";
        }
        if (s.contains("MZJ_2X") && getConfig(String.valueOf(R.id.is2x))) {
            mTextPaint.setARGB(255, 230, 172, 226);
            return "2x";
        }
        if (s.contains("MZJ_HD") && getConfig(String.valueOf(R.id.isreddot))) {
            mTextPaint.setARGB(255, 230, 172, 226);
            return "Red Dot";
        }
        if (s.contains("MZJ_3X") && getConfig(String.valueOf(R.id.is3x))) {
            mTextPaint.setARGB(255, 247, 99, 245);
            return "3X";
        }
        if (s.contains("MZJ_QX") && getConfig(String.valueOf(R.id.ishollow))) {
            mTextPaint.setARGB(255, 153, 75, 152);
            return "Hollow Sight";
        }
        if (s.contains("MZJ_6X") && getConfig(String.valueOf(R.id.is6x))) {
            mTextPaint.setARGB(255, 247, 99, 245);
            return "6x";
        }
        if (s.contains("MZJ_4X") && getConfig(String.valueOf(R.id.is4x))) {
            mTextPaint.setARGB(255, 247, 99, 245);
            return "4x";
        }
        if (s.contains("MZJ_SideRMR") && getConfig(String.valueOf(R.id.iscanted))) {
            mTextPaint.setARGB(255, 153, 75, 152);
            return "Canted Sight";
        }

        //AR and SMG
        if (s.contains("AUG") && getConfig(String.valueOf(R.id.isAug))) {
            mTextPaint.setARGB(255, 52, 224, 63);
            return "AUG";
        }
        if (s.contains("M762") && getConfig(String.valueOf(R.id.isM762))) {
            mTextPaint.setARGB(255, 43, 26, 28);
            return "M762";
        }
        if (s.contains("SCAR") && getConfig(String.valueOf(R.id.isScarL))) {
            mTextPaint.setARGB(255, 52, 224, 63);
            return "SCAR-L";
        }
        if (s.contains("FAMAS") && getConfig(String.valueOf(R.id.isFAMAS))) { 
            mTextPaint.setARGB(255, 0, 255, 0);
            return "FAMAS";
        }
        if (s.contains("MG3") && getConfig(String.valueOf(R.id.isMg3))) { 
            mTextPaint.setARGB(255, 0, 255, 0);
            return "MG3 Machine Gun";
        }
        if (s.contains("AN94") && getConfig(String.valueOf(R.id.isASMAR))) { 
            mTextPaint.setARGB(255, 0, 255, 0);
            return "ASM AR";
        }
        if (s.contains("M416") && getConfig(String.valueOf(R.id.isM416))) {
            mTextPaint.setARGB(255, 115, 235, 223);
            return "M416";
        }
        if (s.contains("M16A4") && getConfig(String.valueOf(R.id.isM16A4))) {
            mTextPaint.setARGB(255, 116, 227, 123);
            return "M16A-4";
        }
        if (s.contains("Mk47") && getConfig(String.valueOf(R.id.isMK47))) {
            mTextPaint.setARGB(255, 247, 99, 245);
            return "Mk47 Mutant";
        }
        if (s.contains("G36") && getConfig(String.valueOf(R.id.isG36C))) {
            mTextPaint.setARGB(255, 116, 227, 123);
            return "G36C";
        }
        if (s.contains("QBZ") && getConfig(String.valueOf(R.id.isQBZ))) {
            mTextPaint.setARGB(255, 52, 224, 63);
            return "QBZ";
        }
        if (s.contains("AKM") && getConfig(String.valueOf(R.id.isAKM))) {
            mTextPaint.setARGB(255, 214, 99, 99);
            return "AKM";
        }
        if (s.contains("BP_Rifle_HoneyBadger_Wrapper_C") && getConfig(String.valueOf(R.id.isHoneyBadger))) {
            mTextPaint.setARGB(255, 214, 99, 99);
            return "Honey Badger";
        }
        if (s.contains("Groza") && getConfig(String.valueOf(R.id.isGroza))) {
            mTextPaint.setARGB(255, 214, 99, 99);
            return "Groza";
        }
        if (s.contains("PP19") && getConfig(String.valueOf(R.id.isBizon))) {
            mTextPaint.setARGB(255, 255, 246, 0);
            return "Bizon";
        }
        if (s.contains("TommyGun") && getConfig(String.valueOf(R.id.isTommygun))) {
            mTextPaint.setARGB(255, 207, 207, 207);
            return "TommyGun";
        }
        if (s.contains("MP5K") && getConfig(String.valueOf(R.id.isMp5k))) {
            mTextPaint.setARGB(255, 207, 207, 207);
            return "MP5K";
        }
        if (s.contains("UMP9") && getConfig(String.valueOf(R.id.isUmp))) {
            mTextPaint.setARGB(255, 207, 207, 207);
            return "UMP";
        }
        if (s.contains("Vector") && getConfig(String.valueOf(R.id.isVector))) {
            mTextPaint.setARGB(255, 255, 246, 0);
            return "Vector";
        }
        if (s.contains("MachineGun_Uzi") && getConfig(String.valueOf(R.id.isUzi))) {
            mTextPaint.setARGB(255, 255, 246, 0);
            return "UZI";
        }
        if (s.contains("MachineGun_P90") && getConfig(String.valueOf(R.id.isP90))) { 
            mTextPaint.setARGB(255, 233, 0, 207);
            return "P90";
        }
        if (s.contains("DP28") && getConfig(String.valueOf(R.id.isDp28))) {
            mTextPaint.setARGB(255, 43, 26, 28);
            return "DP28";
        }
        if (s.contains("M249") && getConfig(String.valueOf(R.id.isM249))) {
            mTextPaint.setARGB(255, 247, 99, 245);
            return "M249";
        }

        //Snipers
        if (s.contains("AWM") && getConfig(String.valueOf(R.id.isawm))) {
            mTextPaint.setColor(Color.BLACK);
            return "AWM";
        }
        if (s.contains("AMR") && getConfig(String.valueOf(R.id.isamr))) {
            mTextPaint.setARGB(255, 247, 99, 245);
            return "AMR";
        }
        if (s.contains("QBU") && getConfig(String.valueOf(R.id.isqbu))) {
            mTextPaint.setARGB(255, 207, 207, 207);
            return "QBU";
        }
        if (s.contains("SLR") && getConfig(String.valueOf(R.id.isslr))) {
            mTextPaint.setARGB(255, 43, 26, 28);
            return "SLR";
        }
        if (s.contains("SKS") && getConfig(String.valueOf(R.id.issks))) {
            mTextPaint.setARGB(255, 43, 26, 28);
            return "SKS";
        }
        if (s.contains("Mini14") && getConfig(String.valueOf(R.id.ismini14))) {
            mTextPaint.setARGB(255, 247, 99, 245);
            return "Mini14";
        }
        if (s.contains("Sniper_M24") && getConfig(String.valueOf(R.id.ism24))) {
            mTextPaint.setARGB(255, 247, 99, 245);
            return "M24";
        }
        if (s.contains("Kar98k") && getConfig(String.valueOf(R.id.iskar98k))) {
            mTextPaint.setARGB(255, 247, 99, 245);
            return "Kar98k";
        }
        if (s.contains("VSS") && getConfig(String.valueOf(R.id.isVss))) {
            mTextPaint.setARGB(255, 255, 246, 0);
            return "VSS";
        }
        if (s.contains("Win94") && getConfig(String.valueOf(R.id.iswin94))) {
            mTextPaint.setARGB(255, 207, 207, 207);
            return "Win94";
        }
        if (s.contains("Mk14") && getConfig(String.valueOf(R.id.ismk14))) {
            mTextPaint.setColor(Color.BLACK);
            return "MK14";
        }
        if (s.contains("Sniper_Mosin") && getConfig(String.valueOf(R.id.ismosin))) { 
            mTextPaint.setARGB(255, 153, 0, 0);
            return "Mosin";
        }
        if (s.contains("Sniper_MK12") && getConfig(String.valueOf(R.id.ismk12))) { 
            mTextPaint.setARGB(255, 153, 0, 0);
            return "MK12";
        }

        //Shotguns and Hand weapons
        if (s.contains("S12K") && getConfig(String.valueOf(R.id.iss12k))) {
            mTextPaint.setARGB(255, 153, 109, 109);
            return "S12K";
        }
        if (s.contains("ShotGun_DP12") && getConfig(String.valueOf(R.id.isdbs))) {
            mTextPaint.setARGB(255, 153, 109, 109);
            return "DBS";
        }
        if (s.contains("M1014") && getConfig(String.valueOf(R.id.isM1014))) { 
            mTextPaint.setARGB(255, 153, 109, 109);
            return "M1014";
        }
        if (s.contains("Neostead2000") && getConfig(String.valueOf(R.id.isns2000))) {
            mTextPaint.setARGB(255, 153, 109, 109);
            return "NS2000";
        }
        if (s.contains("S686") && getConfig(String.valueOf(R.id.iss686))) {
            mTextPaint.setARGB(255, 153, 109, 109);
            return "S686";
        }
        if (s.contains("S1897") && getConfig(String.valueOf(R.id.iss1897))) {
            mTextPaint.setARGB(255, 153, 109, 109);
            return "S1897";
        }
        if (s.contains("Sickle") && getConfig(String.valueOf(R.id.issickle))) {
            mTextPaint.setARGB(255, 102, 74, 74);
            return "Sickle";
        }
        if (s.contains("Machete") && getConfig(String.valueOf(R.id.ismachete))) {
            mTextPaint.setARGB(255, 102, 74, 74);
            return "Machete";
        }
        if (s.contains("Cowbar") && getConfig(String.valueOf(R.id.iscrowbar))) {
            mTextPaint.setARGB(255, 102, 74, 74);
            return "Crowbar";
        }
        if (s.contains("CrossBow") && getConfig(String.valueOf(R.id.iscrosbow))) {
            mTextPaint.setARGB(255, 102, 74, 74);
            return "CrossBow";
        }
        if (s.contains("BP_Other_HuntingBowEA_Wrapper_C") && getConfig(String.valueOf(R.id.isExplosiveBow))) {
            mTextPaint.setARGB(255, 102, 74, 74);
            return "Explosive Bow";
        }
        if (s.contains("Pan") && getConfig(String.valueOf(R.id.ispan))) {
            mTextPaint.setARGB(255, 102, 74, 74);
            return "Pan";
        }

        //Pistols
        if (s.contains("SawedOff") && getConfig(String.valueOf(R.id.issawedoff))) { 
            mTextPaint.setARGB(255, 153, 109, 109);
            return "SawedOff";
        }
        if (s.contains("R1895") && getConfig(String.valueOf(R.id.isr1895))) {
            mTextPaint.setARGB(255, 156, 113, 81);
            return "R1895";
        }
        if (s.contains("Vz61") && getConfig(String.valueOf(R.id.isscorpion))) {
            mTextPaint.setARGB(255, 156, 113, 81);
            return "Scorpion";
        }
        if (s.contains("P92") && getConfig(String.valueOf(R.id.isp92))) {
            mTextPaint.setARGB(255, 156, 113, 81);
            return "P92";
        }
        if (s.contains("P18C") && getConfig(String.valueOf(R.id.isp18c))) {
            mTextPaint.setARGB(255, 156, 113, 81);
            return "P18C";
        }
        if (s.contains("R45") && getConfig(String.valueOf(R.id.isr45))) {
            mTextPaint.setARGB(255, 156, 113, 81);
            return "R45";
        }
        if (s.contains("P1911") && getConfig(String.valueOf(R.id.isp1911))) {
            mTextPaint.setARGB(255, 156, 113, 81);
            return "P1911";
        }
        if (s.contains("DesertEagle") && getConfig(String.valueOf(R.id.isdesserteagle))) { 
            mTextPaint.setARGB(255, 156, 113, 81);
            return "DesertEagle";
        }

        //Ammo
        if (s.contains("Ammo_762mm") && getConfig(String.valueOf(R.id.is762mm))) {
            mTextPaint.setARGB(255, 92, 36, 28);
            return "7.62mm";
        }
        if (s.contains("Ammo_45AC") && getConfig(String.valueOf(R.id.is45acp))) {
            mTextPaint.setColor(Color.LTGRAY);
            return "45ACP";
        }
        if (s.contains("Ammo_556mm") && getConfig(String.valueOf(R.id.is556mm))) {
            mTextPaint.setColor(Color.GREEN);
            return "5.56mm";
        }
        if (s.contains("Ammo_9mm") && getConfig(String.valueOf(R.id.is9mm))) {
            mTextPaint.setColor(Color.YELLOW);
            return "9mm";
        }
        if (s.contains("Ammo_300Magnum") && getConfig(String.valueOf(R.id.is300magnum))) {
            mTextPaint.setColor(Color.BLACK);
            return "300Magnum";
        }
        if (s.contains("Ammo_50BMG") && getConfig(String.valueOf(R.id.is50bmg))) {
            mTextPaint.setColor(Color.BLACK);
            return "50BMG";
        }
        if (s.contains("Ammo_12Guage") && getConfig(String.valueOf(R.id.is12guage))) {
            mTextPaint.setARGB(255, 156, 91, 81);
            return "12 Guage";
        }
        if (s.contains("Ammo_Bolt") && getConfig(String.valueOf(R.id.isarrow))) {
            mTextPaint.setARGB(255, 156, 113, 81);
            return "Arrow";
        }

        //bag helmet vest
        if (s.contains("Bag_Lv3") && getConfig(String.valueOf(R.id.isbags3))) { mTextPaint.setARGB(255, 36, 83, 255);
            return "Bag lvl 3";
        }

        if (s.contains("Bag_Lv1")  && getConfig(String.valueOf(R.id.isbags1))) { mTextPaint.setARGB(255, 127, 154, 250);
            return "Bag lvl 1";
        }

        if (s.contains("Bag_Lv2") && getConfig(String.valueOf(R.id.isbags2))) { mTextPaint.setARGB(255, 77, 115, 255);
            return "Bag lvl 2";
        }

        if (s.contains("Armor_Lv2") && getConfig(String.valueOf(R.id.isvest2))) { mTextPaint.setARGB(255, 77, 115, 255);
            return "Vest lvl 2";
        }


        if (s.contains("Armor_Lv1") && getConfig(String.valueOf(R.id.isvest1))) { mTextPaint.setARGB(255, 127, 154, 250);
            return "Vest lvl 1";
        }


        if (s.contains("Armor_Lv3") && getConfig(String.valueOf(R.id.isvest3))) { mTextPaint.setARGB(255, 36, 83, 255);
            return "Vest lvl 3";
        }


        if (s.contains("Helmet_Lv2") && getConfig(String.valueOf(R.id.ishelm2))) { mTextPaint.setARGB(255, 77, 115, 255);
            return "Helmet lvl 2";
        }

        if (s.contains("Helmet_Lv1") && getConfig(String.valueOf(R.id.ishelm1))) { mTextPaint.setARGB(255, 127, 154, 250);
            return "Helmet lvl 1";
        }

        if (s.contains("Helmet_Lv3") && getConfig(String.valueOf(R.id.ishelm3))) { mTextPaint.setARGB(255, 36, 83, 255);
            return "Helmet lvl 3";
        }

        //Healthkits
        if (s.contains("Pills") && getConfig(String.valueOf(R.id.ispainkiller))) { mTextPaint.setARGB(255, 227, 91, 54);
            return "PainKiller";
        }

        if (s.contains("Injection") && getConfig(String.valueOf(R.id.isinjecti))) { mTextPaint.setARGB(255,204, 193, 190);
            return "Injection";
        }

        if (s.contains("Drink") && getConfig(String.valueOf(R.id.isenergydrink))) { mTextPaint.setARGB(255, 54, 175, 227);
            return "Energy Drink";
        }

        if (s.contains("Firstaid") && getConfig(String.valueOf(R.id.isfirstaid))) { mTextPaint.setARGB(255, 194, 188, 109);
            return "FirstAid";
        }

        if (s.contains("Bandage") && getConfig(String.valueOf(R.id.isbandage))) { mTextPaint.setARGB(255, 43, 189, 48);
            return "Bandage";
        }

        if (s.contains("FirstAidbox") && getConfig(String.valueOf(R.id.ismedkit))) { mTextPaint.setARGB(255, 0, 171, 6);
            return "Medkit";
        }

        //Throwables
        if (s.contains("Grenade_Stun") && getConfig(String.valueOf(R.id.isstung))) { mTextPaint.setARGB(255,204, 193, 190);
            return "Stun";
        }

        if (s.contains("Grenade_Shoulei") && getConfig(String.valueOf(R.id.isgranade))) { mTextPaint.setARGB(255, 2, 77, 4);
            return "Grenade";
        }

        if (s.contains("Grenade_Smoke") && getConfig(String.valueOf(R.id.issmoke))) { mTextPaint.setColor(Color.WHITE);
            return "Smoke";
        }

        if (s.contains("Grenade_Burn") && getConfig(String.valueOf(R.id.ismolotov))) { mTextPaint.setARGB(255, 230, 175, 64);
            return "Molotov";
        }


        //others
        if (s.contains("Large_FlashHider") && getConfig(String.valueOf(R.id.isflashhiderar))) { mTextPaint.setARGB(255, 255, 213, 130);
            return "Flash Hider Ar";
        }

        if (s.contains("QK_Large_C") && getConfig(String.valueOf(R.id.isarcompe))) { mTextPaint.setARGB(255, 255, 213, 130);
            return "Ar Compensator";
        }

        if (s.contains("Mid_FlashHider") && getConfig(String.valueOf(R.id.isflashhidersmg))) { mTextPaint.setARGB(255, 255, 213, 130);
            return "Flash Hider SMG";
        }

        if (s.contains("QT_A_") && getConfig(String.valueOf(R.id.istacticalstock))) { mTextPaint.setARGB(255, 158, 222, 195);
            return "Tactical Stock";
        }

        if (s.contains("DuckBill") && getConfig(String.valueOf(R.id.isduckbill))) { mTextPaint.setARGB(255, 158, 222, 195);
            return "DuckBill";
        }

        if (s.contains("Sniper_FlashHider") && getConfig(String.valueOf(R.id.isflashhidersnip))) { mTextPaint.setARGB(255, 158, 222, 195);
            return "Flash Hider Sniper";
        }

        if (s.contains("Mid_Suppressor") && getConfig(String.valueOf(R.id.issuppresoramg))) { mTextPaint.setARGB(255, 158, 222, 195);
            return "Suppressor SMG";
        }

        if (s.contains("HalfGrip") && getConfig(String.valueOf(R.id.ishalfgrip))) { mTextPaint.setARGB(255, 155, 189, 222);
            return "Half Grip";
        }


        if (s.contains("Choke") && getConfig(String.valueOf(R.id.ischoke))) { mTextPaint.setARGB(255, 155, 189, 222);
            return "Choke";
        }

        if (s.contains("QT_UZI") && getConfig(String.valueOf(R.id.isstockmicrouzi))) { mTextPaint.setARGB(255, 155, 189, 222);
            return "Stock Micro UZI";
        }

        if (s.contains("QK_Sniper") && getConfig(String.valueOf(R.id.issnipercompe))) { mTextPaint.setARGB(255, 60, 127, 194);
            return "Sniper Compensator";
        }

        if (s.contains("Sniper_Suppressor") && getConfig(String.valueOf(R.id.issupsniper))) { mTextPaint.setARGB(255, 60, 127, 194);
            return "Suppressor Sniper";
        }

        if (s.contains("Large_Suppressor") && getConfig(String.valueOf(R.id.issupar))) { mTextPaint.setARGB(255, 60, 127, 194);
            return "Suppressor Ar";
        }


        if (s.contains("Sniper_EQ_") && getConfig(String.valueOf(R.id.isexqdsniper))) { mTextPaint.setARGB(255, 193, 140, 222);
            return "Ex.Qd.Sniper";
        }

        if (s.contains("Mid_Q_") && getConfig(String.valueOf(R.id.isqdsmg))) { mTextPaint.setARGB(255, 193, 163, 209);
            return "Qd.SMG";
        }

        if (s.contains("Mid_E_") && getConfig(String.valueOf(R.id.isexsmg))) { mTextPaint.setARGB(255, 193, 163, 209);
            return "Ex.SMG";
        }

        if (s.contains("Sniper_Q_") && getConfig(String.valueOf(R.id.isqdsniper))) { mTextPaint.setARGB(255, 193, 163, 209);
            return "Qd.Sniper";
        }

        if (s.contains("Sniper_E_") && getConfig(String.valueOf(R.id.isexsniper))) { mTextPaint.setARGB(255, 193, 163, 209);
            return "Ex.Sniper";
        }

        if (s.contains("Large_E_") && getConfig(String.valueOf(R.id.isexar))) { mTextPaint.setARGB(255, 193, 163, 209);
            return "Ex.Ar";
        }

        if (s.contains("Large_EQ_") && getConfig(String.valueOf(R.id.isexqdar))) { mTextPaint.setARGB(255, 193, 140, 222);
            return "Ex.Qd.Ar";
        }

        if (s.contains("Large_Q_") && getConfig(String.valueOf(R.id.isqdar))) { mTextPaint.setARGB(255, 193, 163, 209);
            return "Qd.Ar";
        }

        if (s.contains("Mid_EQ_") && getConfig(String.valueOf(R.id.isexqdsmg))) { mTextPaint.setARGB(255, 193, 140, 222);
            return "Ex.Qd.SMG";
        }

        if (s.contains("Crossbow_Q") && getConfig(String.valueOf(R.id.isquivercrossbow))) { mTextPaint.setARGB(255, 148, 121, 163);
            return "Quiver CrossBow";
        }

        if (s.contains("ZDD_Sniper") && getConfig(String.valueOf(R.id.isbulletloop))) { mTextPaint.setARGB(255, 148, 121, 163);
            return "Bullet Loop";
        }


        if (s.contains("ThumbGrip") && getConfig(String.valueOf(R.id.isthumbgrip))) { mTextPaint.setARGB(255, 148, 121, 163);
            return "Thumb Grip";
        }

        if (s.contains("Lasersight") && getConfig(String.valueOf(R.id.islasersight))) { mTextPaint.setARGB(255, 148, 121, 163);
            return "Laser Sight";
        }

        if (s.contains("Angled") && getConfig(String.valueOf(R.id.isanglegrip))) { mTextPaint.setARGB(255, 219, 219, 219);
            return "Angled Grip";
        }

        if (s.contains("LightGrip") && getConfig(String.valueOf(R.id.islightgrip))) { mTextPaint.setARGB(255, 219, 219, 219);
            return "Light Grip";
        }

        if (s.contains("Vertical") && getConfig(String.valueOf(R.id.isverticalgrip))) { mTextPaint.setARGB(255, 219, 219, 219);
            return "Vertical Grip";
        }

        if (s.contains("GasCan") && getConfig(String.valueOf(R.id.isgascan))) { mTextPaint.setARGB(255, 255, 143, 203);
            return "Gas Can";
        }

        if (s.contains("Mid_Compensator") && getConfig(String.valueOf(R.id.issmgcompe))) { mTextPaint.setARGB(255, 219, 219, 219);
            return "Compensator SMG";
        }


        //special
        if (s.contains("Flare") && getConfig(String.valueOf(R.id.isfalregun))) { mTextPaint.setARGB(255, 242, 63, 159);
            return "Flare Gun";
        }

        if (s.contains("Ghillie") && getConfig(String.valueOf(R.id.isghilliesuit))) { mTextPaint.setARGB(255, 139, 247, 67);
            return "Ghillie Suit";
        }
        if (s.contains("CheekPad") && getConfig(String.valueOf(R.id.ischeeckpad))) { mTextPaint.setARGB(255, 112, 55, 55);
            return "CheekPad";
        }
        if ( s.contains("PickUpListWrapperActor") && getConfig(String.valueOf(R.id.iscrate))) { mTextPaint.setARGB(200, 255, 255, 255);
            return "Crate";
        }
        if ((s.contains("BP_AirDropPlane_ZNQ5th_C") )&& getConfig(String.valueOf(R.id.isdropplane))) { mTextPaint.setARGB(255, 224, 177, 224);
            return "DropPlane";
        }
        if ((s.contains("AirDrop")  )&& getConfig(String.valueOf(R.id.isairdrop))) { mTextPaint.setARGB(255, 255, 10, 255);
            return "AirDrop";
        }
        if ((s.contains("BP_AirDropPlane_C") )&& getConfig(String.valueOf(R.id.isdropplane))) { mTextPaint.setARGB(255, 224, 177, 224);
            return "DropPlane";
        }
        if ((s.contains("BP_AirDropBox_New_C")  )&& getConfig(String.valueOf(R.id.isairdrop))) { mTextPaint.setARGB(255, 255, 10, 255);
            return "AirDrop";
        }

        //Event Items PUBGM
        if ((s.contains("GoldenTokenWrapper_C")  )&& getConfig(String.valueOf(R.id.istoken))) { mTextPaint.setARGB(255, 255, 0, 255);
            return "Token";
        }
        if ((s.contains("Grenade_BuildCapsuleVehicle_ForVehicle")  )&& getConfig(String.valueOf(R.id.iscapsuleitem))) { mTextPaint.setARGB(255, 0, 255, 255);
            return "Capsule Item";
        }

        return null;

    }
  

    private int getVehicleName(String str) {
        if (str.contains("Buggy") && getConfig(String.valueOf(R.id.isBuggy))) {
            return 0;
        }
        if (str.contains("UAZ") && getConfig(String.valueOf(R.id.isuaz))) {
            return 1;
        }
        if (str.contains("MotorcycleC") && getConfig(String.valueOf(R.id.istrike))) {
            return 2;
        }
        if (str.contains("Motorcycle") && getConfig(String.valueOf(R.id.isbike))) {
            return 3;
        }
        if (str.contains("Dacia") && getConfig(String.valueOf(R.id.isdacia))) {
            return 4;
        }
        if (str.contains("AquaRail") && getConfig(String.valueOf(R.id.isjet))) {
            return 5;
        }
        if (str.contains("PG117") && getConfig(String.valueOf(R.id.isboat))) {
            return 6;
        }
        if (str.contains("MiniBus") && getConfig(String.valueOf(R.id.isbus))) {
            return 7;
        }
        if (str.contains("Mirado") && getConfig(String.valueOf(R.id.ismirado))) {
            return 8;
        }
        if (str.contains("Scooter") && getConfig(String.valueOf(R.id.isscooter))) {
            return 9;
        }
        if (str.contains("Rony") && getConfig(String.valueOf(R.id.isrony))) {
            return 10;
        }
        if (str.contains("Snowbike") && getConfig(String.valueOf(R.id.issnowbike))) {
            return 11;
        }
        if (str.contains("Snowmobile") && getConfig(String.valueOf(R.id.isnowmobile))) {
            return 12;
        }
        if (str.contains("Tuk") && getConfig(String.valueOf(R.id.istempo))) {
            return 13;
        }
        if (str.contains("PickUp") && getConfig(String.valueOf(R.id.istruck))) {
            return 14;
        }
        if (str.contains("BRDM") && getConfig(String.valueOf(R.id.isbrdm))) {
            return 15;
        }
        if (str.contains("CoupeRB") && getConfig(String.valueOf(R.id.iscoperb))) {
            return 17;
        }
        if (str.contains("LadaNiva") && getConfig(String.valueOf(R.id.isladaniva))) {
            return 16;
        }
        if (str.contains("glider") && getConfig(String.valueOf(R.id.ismotorglider))) { //Android Text
            return 20;
        }
        if (str.contains("UTV") && getConfig(String.valueOf(R.id.isutv))) {
            return 21;
        }
        if (str.contains("ATV1") && getConfig(String.valueOf(R.id.isatv1))) {
            return 18;
        }      
        if (str.contains("HangGlider") && getConfig(String.valueOf(R.id.ishangglider))) {
            return 20;
        }
        if (str.contains("Bigfoot") && getConfig(String.valueOf(R.id.ismonster))) {
            return 14;
        }if (str.contains("CapsuleVehicleNew") && getConfig(String.valueOf(R.id.iscapsule))) {
            return 5;
        }

        return -1;
	}
    private static int[] VEH_NAME = {
        R.drawable.ve0,
        R.drawable.ve1,
        R.drawable.ve2,
        R.drawable.ve3,
        R.drawable.ve4,
        R.drawable.ve5,
        R.drawable.ve6,
        R.drawable.ve7,
        R.drawable.ve8,
        R.drawable.ve9,
        R.drawable.ve10,
        R.drawable.ve11,
        R.drawable.ve12,
        R.drawable.ve13,
        R.drawable.ve14,
        R.drawable.ve15,
        R.drawable.ve16,
        R.drawable.ve17,
        R.drawable.ve18,
        R.drawable.ve19,
        R.drawable.ve20,
        R.drawable.ve21,
        R.drawable.ve22,
        R.drawable.ve23
    };
    private String VehicleName(String s) {

        if (s.contains("Buggy") && getConfig( String.valueOf(R.id.isBuggy)))
            return "Buggy";
        if (s.contains("UAZ") && getConfig( String.valueOf(R.id.isuaz)))
            return "UAZ";
        if (s.contains("MotorcycleC") && getConfig( String.valueOf(R.id.istrike)))
            return "Trike";
        if (s.contains("Motorcycle") && getConfig( String.valueOf(R.id.isbike)))
            return "Bike";
        if (s.contains("Dacia") && getConfig( String.valueOf(R.id.isdacia)))
            return "Dacia";
        if (s.contains("AquaRail") && getConfig( String.valueOf(R.id.isjet)))
            return "Jet";
        if (s.contains("PG117") && getConfig( String.valueOf(R.id.isboat)))
            return "Boat";
        if (s.contains("MiniBus") && getConfig( String.valueOf(R.id.isbus)))
            return "Bus";
        if (s.contains("Mirado") && getConfig( String.valueOf(R.id.ismirado)))
            return "Mirado";
        if (s.contains("Scooter") && getConfig( String.valueOf(R.id.isscooter)))
            return "Scooter";
        if (s.contains("Rony") && getConfig( String.valueOf(R.id.isrony)))
            return "Rony";
        if (s.contains("Snowbike") && getConfig( String.valueOf(R.id.issnowbike)))
            return "Snowbike";
        if (s.contains("Snowmobile") && getConfig( String.valueOf(R.id.isnowmobile)))
            return "Snowmobile";
        if (s.contains("Tuk") && getConfig( String.valueOf(R.id.istempo)))
            return "Tempo";
        if (s.contains("PickUp") && getConfig( String.valueOf(R.id.istruck)))
            return "Truck";
        if (s.contains("BRDM") && getConfig( String.valueOf(R.id.isbrdm)))
            return "BRDM";
        if (s.contains("LadaNiva") && getConfig( String.valueOf(R.id.isladaniva)))
            return "LadaNiva";
        if (s.contains("Bigfoot") && getConfig( String.valueOf(R.id.ismonster)))
            return "Monster";
        if (s.contains("CoupeRB") && getConfig( String.valueOf(R.id.iscoperb)))
            return "CoupeRB";
        if (s.contains("glider") && getConfig( String.valueOf(R.id.ismotorglider)))
            return "Motor Glider";
        if(s.contains("UTV") && getConfig( String.valueOf(R.id.isutv)))
            return "UTV";
        if(s.contains("ATV1") && getConfig( String.valueOf(R.id.isatv1)))
            return "ATV1";
        if(s.contains("HangGlider") && getConfig(String.valueOf(R.id.ishangglider)))
            return "Hang Glider";
        // even
        if (s.contains("CapsuleVehicleNew") && getConfig(String.valueOf(R.id.iscapsule)))
            return "Capsule";
        return null;
    }

    public static Bitmap scale(Bitmap bitmap, int maxWidth, int maxHeight) {
        // Determine the constrained dimension, which determines both dimensions.
        int width;
        int height;
        float widthRatio = (float)bitmap.getWidth() / maxWidth;
        float heightRatio = (float)bitmap.getHeight() / maxHeight;
        // Width constrained.
        if (widthRatio >= heightRatio) {
            width = maxWidth;
            height = (int)(((float)width / bitmap.getWidth()) * bitmap.getHeight());
        } else {
            height = maxHeight;
            width = (int)(((float)height / bitmap.getHeight()) * bitmap.getWidth());
        }
        Bitmap scaledBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);

        float ratioX = (float)width / bitmap.getWidth();
        float ratioY = (float)height / bitmap.getHeight();
        float middleX = width / 2.0f;
        float middleY = height / 2.0f;
        Matrix scaleMatrix = new Matrix();
        scaleMatrix.setScale(ratioX, ratioY, middleX, middleY);

        Canvas canvas = new Canvas(scaledBitmap);
        canvas.setMatrix(scaleMatrix);
        canvas.drawBitmap(bitmap, middleX - bitmap.getWidth() / 2, middleY - bitmap.getHeight() / 2, new Paint(Paint.FILTER_BITMAP_FLAG));
        return scaledBitmap;
    }
}


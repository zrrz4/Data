package pubgm.loader;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.view.Window;
import android.widget.Toast;

import net.lingala.zip4j.ZipFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class Downtwo extends AsyncTask<String, String, String> {

    private final Context context;
    private File zipFile;
    private Dialog loadingDialog;

    private static final String FILE_NAME = "Saved.zip";

    private native String PASSJKPAPA();

    public Downtwo(Context context) {
        this.context = context;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        try {
            loadingDialog = new Dialog(context);

            loadingDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

            loadingDialog.setContentView(R.layout.loading_dialog);

            loadingDialog.setCancelable(false);

            Window window = loadingDialog.getWindow();

            if (window != null) {
                window.setBackgroundDrawable(
                        new ColorDrawable(Color.TRANSPARENT)
                );

                window.setDimAmount(0.65f);
            }

            /*
             * لا نربط أي LottieAnimationView هنا.
             *
             * جميع الأنيميشنات تعمل تلقائياً من XML
             * باستخدام:
             *
             * app:lottie_autoPlay="true"
             * app:lottie_loop="true"
             */

            loadingDialog.show();

        } catch (Exception e) {

            e.printStackTrace();

            loadingDialog = null;
        }
    }

    @Override
    protected String doInBackground(String... strings) {

        if (strings == null || strings.length < 2) {
            return "Error";
        }

        HttpURLConnection connection = null;
        InputStream input = null;
        OutputStream output = null;

        try {

            URL url = new URL(strings[1]);

            connection = (HttpURLConnection) url.openConnection();

            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            connection.setRequestMethod("GET");
            connection.setDoInput(true);

            connection.connect();

            int responseCode = connection.getResponseCode();

            if (responseCode != HttpURLConnection.HTTP_OK) {
                return "Error";
            }

            input = connection.getInputStream();

            File pathBase = context.getFilesDir();

            if (!pathBase.exists()) {

                if (!pathBase.mkdirs() && !pathBase.exists()) {
                    return "Error";
                }
            }

            zipFile = new File(pathBase, FILE_NAME);

            output = new FileOutputStream(zipFile);

            byte[] data = new byte[8192];

            int count;

            while ((count = input.read(data)) != -1) {

                output.write(data, 0, count);
            }

            output.flush();

            return "Downloaded";

        } catch (Exception e) {

            e.printStackTrace();

            return "Error";

        } finally {

            try {
                if (output != null) {
                    output.close();
                }
            } catch (Exception ignored) {
            }

            try {
                if (input != null) {
                    input.close();
                }
            } catch (Exception ignored) {
            }

            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    @Override
    protected void onProgressUpdate(String... values) {
        super.onProgressUpdate(values);

        /*
         * لا يوجد ProgressBar أو نسبة مئوية.
         *
         * واجهة التحميل تحتوي فقط على:
         * - Lottie الرئيسي
         * - جاري التحميل...
         * - Lottie السفلي
         * - الصاروخ
         */
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);

        // إغلاق نافذة التحميل
        if (loadingDialog != null && loadingDialog.isShowing()) {

            loadingDialog.dismiss();
        }

        // فشل التحميل
        if (!"Downloaded".equals(result)) {

            Toast.makeText(
                    context,
                    "فشل التحميل",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        File downloadedZip =
                new File(context.getFilesDir(), FILE_NAME);

        // التأكد من وجود الملف
        if (!downloadedZip.exists()) {

            Toast.makeText(
                    context,
                    "ملف التحميل غير موجود",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        String extractPath =
                context.getFilesDir().getAbsolutePath();

        try {

            ZipFile zip = new ZipFile(downloadedZip);

            zip.extractAll(extractPath);

            // حذف الملف بعد فك الضغط
            if (downloadedZip.exists()) {
                downloadedZip.delete();
            }

        } catch (Exception e) {

            e.printStackTrace();

            Toast.makeText(
                    context,
                    "فشل فك الضغط",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}
